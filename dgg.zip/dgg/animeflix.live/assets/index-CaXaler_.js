function e(e,t){for(var n=0;n<t.length;n++){const r=t[n];if("string"!=typeof r&&!Array.isArray(r))for(const t in r)if("default"!==t&&!(t in e)){const n=Object.getOwnPropertyDescriptor(r,t);n&&Object.defineProperty(e,t,n.get?n:{enumerable:!0,get:()=>r[t]})}}return Object.freeze(Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}))}!function(){const e=document.createElement("link").relList;if(!(e&&e.supports&&e.supports("modulepreload"))){for(const e of document.querySelectorAll('link[rel="modulepreload"]'))t(e);new MutationObserver((e=>{for(const n of e)if("childList"===n.type)for(const e of n.addedNodes)"LINK"===e.tagName&&"modulepreload"===e.rel&&t(e)})).observe(document,{childList:!0,subtree:!0})}function t(e){if(e.ep)return;e.ep=!0;const t=function(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),"use-credentials"===e.crossOrigin?t.credentials="include":"anonymous"===e.crossOrigin?t.credentials="omit":t.credentials="same-origin",t}(e);fetch(e.href,t)}}();var t="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};function n(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function r(e){if(e.__esModule)return e;var t=e.default;if("function"==typeof t){var n=function e(){return this instanceof e?Reflect.construct(t,arguments,this.constructor):t.apply(this,arguments)};n.prototype=t.prototype}else n={};return Object.defineProperty(n,"__esModule",{value:!0}),Object.keys(e).forEach((function(t){var r=Object.getOwnPropertyDescriptor(e,t);Object.defineProperty(n,t,r.get?r:{enumerable:!0,get:function(){return e[t]}})})),n}var o={exports:{}},i={},a=Object.getOwnPropertySymbols,l=Object.prototype.hasOwnProperty,s=Object.prototype.propertyIsEnumerable;var c=function(){try{if(!Object.assign)return!1;var e=new String("abc");if(e[5]="de","5"===Object.getOwnPropertyNames(e)[0])return!1;for(var t={},n=0;n<10;n++)t["_"+String.fromCharCode(n)]=n;if("0123456789"!==Object.getOwnPropertyNames(t).map((function(e){return t[e]})).join(""))return!1;var r={};return"abcdefghijklmnopqrst".split("").forEach((function(e){r[e]=e})),"abcdefghijklmnopqrst"===Object.keys(Object.assign({},r)).join("")}catch(o){return!1}}()?Object.assign:function(e,t){for(var n,r,o=function(e){if(null==e)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(e)}(e),i=1;i<arguments.length;i++){for(var c in n=Object(arguments[i]))l.call(n,c)&&(o[c]=n[c]);if(a){r=a(n);for(var u=0;u<r.length;u++)s.call(n,r[u])&&(o[r[u]]=n[r[u]])}}return o};const u=n(c);var d={exports:{}},f={},p=c,m=60103,h=60106;f.Fragment=60107,f.StrictMode=60108,f.Profiler=60114;var g=60109,v=60110,y=60112;f.Suspense=60113;var b=60115,w=60116;if("function"==typeof Symbol&&Symbol.for){var x=Symbol.for;m=x("react.element"),h=x("react.portal"),f.Fragment=x("react.fragment"),f.StrictMode=x("react.strict_mode"),f.Profiler=x("react.profiler"),g=x("react.provider"),v=x("react.context"),y=x("react.forward_ref"),f.Suspense=x("react.suspense"),b=x("react.memo"),w=x("react.lazy")}var k="function"==typeof Symbol&&Symbol.iterator;function S(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var j={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},E={};function C(e,t,n){this.props=e,this.context=t,this.refs=E,this.updater=n||j}function A(){}function O(e,t,n){this.props=e,this.context=t,this.refs=E,this.updater=n||j}C.prototype.isReactComponent={},C.prototype.setState=function(e,t){if("object"!=typeof e&&"function"!=typeof e&&null!=e)throw Error(S(85));this.updater.enqueueSetState(this,e,t,"setState")},C.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},A.prototype=C.prototype;var N=O.prototype=new A;N.constructor=O,p(N,C.prototype),N.isPureReactComponent=!0;var _={current:null},P=Object.prototype.hasOwnProperty,I={key:!0,ref:!0,__self:!0,__source:!0};function T(e,t,n){var r,o={},i=null,a=null;if(null!=t)for(r in void 0!==t.ref&&(a=t.ref),void 0!==t.key&&(i=""+t.key),t)P.call(t,r)&&!I.hasOwnProperty(r)&&(o[r]=t[r]);var l=arguments.length-2;if(1===l)o.children=n;else if(1<l){for(var s=Array(l),c=0;c<l;c++)s[c]=arguments[c+2];o.children=s}if(e&&e.defaultProps)for(r in l=e.defaultProps)void 0===o[r]&&(o[r]=l[r]);return{$$typeof:m,type:e,key:i,ref:a,props:o,_owner:_.current}}function L(e){return"object"==typeof e&&null!==e&&e.$$typeof===m}var M=/\/+/g;function R(e,t){return"object"==typeof e&&null!==e&&null!=e.key?function(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,(function(e){return t[e]}))}(""+e.key):t.toString(36)}function z(e,t,n,r,o){var i=typeof e;"undefined"!==i&&"boolean"!==i||(e=null);var a=!1;if(null===e)a=!0;else switch(i){case"string":case"number":a=!0;break;case"object":switch(e.$$typeof){case m:case h:a=!0}}if(a)return o=o(a=e),e=""===r?"."+R(a,0):r,Array.isArray(o)?(n="",null!=e&&(n=e.replace(M,"$&/")+"/"),z(o,t,n,"",(function(e){return e}))):null!=o&&(L(o)&&(o=function(e,t){return{$$typeof:m,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}(o,n+(!o.key||a&&a.key===o.key?"":(""+o.key).replace(M,"$&/")+"/")+e)),t.push(o)),1;if(a=0,r=""===r?".":r+":",Array.isArray(e))for(var l=0;l<e.length;l++){var s=r+R(i=e[l],l);a+=z(i,t,n,s,o)}else if(s=function(e){return null===e||"object"!=typeof e?null:"function"==typeof(e=k&&e[k]||e["@@iterator"])?e:null}(e),"function"==typeof s)for(e=s.call(e),l=0;!(i=e.next()).done;)a+=z(i=i.value,t,n,s=r+R(i,l++),o);else if("object"===i)throw t=""+e,Error(S(31,"[object Object]"===t?"object with keys {"+Object.keys(e).join(", ")+"}":t));return a}function $(e,t,n){if(null==e)return e;var r=[],o=0;return z(e,r,"","",(function(e){return t.call(n,e,o++)})),r}function D(e){if(-1===e._status){var t=e._result;t=t(),e._status=0,e._result=t,t.then((function(t){0===e._status&&(t=t.default,e._status=1,e._result=t)}),(function(t){0===e._status&&(e._status=2,e._result=t)}))}if(1===e._status)return e._result;throw e._result}var B={current:null};function F(){var e=B.current;if(null===e)throw Error(S(321));return e}var U={ReactCurrentDispatcher:B,ReactCurrentBatchConfig:{transition:0},ReactCurrentOwner:_,IsSomeRendererActing:{current:!1},assign:p};f.Children={map:$,forEach:function(e,t,n){$(e,(function(){t.apply(this,arguments)}),n)},count:function(e){var t=0;return $(e,(function(){t++})),t},toArray:function(e){return $(e,(function(e){return e}))||[]},only:function(e){if(!L(e))throw Error(S(143));return e}},f.Component=C,f.PureComponent=O,f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=U,f.cloneElement=function(e,t,n){if(null==e)throw Error(S(267,e));var r=p({},e.props),o=e.key,i=e.ref,a=e._owner;if(null!=t){if(void 0!==t.ref&&(i=t.ref,a=_.current),void 0!==t.key&&(o=""+t.key),e.type&&e.type.defaultProps)var l=e.type.defaultProps;for(s in t)P.call(t,s)&&!I.hasOwnProperty(s)&&(r[s]=void 0===t[s]&&void 0!==l?l[s]:t[s])}var s=arguments.length-2;if(1===s)r.children=n;else if(1<s){l=Array(s);for(var c=0;c<s;c++)l[c]=arguments[c+2];r.children=l}return{$$typeof:m,type:e.type,key:o,ref:i,props:r,_owner:a}},f.createContext=function(e,t){return void 0===t&&(t=null),(e={$$typeof:v,_calculateChangedBits:t,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider={$$typeof:g,_context:e},e.Consumer=e},f.createElement=T,f.createFactory=function(e){var t=T.bind(null,e);return t.type=e,t},f.createRef=function(){return{current:null}},f.forwardRef=function(e){return{$$typeof:y,render:e}},f.isValidElement=L,f.lazy=function(e){return{$$typeof:w,_payload:{_status:-1,_result:e},_init:D}},f.memo=function(e,t){return{$$typeof:b,type:e,compare:void 0===t?null:t}},f.useCallback=function(e,t){return F().useCallback(e,t)},f.useContext=function(e,t){return F().useContext(e,t)},f.useDebugValue=function(){},f.useEffect=function(e,t){return F().useEffect(e,t)},f.useImperativeHandle=function(e,t,n){return F().useImperativeHandle(e,t,n)},f.useLayoutEffect=function(e,t){return F().useLayoutEffect(e,t)},f.useMemo=function(e,t){return F().useMemo(e,t)},f.useReducer=function(e,t,n){return F().useReducer(e,t,n)},f.useRef=function(e){return F().useRef(e)},f.useState=function(e){return F().useState(e)},f.version="17.0.2",d.exports=f;var W=d.exports;const V=n(W),H=e({__proto__:null,default:V},[W]);var q=W,Y=60103;if(i.Fragment=60107,"function"==typeof Symbol&&Symbol.for){var J=Symbol.for;Y=J("react.element"),i.Fragment=J("react.fragment")}var G=q.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,Q=Object.prototype.hasOwnProperty,K={key:!0,ref:!0,__self:!0,__source:!0};function X(e,t,n){var r,o={},i=null,a=null;for(r in void 0!==n&&(i=""+n),void 0!==t.key&&(i=""+t.key),void 0!==t.ref&&(a=t.ref),t)Q.call(t,r)&&!K.hasOwnProperty(r)&&(o[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps)void 0===o[r]&&(o[r]=t[r]);return{$$typeof:Y,type:e,key:i,ref:a,props:o,_owner:G.current}}i.jsx=X,i.jsxs=X,o.exports=i;var Z=o.exports,ee={exports:{}},te={},ne={exports:{}},re={};!function(e){var t,n,r,o;if("object"==typeof performance&&"function"==typeof performance.now){var i=performance;e.unstable_now=function(){return i.now()}}else{var a=Date,l=a.now();e.unstable_now=function(){return a.now()-l}}if("undefined"==typeof window||"function"!=typeof MessageChannel){var s=null,c=null,u=function(){if(null!==s)try{var t=e.unstable_now();s(!0,t),s=null}catch(n){throw setTimeout(u,0),n}};t=function(e){null!==s?setTimeout(t,0,e):(s=e,setTimeout(u,0))},n=function(e,t){c=setTimeout(e,t)},r=function(){clearTimeout(c)},e.unstable_shouldYield=function(){return!1},o=e.unstable_forceFrameRate=function(){}}else{var d=window.setTimeout,f=window.clearTimeout;if("undefined"!=typeof console){var p=window.cancelAnimationFrame;"function"!=typeof window.requestAnimationFrame&&console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills"),"function"!=typeof p&&console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills")}var m=!1,h=null,g=-1,v=5,y=0;e.unstable_shouldYield=function(){return e.unstable_now()>=y},o=function(){},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):v=0<e?Math.floor(1e3/e):5};var b=new MessageChannel,w=b.port2;b.port1.onmessage=function(){if(null!==h){var t=e.unstable_now();y=t+v;try{h(!0,t)?w.postMessage(null):(m=!1,h=null)}catch(n){throw w.postMessage(null),n}}else m=!1},t=function(e){h=e,m||(m=!0,w.postMessage(null))},n=function(t,n){g=d((function(){t(e.unstable_now())}),n)},r=function(){f(g),g=-1}}function x(e,t){var n=e.length;e.push(t);e:for(;;){var r=n-1>>>1,o=e[r];if(!(void 0!==o&&0<j(o,t)))break e;e[r]=t,e[n]=o,n=r}}function k(e){return void 0===(e=e[0])?null:e}function S(e){var t=e[0];if(void 0!==t){var n=e.pop();if(n!==t){e[0]=n;e:for(var r=0,o=e.length;r<o;){var i=2*(r+1)-1,a=e[i],l=i+1,s=e[l];if(void 0!==a&&0>j(a,n))void 0!==s&&0>j(s,a)?(e[r]=s,e[l]=n,r=l):(e[r]=a,e[i]=n,r=i);else{if(!(void 0!==s&&0>j(s,n)))break e;e[r]=s,e[l]=n,r=l}}}return t}return null}function j(e,t){var n=e.sortIndex-t.sortIndex;return 0!==n?n:e.id-t.id}var E=[],C=[],A=1,O=null,N=3,_=!1,P=!1,I=!1;function T(e){for(var t=k(C);null!==t;){if(null===t.callback)S(C);else{if(!(t.startTime<=e))break;S(C),t.sortIndex=t.expirationTime,x(E,t)}t=k(C)}}function L(e){if(I=!1,T(e),!P)if(null!==k(E))P=!0,t(M);else{var r=k(C);null!==r&&n(L,r.startTime-e)}}function M(t,o){P=!1,I&&(I=!1,r()),_=!0;var i=N;try{for(T(o),O=k(E);null!==O&&(!(O.expirationTime>o)||t&&!e.unstable_shouldYield());){var a=O.callback;if("function"==typeof a){O.callback=null,N=O.priorityLevel;var l=a(O.expirationTime<=o);o=e.unstable_now(),"function"==typeof l?O.callback=l:O===k(E)&&S(E),T(o)}else S(E);O=k(E)}if(null!==O)var s=!0;else{var c=k(C);null!==c&&n(L,c.startTime-o),s=!1}return s}finally{O=null,N=i,_=!1}}var R=o;e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_continueExecution=function(){P||_||(P=!0,t(M))},e.unstable_getCurrentPriorityLevel=function(){return N},e.unstable_getFirstCallbackNode=function(){return k(E)},e.unstable_next=function(e){switch(N){case 1:case 2:case 3:var t=3;break;default:t=N}var n=N;N=t;try{return e()}finally{N=n}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=R,e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=N;N=e;try{return t()}finally{N=n}},e.unstable_scheduleCallback=function(o,i,a){var l=e.unstable_now();switch("object"==typeof a&&null!==a?a="number"==typeof(a=a.delay)&&0<a?l+a:l:a=l,o){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return o={id:A++,callback:i,priorityLevel:o,startTime:a,expirationTime:s=a+s,sortIndex:-1},a>l?(o.sortIndex=a,x(C,o),null===k(E)&&o===k(C)&&(I?r():I=!0,n(L,a-l))):(o.sortIndex=s,x(E,o),P||_||(P=!0,t(M))),o},e.unstable_wrapCallback=function(e){var t=N;return function(){var n=N;N=t;try{return e.apply(this,arguments)}finally{N=n}}}}(re),ne.exports=re;var oe=ne.exports,ie=W,ae=c,le=oe;function se(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}if(!ie)throw Error(se(227));var ce=new Set,ue={};function de(e,t){fe(e,t),fe(e+"Capture",t)}function fe(e,t){for(ue[e]=t,e=0;e<t.length;e++)ce.add(t[e])}var pe=!("undefined"==typeof window||void 0===window.document||void 0===window.document.createElement),me=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,he=Object.prototype.hasOwnProperty,ge={},ve={};function ye(e,t,n,r,o,i,a){this.acceptsBooleans=2===t||3===t||4===t,this.attributeName=r,this.attributeNamespace=o,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=i,this.removeEmptyString=a}var be={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach((function(e){be[e]=new ye(e,0,!1,e,null,!1,!1)})),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach((function(e){var t=e[0];be[t]=new ye(t,1,!1,e[1],null,!1,!1)})),["contentEditable","draggable","spellCheck","value"].forEach((function(e){be[e]=new ye(e,2,!1,e.toLowerCase(),null,!1,!1)})),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach((function(e){be[e]=new ye(e,2,!1,e,null,!1,!1)})),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach((function(e){be[e]=new ye(e,3,!1,e.toLowerCase(),null,!1,!1)})),["checked","multiple","muted","selected"].forEach((function(e){be[e]=new ye(e,3,!0,e,null,!1,!1)})),["capture","download"].forEach((function(e){be[e]=new ye(e,4,!1,e,null,!1,!1)})),["cols","rows","size","span"].forEach((function(e){be[e]=new ye(e,6,!1,e,null,!1,!1)})),["rowSpan","start"].forEach((function(e){be[e]=new ye(e,5,!1,e.toLowerCase(),null,!1,!1)}));var we=/[\-:]([a-z])/g;function xe(e){return e[1].toUpperCase()}function ke(e,t,n,r){var o=be.hasOwnProperty(t)?be[t]:null;(null!==o?0===o.type:!r&&(2<t.length&&("o"===t[0]||"O"===t[0])&&("n"===t[1]||"N"===t[1])))||(function(e,t,n,r){if(null==t||function(e,t,n,r){if(null!==n&&0===n.type)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return!r&&(null!==n?!n.acceptsBooleans:"data-"!==(e=e.toLowerCase().slice(0,5))&&"aria-"!==e);default:return!1}}(e,t,n,r))return!0;if(r)return!1;if(null!==n)switch(n.type){case 3:return!t;case 4:return!1===t;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}(t,n,o,r)&&(n=null),r||null===o?function(e){return!!he.call(ve,e)||!he.call(ge,e)&&(me.test(e)?ve[e]=!0:(ge[e]=!0,!1))}(t)&&(null===n?e.removeAttribute(t):e.setAttribute(t,""+n)):o.mustUseProperty?e[o.propertyName]=null===n?3!==o.type&&"":n:(t=o.attributeName,r=o.attributeNamespace,null===n?e.removeAttribute(t):(n=3===(o=o.type)||4===o&&!0===n?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach((function(e){var t=e.replace(we,xe);be[t]=new ye(t,1,!1,e,null,!1,!1)})),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach((function(e){var t=e.replace(we,xe);be[t]=new ye(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)})),["xml:base","xml:lang","xml:space"].forEach((function(e){var t=e.replace(we,xe);be[t]=new ye(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)})),["tabIndex","crossOrigin"].forEach((function(e){be[e]=new ye(e,1,!1,e.toLowerCase(),null,!1,!1)})),be.xlinkHref=new ye("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach((function(e){be[e]=new ye(e,1,!1,e.toLowerCase(),null,!0,!0)}));var Se=ie.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,je=60103,Ee=60106,Ce=60107,Ae=60108,Oe=60114,Ne=60109,_e=60110,Pe=60112,Ie=60113,Te=60120,Le=60115,Me=60116,Re=60121,ze=60128,$e=60129,De=60130,Be=60131;if("function"==typeof Symbol&&Symbol.for){var Fe=Symbol.for;je=Fe("react.element"),Ee=Fe("react.portal"),Ce=Fe("react.fragment"),Ae=Fe("react.strict_mode"),Oe=Fe("react.profiler"),Ne=Fe("react.provider"),_e=Fe("react.context"),Pe=Fe("react.forward_ref"),Ie=Fe("react.suspense"),Te=Fe("react.suspense_list"),Le=Fe("react.memo"),Me=Fe("react.lazy"),Re=Fe("react.block"),Fe("react.scope"),ze=Fe("react.opaque.id"),$e=Fe("react.debug_trace_mode"),De=Fe("react.offscreen"),Be=Fe("react.legacy_hidden")}var Ue,We="function"==typeof Symbol&&Symbol.iterator;function Ve(e){return null===e||"object"!=typeof e?null:"function"==typeof(e=We&&e[We]||e["@@iterator"])?e:null}function He(e){if(void 0===Ue)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);Ue=t&&t[1]||""}return"\n"+Ue+e}var qe=!1;function Ye(e,t){if(!e||qe)return"";qe=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),"object"==typeof Reflect&&Reflect.construct){try{Reflect.construct(t,[])}catch(s){var r=s}Reflect.construct(e,[],t)}else{try{t.call()}catch(s){r=s}e.call(t.prototype)}else{try{throw Error()}catch(s){r=s}e()}}catch(s){if(s&&r&&"string"==typeof s.stack){for(var o=s.stack.split("\n"),i=r.stack.split("\n"),a=o.length-1,l=i.length-1;1<=a&&0<=l&&o[a]!==i[l];)l--;for(;1<=a&&0<=l;a--,l--)if(o[a]!==i[l]){if(1!==a||1!==l)do{if(a--,0>--l||o[a]!==i[l])return"\n"+o[a].replace(" at new "," at ")}while(1<=a&&0<=l);break}}}finally{qe=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?He(e):""}function Je(e){switch(e.tag){case 5:return He(e.type);case 16:return He("Lazy");case 13:return He("Suspense");case 19:return He("SuspenseList");case 0:case 2:case 15:return e=Ye(e.type,!1);case 11:return e=Ye(e.type.render,!1);case 22:return e=Ye(e.type._render,!1);case 1:return e=Ye(e.type,!0);default:return""}}function Ge(e){if(null==e)return null;if("function"==typeof e)return e.displayName||e.name||null;if("string"==typeof e)return e;switch(e){case Ce:return"Fragment";case Ee:return"Portal";case Oe:return"Profiler";case Ae:return"StrictMode";case Ie:return"Suspense";case Te:return"SuspenseList"}if("object"==typeof e)switch(e.$$typeof){case _e:return(e.displayName||"Context")+".Consumer";case Ne:return(e._context.displayName||"Context")+".Provider";case Pe:var t=e.render;return t=t.displayName||t.name||"",e.displayName||(""!==t?"ForwardRef("+t+")":"ForwardRef");case Le:return Ge(e.type);case Re:return Ge(e._render);case Me:t=e._payload,e=e._init;try{return Ge(e(t))}catch(n){}}return null}function Qe(e){switch(typeof e){case"boolean":case"number":case"object":case"string":case"undefined":return e;default:return""}}function Ke(e){var t=e.type;return(e=e.nodeName)&&"input"===e.toLowerCase()&&("checkbox"===t||"radio"===t)}function Xe(e){e._valueTracker||(e._valueTracker=function(e){var t=Ke(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&void 0!==n&&"function"==typeof n.get&&"function"==typeof n.set){var o=n.get,i=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return o.call(this)},set:function(e){r=""+e,i.call(this,e)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(e){r=""+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}(e))}function Ze(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=Ke(e)?e.checked?"true":"false":e.value),(e=r)!==n&&(t.setValue(e),!0)}function et(e){if(void 0===(e=e||("undefined"!=typeof document?document:void 0)))return null;try{return e.activeElement||e.body}catch(t){return e.body}}function tt(e,t){var n=t.checked;return ae({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=n?n:e._wrapperState.initialChecked})}function nt(e,t){var n=null==t.defaultValue?"":t.defaultValue,r=null!=t.checked?t.checked:t.defaultChecked;n=Qe(null!=t.value?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:"checkbox"===t.type||"radio"===t.type?null!=t.checked:null!=t.value}}function rt(e,t){null!=(t=t.checked)&&ke(e,"checked",t,!1)}function ot(e,t){rt(e,t);var n=Qe(t.value),r=t.type;if(null!=n)"number"===r?(0===n&&""===e.value||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if("submit"===r||"reset"===r)return void e.removeAttribute("value");t.hasOwnProperty("value")?at(e,t.type,n):t.hasOwnProperty("defaultValue")&&at(e,t.type,Qe(t.defaultValue)),null==t.checked&&null!=t.defaultChecked&&(e.defaultChecked=!!t.defaultChecked)}function it(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!("submit"!==r&&"reset"!==r||void 0!==t.value&&null!==t.value))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}""!==(n=e.name)&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,""!==n&&(e.name=n)}function at(e,t,n){"number"===t&&et(e.ownerDocument)===e||(null==n?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}function lt(e,t){return e=ae({children:void 0},t),(t=function(e){var t="";return ie.Children.forEach(e,(function(e){null!=e&&(t+=e)})),t}(t.children))&&(e.children=t),e}function st(e,t,n,r){if(e=e.options,t){t={};for(var o=0;o<n.length;o++)t["$"+n[o]]=!0;for(n=0;n<e.length;n++)o=t.hasOwnProperty("$"+e[n].value),e[n].selected!==o&&(e[n].selected=o),o&&r&&(e[n].defaultSelected=!0)}else{for(n=""+Qe(n),t=null,o=0;o<e.length;o++){if(e[o].value===n)return e[o].selected=!0,void(r&&(e[o].defaultSelected=!0));null!==t||e[o].disabled||(t=e[o])}null!==t&&(t.selected=!0)}}function ct(e,t){if(null!=t.dangerouslySetInnerHTML)throw Error(se(91));return ae({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function ut(e,t){var n=t.value;if(null==n){if(n=t.children,t=t.defaultValue,null!=n){if(null!=t)throw Error(se(92));if(Array.isArray(n)){if(!(1>=n.length))throw Error(se(93));n=n[0]}t=n}null==t&&(t=""),n=t}e._wrapperState={initialValue:Qe(n)}}function dt(e,t){var n=Qe(t.value),r=Qe(t.defaultValue);null!=n&&((n=""+n)!==e.value&&(e.value=n),null==t.defaultValue&&e.defaultValue!==n&&(e.defaultValue=n)),null!=r&&(e.defaultValue=""+r)}function ft(e){var t=e.textContent;t===e._wrapperState.initialValue&&""!==t&&null!==t&&(e.value=t)}var pt={html:"http://www.w3.org/1999/xhtml",mathml:"http://www.w3.org/1998/Math/MathML",svg:"http://www.w3.org/2000/svg"};function mt(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function ht(e,t){return null==e||"http://www.w3.org/1999/xhtml"===e?mt(t):"http://www.w3.org/2000/svg"===e&&"foreignObject"===t?"http://www.w3.org/1999/xhtml":e}var gt,vt,yt=(vt=function(e,t){if(e.namespaceURI!==pt.svg||"innerHTML"in e)e.innerHTML=t;else{for((gt=gt||document.createElement("div")).innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=gt.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}},"undefined"!=typeof MSApp&&MSApp.execUnsafeLocalFunction?function(e,t,n,r){MSApp.execUnsafeLocalFunction((function(){return vt(e,t)}))}:vt);function bt(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&3===n.nodeType)return void(n.nodeValue=t)}e.textContent=t}var wt={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},xt=["Webkit","ms","Moz","O"];function kt(e,t,n){return null==t||"boolean"==typeof t||""===t?"":n||"number"!=typeof t||0===t||wt.hasOwnProperty(e)&&wt[e]?(""+t).trim():t+"px"}function St(e,t){for(var n in e=e.style,t)if(t.hasOwnProperty(n)){var r=0===n.indexOf("--"),o=kt(n,t[n],r);"float"===n&&(n="cssFloat"),r?e.setProperty(n,o):e[n]=o}}Object.keys(wt).forEach((function(e){xt.forEach((function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),wt[t]=wt[e]}))}));var jt=ae({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Et(e,t){if(t){if(jt[e]&&(null!=t.children||null!=t.dangerouslySetInnerHTML))throw Error(se(137,e));if(null!=t.dangerouslySetInnerHTML){if(null!=t.children)throw Error(se(60));if("object"!=typeof t.dangerouslySetInnerHTML||!("__html"in t.dangerouslySetInnerHTML))throw Error(se(61))}if(null!=t.style&&"object"!=typeof t.style)throw Error(se(62))}}function Ct(e,t){if(-1===e.indexOf("-"))return"string"==typeof t.is;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}function At(e){return(e=e.target||e.srcElement||window).correspondingUseElement&&(e=e.correspondingUseElement),3===e.nodeType?e.parentNode:e}var Ot=null,Nt=null,_t=null;function Pt(e){if(e=ii(e)){if("function"!=typeof Ot)throw Error(se(280));var t=e.stateNode;t&&(t=li(t),Ot(e.stateNode,e.type,t))}}function It(e){Nt?_t?_t.push(e):_t=[e]:Nt=e}function Tt(){if(Nt){var e=Nt,t=_t;if(_t=Nt=null,Pt(e),t)for(e=0;e<t.length;e++)Pt(t[e])}}function Lt(e,t){return e(t)}function Mt(e,t,n,r,o){return e(t,n,r,o)}function Rt(){}var zt=Lt,$t=!1,Dt=!1;function Bt(){null===Nt&&null===_t||(Rt(),Tt())}function Ft(e,t){var n=e.stateNode;if(null===n)return null;var r=li(n);if(null===r)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(r=!("button"===(e=e.type)||"input"===e||"select"===e||"textarea"===e)),e=!r;break e;default:e=!1}if(e)return null;if(n&&"function"!=typeof n)throw Error(se(231,t,typeof n));return n}var Ut=!1;if(pe)try{var Wt={};Object.defineProperty(Wt,"passive",{get:function(){Ut=!0}}),window.addEventListener("test",Wt,Wt),window.removeEventListener("test",Wt,Wt)}catch(vt){Ut=!1}function Vt(e,t,n,r,o,i,a,l,s){var c=Array.prototype.slice.call(arguments,3);try{t.apply(n,c)}catch(u){this.onError(u)}}var Ht=!1,qt=null,Yt=!1,Jt=null,Gt={onError:function(e){Ht=!0,qt=e}};function Qt(e,t,n,r,o,i,a,l,s){Ht=!1,qt=null,Vt.apply(Gt,arguments)}function Kt(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do{0!=(1026&(t=e).flags)&&(n=t.return),e=t.return}while(e)}return 3===t.tag?n:null}function Xt(e){if(13===e.tag){var t=e.memoizedState;if(null===t&&(null!==(e=e.alternate)&&(t=e.memoizedState)),null!==t)return t.dehydrated}return null}function Zt(e){if(Kt(e)!==e)throw Error(se(188))}function en(e){if(e=function(e){var t=e.alternate;if(!t){if(null===(t=Kt(e)))throw Error(se(188));return t!==e?null:e}for(var n=e,r=t;;){var o=n.return;if(null===o)break;var i=o.alternate;if(null===i){if(null!==(r=o.return)){n=r;continue}break}if(o.child===i.child){for(i=o.child;i;){if(i===n)return Zt(o),e;if(i===r)return Zt(o),t;i=i.sibling}throw Error(se(188))}if(n.return!==r.return)n=o,r=i;else{for(var a=!1,l=o.child;l;){if(l===n){a=!0,n=o,r=i;break}if(l===r){a=!0,r=o,n=i;break}l=l.sibling}if(!a){for(l=i.child;l;){if(l===n){a=!0,n=i,r=o;break}if(l===r){a=!0,r=i,n=o;break}l=l.sibling}if(!a)throw Error(se(189))}}if(n.alternate!==r)throw Error(se(190))}if(3!==n.tag)throw Error(se(188));return n.stateNode.current===n?e:t}(e),!e)return null;for(var t=e;;){if(5===t.tag||6===t.tag)return t;if(t.child)t.child.return=t,t=t.child;else{if(t===e)break;for(;!t.sibling;){if(!t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}}return null}function tn(e,t){for(var n=e.alternate;null!==t;){if(t===e||t===n)return!0;t=t.return}return!1}var nn,rn,on,an,ln=!1,sn=[],cn=null,un=null,dn=null,fn=new Map,pn=new Map,mn=[],hn="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function gn(e,t,n,r,o){return{blockedOn:e,domEventName:t,eventSystemFlags:16|n,nativeEvent:o,targetContainers:[r]}}function vn(e,t){switch(e){case"focusin":case"focusout":cn=null;break;case"dragenter":case"dragleave":un=null;break;case"mouseover":case"mouseout":dn=null;break;case"pointerover":case"pointerout":fn.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":pn.delete(t.pointerId)}}function yn(e,t,n,r,o,i){return null===e||e.nativeEvent!==i?(e=gn(t,n,r,o,i),null!==t&&(null!==(t=ii(t))&&rn(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,null!==o&&-1===t.indexOf(o)&&t.push(o),e)}function bn(e){var t=oi(e.target);if(null!==t){var n=Kt(t);if(null!==n)if(13===(t=n.tag)){if(null!==(t=Xt(n)))return e.blockedOn=t,void an(e.lanePriority,(function(){le.unstable_runWithPriority(e.priority,(function(){on(n)}))}))}else if(3===t&&n.stateNode.hydrate)return void(e.blockedOn=3===n.tag?n.stateNode.containerInfo:null)}e.blockedOn=null}function wn(e){if(null!==e.blockedOn)return!1;for(var t=e.targetContainers;0<t.length;){var n=tr(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(null!==n)return null!==(t=ii(n))&&rn(t),e.blockedOn=n,!1;t.shift()}return!0}function xn(e,t,n){wn(e)&&n.delete(t)}function kn(){for(ln=!1;0<sn.length;){var e=sn[0];if(null!==e.blockedOn){null!==(e=ii(e.blockedOn))&&nn(e);break}for(var t=e.targetContainers;0<t.length;){var n=tr(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(null!==n){e.blockedOn=n;break}t.shift()}null===e.blockedOn&&sn.shift()}null!==cn&&wn(cn)&&(cn=null),null!==un&&wn(un)&&(un=null),null!==dn&&wn(dn)&&(dn=null),fn.forEach(xn),pn.forEach(xn)}function Sn(e,t){e.blockedOn===t&&(e.blockedOn=null,ln||(ln=!0,le.unstable_scheduleCallback(le.unstable_NormalPriority,kn)))}function jn(e){function t(t){return Sn(t,e)}if(0<sn.length){Sn(sn[0],e);for(var n=1;n<sn.length;n++){var r=sn[n];r.blockedOn===e&&(r.blockedOn=null)}}for(null!==cn&&Sn(cn,e),null!==un&&Sn(un,e),null!==dn&&Sn(dn,e),fn.forEach(t),pn.forEach(t),n=0;n<mn.length;n++)(r=mn[n]).blockedOn===e&&(r.blockedOn=null);for(;0<mn.length&&null===(n=mn[0]).blockedOn;)bn(n),null===n.blockedOn&&mn.shift()}function En(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Cn={animationend:En("Animation","AnimationEnd"),animationiteration:En("Animation","AnimationIteration"),animationstart:En("Animation","AnimationStart"),transitionend:En("Transition","TransitionEnd")},An={},On={};function Nn(e){if(An[e])return An[e];if(!Cn[e])return e;var t,n=Cn[e];for(t in n)if(n.hasOwnProperty(t)&&t in On)return An[e]=n[t];return e}pe&&(On=document.createElement("div").style,"AnimationEvent"in window||(delete Cn.animationend.animation,delete Cn.animationiteration.animation,delete Cn.animationstart.animation),"TransitionEvent"in window||delete Cn.transitionend.transition);var _n=Nn("animationend"),Pn=Nn("animationiteration"),In=Nn("animationstart"),Tn=Nn("transitionend"),Ln=new Map,Mn=new Map,Rn=["abort","abort",_n,"animationEnd",Pn,"animationIteration",In,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart","lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",Tn,"transitionEnd","waiting","waiting"];function zn(e,t){for(var n=0;n<e.length;n+=2){var r=e[n],o=e[n+1];o="on"+(o[0].toUpperCase()+o.slice(1)),Mn.set(r,t),Ln.set(r,o),de(o,[r])}}(0,le.unstable_now)();var $n=8;function Dn(e){if(0!=(1&e))return $n=15,1;if(0!=(2&e))return $n=14,2;if(0!=(4&e))return $n=13,4;var t=24&e;return 0!==t?($n=12,t):0!=(32&e)?($n=11,32):0!==(t=192&e)?($n=10,t):0!=(256&e)?($n=9,256):0!==(t=3584&e)?($n=8,t):0!=(4096&e)?($n=7,4096):0!==(t=4186112&e)?($n=6,t):0!==(t=62914560&e)?($n=5,t):67108864&e?($n=4,67108864):0!=(134217728&e)?($n=3,134217728):0!==(t=805306368&e)?($n=2,t):0!=(1073741824&e)?($n=1,1073741824):($n=8,e)}function Bn(e,t){var n=e.pendingLanes;if(0===n)return $n=0;var r=0,o=0,i=e.expiredLanes,a=e.suspendedLanes,l=e.pingedLanes;if(0!==i)r=i,o=$n=15;else if(0!==(i=134217727&n)){var s=i&~a;0!==s?(r=Dn(s),o=$n):0!==(l&=i)&&(r=Dn(l),o=$n)}else 0!==(i=n&~a)?(r=Dn(i),o=$n):0!==l&&(r=Dn(l),o=$n);if(0===r)return 0;if(r=n&((0>(r=31-qn(r))?0:1<<r)<<1)-1,0!==t&&t!==r&&0==(t&a)){if(Dn(t),o<=$n)return t;$n=o}if(0!==(t=e.entangledLanes))for(e=e.entanglements,t&=r;0<t;)o=1<<(n=31-qn(t)),r|=e[n],t&=~o;return r}function Fn(e){return 0!==(e=-1073741825&e.pendingLanes)?e:1073741824&e?1073741824:0}function Un(e,t){switch(e){case 15:return 1;case 14:return 2;case 12:return 0===(e=Wn(24&~t))?Un(10,t):e;case 10:return 0===(e=Wn(192&~t))?Un(8,t):e;case 8:return 0===(e=Wn(3584&~t))&&(0===(e=Wn(4186112&~t))&&(e=512)),e;case 2:return 0===(t=Wn(805306368&~t))&&(t=268435456),t}throw Error(se(358,e))}function Wn(e){return e&-e}function Vn(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Hn(e,t,n){e.pendingLanes|=t;var r=t-1;e.suspendedLanes&=r,e.pingedLanes&=r,(e=e.eventTimes)[t=31-qn(t)]=n}var qn=Math.clz32?Math.clz32:function(e){return 0===e?32:31-(Yn(e)/Jn|0)|0},Yn=Math.log,Jn=Math.LN2;var Gn=le.unstable_UserBlockingPriority,Qn=le.unstable_runWithPriority,Kn=!0;function Xn(e,t,n,r){$t||Rt();var o=er,i=$t;$t=!0;try{Mt(o,e,t,n,r)}finally{($t=i)||Bt()}}function Zn(e,t,n,r){Qn(Gn,er.bind(null,e,t,n,r))}function er(e,t,n,r){var o;if(Kn)if((o=0==(4&t))&&0<sn.length&&-1<hn.indexOf(e))e=gn(null,e,t,n,r),sn.push(e);else{var i=tr(e,t,n,r);if(null===i)o&&vn(e,r);else{if(o){if(-1<hn.indexOf(e))return e=gn(i,e,t,n,r),void sn.push(e);if(function(e,t,n,r,o){switch(t){case"focusin":return cn=yn(cn,e,t,n,r,o),!0;case"dragenter":return un=yn(un,e,t,n,r,o),!0;case"mouseover":return dn=yn(dn,e,t,n,r,o),!0;case"pointerover":var i=o.pointerId;return fn.set(i,yn(fn.get(i)||null,e,t,n,r,o)),!0;case"gotpointercapture":return i=o.pointerId,pn.set(i,yn(pn.get(i)||null,e,t,n,r,o)),!0}return!1}(i,e,t,n,r))return;vn(e,r)}zo(e,t,r,null,n)}}}function tr(e,t,n,r){var o=At(r);if(null!==(o=oi(o))){var i=Kt(o);if(null===i)o=null;else{var a=i.tag;if(13===a){if(null!==(o=Xt(i)))return o;o=null}else if(3===a){if(i.stateNode.hydrate)return 3===i.tag?i.stateNode.containerInfo:null;o=null}else i!==o&&(o=null)}}return zo(e,t,r,o,n),null}var nr=null,rr=null,or=null;function ir(){if(or)return or;var e,t,n=rr,r=n.length,o="value"in nr?nr.value:nr.textContent,i=o.length;for(e=0;e<r&&n[e]===o[e];e++);var a=r-e;for(t=1;t<=a&&n[r-t]===o[i-t];t++);return or=o.slice(e,1<t?1-t:void 0)}function ar(e){var t=e.keyCode;return"charCode"in e?0===(e=e.charCode)&&13===t&&(e=13):e=t,10===e&&(e=13),32<=e||13===e?e:0}function lr(){return!0}function sr(){return!1}function cr(e){function t(t,n,r,o,i){for(var a in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=o,this.target=i,this.currentTarget=null,e)e.hasOwnProperty(a)&&(t=e[a],this[a]=t?t(o):o[a]);return this.isDefaultPrevented=(null!=o.defaultPrevented?o.defaultPrevented:!1===o.returnValue)?lr:sr,this.isPropagationStopped=sr,this}return ae(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():"unknown"!=typeof e.returnValue&&(e.returnValue=!1),this.isDefaultPrevented=lr)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():"unknown"!=typeof e.cancelBubble&&(e.cancelBubble=!0),this.isPropagationStopped=lr)},persist:function(){},isPersistent:lr}),t}var ur,dr,fr,pr={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},mr=cr(pr),hr=ae({},pr,{view:0,detail:0}),gr=cr(hr),vr=ae({},hr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Nr,button:0,buttons:0,relatedTarget:function(e){return void 0===e.relatedTarget?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==fr&&(fr&&"mousemove"===e.type?(ur=e.screenX-fr.screenX,dr=e.screenY-fr.screenY):dr=ur=0,fr=e),ur)},movementY:function(e){return"movementY"in e?e.movementY:dr}}),yr=cr(vr),br=cr(ae({},vr,{dataTransfer:0})),wr=cr(ae({},hr,{relatedTarget:0})),xr=cr(ae({},pr,{animationName:0,elapsedTime:0,pseudoElement:0})),kr=ae({},pr,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Sr=cr(kr),jr=cr(ae({},pr,{data:0})),Er={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Cr={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Ar={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Or(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):!!(e=Ar[e])&&!!t[e]}function Nr(){return Or}var _r=ae({},hr,{key:function(e){if(e.key){var t=Er[e.key]||e.key;if("Unidentified"!==t)return t}return"keypress"===e.type?13===(e=ar(e))?"Enter":String.fromCharCode(e):"keydown"===e.type||"keyup"===e.type?Cr[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Nr,charCode:function(e){return"keypress"===e.type?ar(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?ar(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}}),Pr=cr(_r),Ir=cr(ae({},vr,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),Tr=cr(ae({},hr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Nr})),Lr=cr(ae({},pr,{propertyName:0,elapsedTime:0,pseudoElement:0})),Mr=ae({},vr,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Rr=cr(Mr),zr=[9,13,27,32],$r=pe&&"CompositionEvent"in window,Dr=null;pe&&"documentMode"in document&&(Dr=document.documentMode);var Br=pe&&"TextEvent"in window&&!Dr,Fr=pe&&(!$r||Dr&&8<Dr&&11>=Dr),Ur=String.fromCharCode(32),Wr=!1;function Vr(e,t){switch(e){case"keyup":return-1!==zr.indexOf(t.keyCode);case"keydown":return 229!==t.keyCode;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Hr(e){return"object"==typeof(e=e.detail)&&"data"in e?e.data:null}var qr=!1;var Yr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Jr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return"input"===t?!!Yr[e.type]:"textarea"===t}function Gr(e,t,n,r){It(r),0<(t=Do(t,"onChange")).length&&(n=new mr("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var Qr=null,Kr=null;function Xr(e){Po(e,0)}function Zr(e){if(Ze(ai(e)))return e}function eo(e,t){if("change"===e)return t}var to=!1;if(pe){var no;if(pe){var ro="oninput"in document;if(!ro){var oo=document.createElement("div");oo.setAttribute("oninput","return;"),ro="function"==typeof oo.oninput}no=ro}else no=!1;to=no&&(!document.documentMode||9<document.documentMode)}function io(){Qr&&(Qr.detachEvent("onpropertychange",ao),Kr=Qr=null)}function ao(e){if("value"===e.propertyName&&Zr(Kr)){var t=[];if(Gr(t,Kr,e,At(e)),e=Xr,$t)e(t);else{$t=!0;try{Lt(e,t)}finally{$t=!1,Bt()}}}}function lo(e,t,n){"focusin"===e?(io(),Kr=n,(Qr=t).attachEvent("onpropertychange",ao)):"focusout"===e&&io()}function so(e){if("selectionchange"===e||"keyup"===e||"keydown"===e)return Zr(Kr)}function co(e,t){if("click"===e)return Zr(t)}function uo(e,t){if("input"===e||"change"===e)return Zr(t)}var fo="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},po=Object.prototype.hasOwnProperty;function mo(e,t){if(fo(e,t))return!0;if("object"!=typeof e||null===e||"object"!=typeof t||null===t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++)if(!po.call(t,n[r])||!fo(e[n[r]],t[n[r]]))return!1;return!0}function ho(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function go(e,t){var n,r=ho(e);for(e=0;r;){if(3===r.nodeType){if(n=e+r.textContent.length,e<=t&&n>=t)return{node:r,offset:t-e};e=n}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=ho(r)}}function vo(e,t){return!(!e||!t)&&(e===t||(!e||3!==e.nodeType)&&(t&&3===t.nodeType?vo(e,t.parentNode):"contains"in e?e.contains(t):!!e.compareDocumentPosition&&!!(16&e.compareDocumentPosition(t))))}function yo(){for(var e=window,t=et();t instanceof e.HTMLIFrameElement;){try{var n="string"==typeof t.contentWindow.location.href}catch(r){n=!1}if(!n)break;t=et((e=t.contentWindow).document)}return t}function bo(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&("input"===t&&("text"===e.type||"search"===e.type||"tel"===e.type||"url"===e.type||"password"===e.type)||"textarea"===t||"true"===e.contentEditable)}var wo=pe&&"documentMode"in document&&11>=document.documentMode,xo=null,ko=null,So=null,jo=!1;function Eo(e,t,n){var r=n.window===n?n.document:9===n.nodeType?n:n.ownerDocument;jo||null==xo||xo!==et(r)||("selectionStart"in(r=xo)&&bo(r)?r={start:r.selectionStart,end:r.selectionEnd}:r={anchorNode:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection()).anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset},So&&mo(So,r)||(So=r,0<(r=Do(ko,"onSelect")).length&&(t=new mr("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=xo)))}zn("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),0),zn("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1),zn(Rn,2);for(var Co="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),Ao=0;Ao<Co.length;Ao++)Mn.set(Co[Ao],0);fe("onMouseEnter",["mouseout","mouseover"]),fe("onMouseLeave",["mouseout","mouseover"]),fe("onPointerEnter",["pointerout","pointerover"]),fe("onPointerLeave",["pointerout","pointerover"]),de("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),de("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),de("onBeforeInput",["compositionend","keypress","textInput","paste"]),de("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),de("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),de("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Oo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),No=new Set("cancel close invalid load scroll toggle".split(" ").concat(Oo));function _o(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,function(e,t,n,r,o,i,a,l,s){if(Qt.apply(this,arguments),Ht){if(!Ht)throw Error(se(198));var c=qt;Ht=!1,qt=null,Yt||(Yt=!0,Jt=c)}}(r,t,void 0,e),e.currentTarget=null}function Po(e,t){t=0!=(4&t);for(var n=0;n<e.length;n++){var r=e[n],o=r.event;r=r.listeners;e:{var i=void 0;if(t)for(var a=r.length-1;0<=a;a--){var l=r[a],s=l.instance,c=l.currentTarget;if(l=l.listener,s!==i&&o.isPropagationStopped())break e;_o(o,l,c),i=s}else for(a=0;a<r.length;a++){if(s=(l=r[a]).instance,c=l.currentTarget,l=l.listener,s!==i&&o.isPropagationStopped())break e;_o(o,l,c),i=s}}}if(Yt)throw e=Jt,Yt=!1,Jt=null,e}function Io(e,t){var n=si(t),r=e+"__bubble";n.has(r)||(Ro(t,e,2,!1),n.add(r))}var To="_reactListening"+Math.random().toString(36).slice(2);function Lo(e){e[To]||(e[To]=!0,ce.forEach((function(t){No.has(t)||Mo(t,!1,e,null),Mo(t,!0,e,null)})))}function Mo(e,t,n,r){var o=4<arguments.length&&void 0!==arguments[4]?arguments[4]:0,i=n;if("selectionchange"===e&&9!==n.nodeType&&(i=n.ownerDocument),null!==r&&!t&&No.has(e)){if("scroll"!==e)return;o|=2,i=r}var a=si(i),l=e+"__"+(t?"capture":"bubble");a.has(l)||(t&&(o|=4),Ro(i,e,o,t),a.add(l))}function Ro(e,t,n,r){var o=Mn.get(t);switch(void 0===o?2:o){case 0:o=Xn;break;case 1:o=Zn;break;default:o=er}n=o.bind(null,t,n,e),o=void 0,!Ut||"touchstart"!==t&&"touchmove"!==t&&"wheel"!==t||(o=!0),r?void 0!==o?e.addEventListener(t,n,{capture:!0,passive:o}):e.addEventListener(t,n,!0):void 0!==o?e.addEventListener(t,n,{passive:o}):e.addEventListener(t,n,!1)}function zo(e,t,n,r,o){var i=r;if(0==(1&t)&&0==(2&t)&&null!==r)e:for(;;){if(null===r)return;var a=r.tag;if(3===a||4===a){var l=r.stateNode.containerInfo;if(l===o||8===l.nodeType&&l.parentNode===o)break;if(4===a)for(a=r.return;null!==a;){var s=a.tag;if((3===s||4===s)&&((s=a.stateNode.containerInfo)===o||8===s.nodeType&&s.parentNode===o))return;a=a.return}for(;null!==l;){if(null===(a=oi(l)))return;if(5===(s=a.tag)||6===s){r=i=a;continue e}l=l.parentNode}}r=r.return}!function(e,t,n){if(Dt)return e(t,n);Dt=!0;try{return zt(e,t,n)}finally{Dt=!1,Bt()}}((function(){var r=i,o=At(n),a=[];e:{var l=Ln.get(e);if(void 0!==l){var s=mr,c=e;switch(e){case"keypress":if(0===ar(n))break e;case"keydown":case"keyup":s=Pr;break;case"focusin":c="focus",s=wr;break;case"focusout":c="blur",s=wr;break;case"beforeblur":case"afterblur":s=wr;break;case"click":if(2===n.button)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":s=yr;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":s=br;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":s=Tr;break;case _n:case Pn:case In:s=xr;break;case Tn:s=Lr;break;case"scroll":s=gr;break;case"wheel":s=Rr;break;case"copy":case"cut":case"paste":s=Sr;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":s=Ir}var u=0!=(4&t),d=!u&&"scroll"===e,f=u?null!==l?l+"Capture":null:l;u=[];for(var p,m=r;null!==m;){var h=(p=m).stateNode;if(5===p.tag&&null!==h&&(p=h,null!==f&&(null!=(h=Ft(m,f))&&u.push($o(m,h,p)))),d)break;m=m.return}0<u.length&&(l=new s(l,c,null,n,o),a.push({event:l,listeners:u}))}}if(0==(7&t)){if(s="mouseout"===e||"pointerout"===e,(!(l="mouseover"===e||"pointerover"===e)||0!=(16&t)||!(c=n.relatedTarget||n.fromElement)||!oi(c)&&!c[ni])&&(s||l)&&(l=o.window===o?o:(l=o.ownerDocument)?l.defaultView||l.parentWindow:window,s?(s=r,null!==(c=(c=n.relatedTarget||n.toElement)?oi(c):null)&&(c!==(d=Kt(c))||5!==c.tag&&6!==c.tag)&&(c=null)):(s=null,c=r),s!==c)){if(u=yr,h="onMouseLeave",f="onMouseEnter",m="mouse","pointerout"!==e&&"pointerover"!==e||(u=Ir,h="onPointerLeave",f="onPointerEnter",m="pointer"),d=null==s?l:ai(s),p=null==c?l:ai(c),(l=new u(h,m+"leave",s,n,o)).target=d,l.relatedTarget=p,h=null,oi(o)===r&&((u=new u(f,m+"enter",c,n,o)).target=p,u.relatedTarget=d,h=u),d=h,s&&c)e:{for(f=c,m=0,p=u=s;p;p=Bo(p))m++;for(p=0,h=f;h;h=Bo(h))p++;for(;0<m-p;)u=Bo(u),m--;for(;0<p-m;)f=Bo(f),p--;for(;m--;){if(u===f||null!==f&&u===f.alternate)break e;u=Bo(u),f=Bo(f)}u=null}else u=null;null!==s&&Fo(a,l,s,u,!1),null!==c&&null!==d&&Fo(a,d,c,u,!0)}if("select"===(s=(l=r?ai(r):window).nodeName&&l.nodeName.toLowerCase())||"input"===s&&"file"===l.type)var g=eo;else if(Jr(l))if(to)g=uo;else{g=so;var v=lo}else(s=l.nodeName)&&"input"===s.toLowerCase()&&("checkbox"===l.type||"radio"===l.type)&&(g=co);switch(g&&(g=g(e,r))?Gr(a,g,n,o):(v&&v(e,l,r),"focusout"===e&&(v=l._wrapperState)&&v.controlled&&"number"===l.type&&at(l,"number",l.value)),v=r?ai(r):window,e){case"focusin":(Jr(v)||"true"===v.contentEditable)&&(xo=v,ko=r,So=null);break;case"focusout":So=ko=xo=null;break;case"mousedown":jo=!0;break;case"contextmenu":case"mouseup":case"dragend":jo=!1,Eo(a,n,o);break;case"selectionchange":if(wo)break;case"keydown":case"keyup":Eo(a,n,o)}var y;if($r)e:{switch(e){case"compositionstart":var b="onCompositionStart";break e;case"compositionend":b="onCompositionEnd";break e;case"compositionupdate":b="onCompositionUpdate";break e}b=void 0}else qr?Vr(e,n)&&(b="onCompositionEnd"):"keydown"===e&&229===n.keyCode&&(b="onCompositionStart");b&&(Fr&&"ko"!==n.locale&&(qr||"onCompositionStart"!==b?"onCompositionEnd"===b&&qr&&(y=ir()):(rr="value"in(nr=o)?nr.value:nr.textContent,qr=!0)),0<(v=Do(r,b)).length&&(b=new jr(b,e,null,n,o),a.push({event:b,listeners:v}),y?b.data=y:null!==(y=Hr(n))&&(b.data=y))),(y=Br?function(e,t){switch(e){case"compositionend":return Hr(t);case"keypress":return 32!==t.which?null:(Wr=!0,Ur);case"textInput":return(e=t.data)===Ur&&Wr?null:e;default:return null}}(e,n):function(e,t){if(qr)return"compositionend"===e||!$r&&Vr(e,t)?(e=ir(),or=rr=nr=null,qr=!1,e):null;switch(e){case"paste":default:return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Fr&&"ko"!==t.locale?null:t.data}}(e,n))&&(0<(r=Do(r,"onBeforeInput")).length&&(o=new jr("onBeforeInput","beforeinput",null,n,o),a.push({event:o,listeners:r}),o.data=y))}Po(a,t)}))}function $o(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Do(e,t){for(var n=t+"Capture",r=[];null!==e;){var o=e,i=o.stateNode;5===o.tag&&null!==i&&(o=i,null!=(i=Ft(e,n))&&r.unshift($o(e,i,o)),null!=(i=Ft(e,t))&&r.push($o(e,i,o))),e=e.return}return r}function Bo(e){if(null===e)return null;do{e=e.return}while(e&&5!==e.tag);return e||null}function Fo(e,t,n,r,o){for(var i=t._reactName,a=[];null!==n&&n!==r;){var l=n,s=l.alternate,c=l.stateNode;if(null!==s&&s===r)break;5===l.tag&&null!==c&&(l=c,o?null!=(s=Ft(n,i))&&a.unshift($o(n,s,l)):o||null!=(s=Ft(n,i))&&a.push($o(n,s,l))),n=n.return}0!==a.length&&e.push({event:t,listeners:a})}function Uo(){}var Wo=null,Vo=null;function Ho(e,t){switch(e){case"button":case"input":case"select":case"textarea":return!!t.autoFocus}return!1}function qo(e,t){return"textarea"===e||"option"===e||"noscript"===e||"string"==typeof t.children||"number"==typeof t.children||"object"==typeof t.dangerouslySetInnerHTML&&null!==t.dangerouslySetInnerHTML&&null!=t.dangerouslySetInnerHTML.__html}var Yo="function"==typeof setTimeout?setTimeout:void 0,Jo="function"==typeof clearTimeout?clearTimeout:void 0;function Go(e){1===e.nodeType?e.textContent="":9===e.nodeType&&(null!=(e=e.body)&&(e.textContent=""))}function Qo(e){for(;null!=e;e=e.nextSibling){var t=e.nodeType;if(1===t||3===t)break}return e}function Ko(e){e=e.previousSibling;for(var t=0;e;){if(8===e.nodeType){var n=e.data;if("$"===n||"$!"===n||"$?"===n){if(0===t)return e;t--}else"/$"===n&&t++}e=e.previousSibling}return null}var Xo=0;var Zo=Math.random().toString(36).slice(2),ei="__reactFiber$"+Zo,ti="__reactProps$"+Zo,ni="__reactContainer$"+Zo,ri="__reactEvents$"+Zo;function oi(e){var t=e[ei];if(t)return t;for(var n=e.parentNode;n;){if(t=n[ni]||n[ei]){if(n=t.alternate,null!==t.child||null!==n&&null!==n.child)for(e=Ko(e);null!==e;){if(n=e[ei])return n;e=Ko(e)}return t}n=(e=n).parentNode}return null}function ii(e){return!(e=e[ei]||e[ni])||5!==e.tag&&6!==e.tag&&13!==e.tag&&3!==e.tag?null:e}function ai(e){if(5===e.tag||6===e.tag)return e.stateNode;throw Error(se(33))}function li(e){return e[ti]||null}function si(e){var t=e[ri];return void 0===t&&(t=e[ri]=new Set),t}var ci=[],ui=-1;function di(e){return{current:e}}function fi(e){0>ui||(e.current=ci[ui],ci[ui]=null,ui--)}function pi(e,t){ui++,ci[ui]=e.current,e.current=t}var mi={},hi=di(mi),gi=di(!1),vi=mi;function yi(e,t){var n=e.type.contextTypes;if(!n)return mi;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var o,i={};for(o in n)i[o]=t[o];return r&&((e=e.stateNode).__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=i),i}function bi(e){return null!=(e=e.childContextTypes)}function wi(){fi(gi),fi(hi)}function xi(e,t,n){if(hi.current!==mi)throw Error(se(168));pi(hi,t),pi(gi,n)}function ki(e,t,n){var r=e.stateNode;if(e=t.childContextTypes,"function"!=typeof r.getChildContext)return n;for(var o in r=r.getChildContext())if(!(o in e))throw Error(se(108,Ge(t)||"Unknown",o));return ae({},n,r)}function Si(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||mi,vi=hi.current,pi(hi,e),pi(gi,gi.current),!0}function ji(e,t,n){var r=e.stateNode;if(!r)throw Error(se(169));n?(e=ki(e,t,vi),r.__reactInternalMemoizedMergedChildContext=e,fi(gi),fi(hi),pi(hi,e)):fi(gi),pi(gi,n)}var Ei=null,Ci=null,Ai=le.unstable_runWithPriority,Oi=le.unstable_scheduleCallback,Ni=le.unstable_cancelCallback,_i=le.unstable_shouldYield,Pi=le.unstable_requestPaint,Ii=le.unstable_now,Ti=le.unstable_getCurrentPriorityLevel,Li=le.unstable_ImmediatePriority,Mi=le.unstable_UserBlockingPriority,Ri=le.unstable_NormalPriority,zi=le.unstable_LowPriority,$i=le.unstable_IdlePriority,Di={},Bi=void 0!==Pi?Pi:function(){},Fi=null,Ui=null,Wi=!1,Vi=Ii(),Hi=1e4>Vi?Ii:function(){return Ii()-Vi};function qi(){switch(Ti()){case Li:return 99;case Mi:return 98;case Ri:return 97;case zi:return 96;case $i:return 95;default:throw Error(se(332))}}function Yi(e){switch(e){case 99:return Li;case 98:return Mi;case 97:return Ri;case 96:return zi;case 95:return $i;default:throw Error(se(332))}}function Ji(e,t){return e=Yi(e),Ai(e,t)}function Gi(e,t,n){return e=Yi(e),Oi(e,t,n)}function Qi(){if(null!==Ui){var e=Ui;Ui=null,Ni(e)}Ki()}function Ki(){if(!Wi&&null!==Fi){Wi=!0;var e=0;try{var t=Fi;Ji(99,(function(){for(;e<t.length;e++){var n=t[e];do{n=n(!0)}while(null!==n)}})),Fi=null}catch(n){throw null!==Fi&&(Fi=Fi.slice(e+1)),Oi(Li,Qi),n}finally{Wi=!1}}}var Xi=Se.ReactCurrentBatchConfig;function Zi(e,t){if(e&&e.defaultProps){for(var n in t=ae({},t),e=e.defaultProps)void 0===t[n]&&(t[n]=e[n]);return t}return t}var ea=di(null),ta=null,na=null,ra=null;function oa(){ra=na=ta=null}function ia(e){var t=ea.current;fi(ea),e.type._context._currentValue=t}function aa(e,t){for(;null!==e;){var n=e.alternate;if((e.childLanes&t)===t){if(null===n||(n.childLanes&t)===t)break;n.childLanes|=t}else e.childLanes|=t,null!==n&&(n.childLanes|=t);e=e.return}}function la(e,t){ta=e,ra=na=null,null!==(e=e.dependencies)&&null!==e.firstContext&&(0!=(e.lanes&t)&&($l=!0),e.firstContext=null)}function sa(e,t){if(ra!==e&&!1!==t&&0!==t)if("number"==typeof t&&1073741823!==t||(ra=e,t=1073741823),t={context:e,observedBits:t,next:null},null===na){if(null===ta)throw Error(se(308));na=t,ta.dependencies={lanes:0,firstContext:t,responders:null}}else na=na.next=t;return e._currentValue}var ca=!1;function ua(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null},effects:null}}function da(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function fa(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function pa(e,t){if(null!==(e=e.updateQueue)){var n=(e=e.shared).pending;null===n?t.next=t:(t.next=n.next,n.next=t),e.pending=t}}function ma(e,t){var n=e.updateQueue,r=e.alternate;if(null!==r&&n===(r=r.updateQueue)){var o=null,i=null;if(null!==(n=n.firstBaseUpdate)){do{var a={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};null===i?o=i=a:i=i.next=a,n=n.next}while(null!==n);null===i?o=i=t:i=i.next=t}else o=i=t;return n={baseState:r.baseState,firstBaseUpdate:o,lastBaseUpdate:i,shared:r.shared,effects:r.effects},void(e.updateQueue=n)}null===(e=n.lastBaseUpdate)?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function ha(e,t,n,r){var o=e.updateQueue;ca=!1;var i=o.firstBaseUpdate,a=o.lastBaseUpdate,l=o.shared.pending;if(null!==l){o.shared.pending=null;var s=l,c=s.next;s.next=null,null===a?i=c:a.next=c,a=s;var u=e.alternate;if(null!==u){var d=(u=u.updateQueue).lastBaseUpdate;d!==a&&(null===d?u.firstBaseUpdate=c:d.next=c,u.lastBaseUpdate=s)}}if(null!==i){for(d=o.baseState,a=0,u=c=s=null;;){l=i.lane;var f=i.eventTime;if((r&l)===l){null!==u&&(u=u.next={eventTime:f,lane:0,tag:i.tag,payload:i.payload,callback:i.callback,next:null});e:{var p=e,m=i;switch(l=t,f=n,m.tag){case 1:if("function"==typeof(p=m.payload)){d=p.call(f,d,l);break e}d=p;break e;case 3:p.flags=-4097&p.flags|64;case 0:if(null==(l="function"==typeof(p=m.payload)?p.call(f,d,l):p))break e;d=ae({},d,l);break e;case 2:ca=!0}}null!==i.callback&&(e.flags|=32,null===(l=o.effects)?o.effects=[i]:l.push(i))}else f={eventTime:f,lane:l,tag:i.tag,payload:i.payload,callback:i.callback,next:null},null===u?(c=u=f,s=d):u=u.next=f,a|=l;if(null===(i=i.next)){if(null===(l=o.shared.pending))break;i=l.next,l.next=null,o.lastBaseUpdate=l,o.shared.pending=null}}null===u&&(s=d),o.baseState=s,o.firstBaseUpdate=c,o.lastBaseUpdate=u,Ws|=a,e.lanes=a,e.memoizedState=d}}function ga(e,t,n){if(e=t.effects,t.effects=null,null!==e)for(t=0;t<e.length;t++){var r=e[t],o=r.callback;if(null!==o){if(r.callback=null,r=n,"function"!=typeof o)throw Error(se(191,o));o.call(r)}}}var va=(new ie.Component).refs;function ya(e,t,n,r){n=null==(n=n(r,t=e.memoizedState))?t:ae({},t,n),e.memoizedState=n,0===e.lanes&&(e.updateQueue.baseState=n)}var ba={isMounted:function(e){return!!(e=e._reactInternals)&&Kt(e)===e},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=mc(),o=hc(e),i=fa(r,o);i.payload=t,null!=n&&(i.callback=n),pa(e,i),gc(e,o,r)},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=mc(),o=hc(e),i=fa(r,o);i.tag=1,i.payload=t,null!=n&&(i.callback=n),pa(e,i),gc(e,o,r)},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=mc(),r=hc(e),o=fa(n,r);o.tag=2,null!=t&&(o.callback=t),pa(e,o),gc(e,r,n)}};function wa(e,t,n,r,o,i,a){return"function"==typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(r,i,a):!t.prototype||!t.prototype.isPureReactComponent||(!mo(n,r)||!mo(o,i))}function xa(e,t,n){var r=!1,o=mi,i=t.contextType;return"object"==typeof i&&null!==i?i=sa(i):(o=bi(t)?vi:hi.current,i=(r=null!=(r=t.contextTypes))?yi(e,o):mi),t=new t(n,i),e.memoizedState=null!==t.state&&void 0!==t.state?t.state:null,t.updater=ba,e.stateNode=t,t._reactInternals=e,r&&((e=e.stateNode).__reactInternalMemoizedUnmaskedChildContext=o,e.__reactInternalMemoizedMaskedChildContext=i),t}function ka(e,t,n,r){e=t.state,"function"==typeof t.componentWillReceiveProps&&t.componentWillReceiveProps(n,r),"function"==typeof t.UNSAFE_componentWillReceiveProps&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&ba.enqueueReplaceState(t,t.state,null)}function Sa(e,t,n,r){var o=e.stateNode;o.props=n,o.state=e.memoizedState,o.refs=va,ua(e);var i=t.contextType;"object"==typeof i&&null!==i?o.context=sa(i):(i=bi(t)?vi:hi.current,o.context=yi(e,i)),ha(e,n,o,r),o.state=e.memoizedState,"function"==typeof(i=t.getDerivedStateFromProps)&&(ya(e,t,i,n),o.state=e.memoizedState),"function"==typeof t.getDerivedStateFromProps||"function"==typeof o.getSnapshotBeforeUpdate||"function"!=typeof o.UNSAFE_componentWillMount&&"function"!=typeof o.componentWillMount||(t=o.state,"function"==typeof o.componentWillMount&&o.componentWillMount(),"function"==typeof o.UNSAFE_componentWillMount&&o.UNSAFE_componentWillMount(),t!==o.state&&ba.enqueueReplaceState(o,o.state,null),ha(e,n,o,r),o.state=e.memoizedState),"function"==typeof o.componentDidMount&&(e.flags|=4)}var ja=Array.isArray;function Ea(e,t,n){if(null!==(e=n.ref)&&"function"!=typeof e&&"object"!=typeof e){if(n._owner){if(n=n._owner){if(1!==n.tag)throw Error(se(309));var r=n.stateNode}if(!r)throw Error(se(147,e));var o=""+e;return null!==t&&null!==t.ref&&"function"==typeof t.ref&&t.ref._stringRef===o?t.ref:((t=function(e){var t=r.refs;t===va&&(t=r.refs={}),null===e?delete t[o]:t[o]=e})._stringRef=o,t)}if("string"!=typeof e)throw Error(se(284));if(!n._owner)throw Error(se(290,e))}return e}function Ca(e,t){if("textarea"!==e.type)throw Error(se(31,"[object Object]"===Object.prototype.toString.call(t)?"object with keys {"+Object.keys(t).join(", ")+"}":t))}function Aa(e){function t(t,n){if(e){var r=t.lastEffect;null!==r?(r.nextEffect=n,t.lastEffect=n):t.firstEffect=t.lastEffect=n,n.nextEffect=null,n.flags=8}}function n(n,r){if(!e)return null;for(;null!==r;)t(n,r),r=r.sibling;return null}function r(e,t){for(e=new Map;null!==t;)null!==t.key?e.set(t.key,t):e.set(t.index,t),t=t.sibling;return e}function o(e,t){return(e=Jc(e,t)).index=0,e.sibling=null,e}function i(t,n,r){return t.index=r,e?null!==(r=t.alternate)?(r=r.index)<n?(t.flags=2,n):r:(t.flags=2,n):n}function a(t){return e&&null===t.alternate&&(t.flags=2),t}function l(e,t,n,r){return null===t||6!==t.tag?((t=Xc(n,e.mode,r)).return=e,t):((t=o(t,n)).return=e,t)}function s(e,t,n,r){return null!==t&&t.elementType===n.type?((r=o(t,n.props)).ref=Ea(e,t,n),r.return=e,r):((r=Gc(n.type,n.key,n.props,null,e.mode,r)).ref=Ea(e,t,n),r.return=e,r)}function c(e,t,n,r){return null===t||4!==t.tag||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?((t=Zc(n,e.mode,r)).return=e,t):((t=o(t,n.children||[])).return=e,t)}function u(e,t,n,r,i){return null===t||7!==t.tag?((t=Qc(n,e.mode,r,i)).return=e,t):((t=o(t,n)).return=e,t)}function d(e,t,n){if("string"==typeof t||"number"==typeof t)return(t=Xc(""+t,e.mode,n)).return=e,t;if("object"==typeof t&&null!==t){switch(t.$$typeof){case je:return(n=Gc(t.type,t.key,t.props,null,e.mode,n)).ref=Ea(e,null,t),n.return=e,n;case Ee:return(t=Zc(t,e.mode,n)).return=e,t}if(ja(t)||Ve(t))return(t=Qc(t,e.mode,n,null)).return=e,t;Ca(e,t)}return null}function f(e,t,n,r){var o=null!==t?t.key:null;if("string"==typeof n||"number"==typeof n)return null!==o?null:l(e,t,""+n,r);if("object"==typeof n&&null!==n){switch(n.$$typeof){case je:return n.key===o?n.type===Ce?u(e,t,n.props.children,r,o):s(e,t,n,r):null;case Ee:return n.key===o?c(e,t,n,r):null}if(ja(n)||Ve(n))return null!==o?null:u(e,t,n,r,null);Ca(e,n)}return null}function p(e,t,n,r,o){if("string"==typeof r||"number"==typeof r)return l(t,e=e.get(n)||null,""+r,o);if("object"==typeof r&&null!==r){switch(r.$$typeof){case je:return e=e.get(null===r.key?n:r.key)||null,r.type===Ce?u(t,e,r.props.children,o,r.key):s(t,e,r,o);case Ee:return c(t,e=e.get(null===r.key?n:r.key)||null,r,o)}if(ja(r)||Ve(r))return u(t,e=e.get(n)||null,r,o,null);Ca(t,r)}return null}return function(l,s,c,u){var m="object"==typeof c&&null!==c&&c.type===Ce&&null===c.key;m&&(c=c.props.children);var h="object"==typeof c&&null!==c;if(h)switch(c.$$typeof){case je:e:{for(h=c.key,m=s;null!==m;){if(m.key===h){if(7===m.tag){if(c.type===Ce){n(l,m.sibling),(s=o(m,c.props.children)).return=l,l=s;break e}}else if(m.elementType===c.type){n(l,m.sibling),(s=o(m,c.props)).ref=Ea(l,m,c),s.return=l,l=s;break e}n(l,m);break}t(l,m),m=m.sibling}c.type===Ce?((s=Qc(c.props.children,l.mode,u,c.key)).return=l,l=s):((u=Gc(c.type,c.key,c.props,null,l.mode,u)).ref=Ea(l,s,c),u.return=l,l=u)}return a(l);case Ee:e:{for(m=c.key;null!==s;){if(s.key===m){if(4===s.tag&&s.stateNode.containerInfo===c.containerInfo&&s.stateNode.implementation===c.implementation){n(l,s.sibling),(s=o(s,c.children||[])).return=l,l=s;break e}n(l,s);break}t(l,s),s=s.sibling}(s=Zc(c,l.mode,u)).return=l,l=s}return a(l)}if("string"==typeof c||"number"==typeof c)return c=""+c,null!==s&&6===s.tag?(n(l,s.sibling),(s=o(s,c)).return=l,l=s):(n(l,s),(s=Xc(c,l.mode,u)).return=l,l=s),a(l);if(ja(c))return function(o,a,l,s){for(var c=null,u=null,m=a,h=a=0,g=null;null!==m&&h<l.length;h++){m.index>h?(g=m,m=null):g=m.sibling;var v=f(o,m,l[h],s);if(null===v){null===m&&(m=g);break}e&&m&&null===v.alternate&&t(o,m),a=i(v,a,h),null===u?c=v:u.sibling=v,u=v,m=g}if(h===l.length)return n(o,m),c;if(null===m){for(;h<l.length;h++)null!==(m=d(o,l[h],s))&&(a=i(m,a,h),null===u?c=m:u.sibling=m,u=m);return c}for(m=r(o,m);h<l.length;h++)null!==(g=p(m,o,h,l[h],s))&&(e&&null!==g.alternate&&m.delete(null===g.key?h:g.key),a=i(g,a,h),null===u?c=g:u.sibling=g,u=g);return e&&m.forEach((function(e){return t(o,e)})),c}(l,s,c,u);if(Ve(c))return function(o,a,l,s){var c=Ve(l);if("function"!=typeof c)throw Error(se(150));if(null==(l=c.call(l)))throw Error(se(151));for(var u=c=null,m=a,h=a=0,g=null,v=l.next();null!==m&&!v.done;h++,v=l.next()){m.index>h?(g=m,m=null):g=m.sibling;var y=f(o,m,v.value,s);if(null===y){null===m&&(m=g);break}e&&m&&null===y.alternate&&t(o,m),a=i(y,a,h),null===u?c=y:u.sibling=y,u=y,m=g}if(v.done)return n(o,m),c;if(null===m){for(;!v.done;h++,v=l.next())null!==(v=d(o,v.value,s))&&(a=i(v,a,h),null===u?c=v:u.sibling=v,u=v);return c}for(m=r(o,m);!v.done;h++,v=l.next())null!==(v=p(m,o,h,v.value,s))&&(e&&null!==v.alternate&&m.delete(null===v.key?h:v.key),a=i(v,a,h),null===u?c=v:u.sibling=v,u=v);return e&&m.forEach((function(e){return t(o,e)})),c}(l,s,c,u);if(h&&Ca(l,c),void 0===c&&!m)switch(l.tag){case 1:case 22:case 0:case 11:case 15:throw Error(se(152,Ge(l.type)||"Component"))}return n(l,s)}}var Oa=Aa(!0),Na=Aa(!1),_a={},Pa=di(_a),Ia=di(_a),Ta=di(_a);function La(e){if(e===_a)throw Error(se(174));return e}function Ma(e,t){switch(pi(Ta,t),pi(Ia,e),pi(Pa,_a),e=t.nodeType){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:ht(null,"");break;default:t=ht(t=(e=8===e?t.parentNode:t).namespaceURI||null,e=e.tagName)}fi(Pa),pi(Pa,t)}function Ra(){fi(Pa),fi(Ia),fi(Ta)}function za(e){La(Ta.current);var t=La(Pa.current),n=ht(t,e.type);t!==n&&(pi(Ia,e),pi(Pa,n))}function $a(e){Ia.current===e&&(fi(Pa),fi(Ia))}var Da=di(0);function Ba(e){for(var t=e;null!==t;){if(13===t.tag){var n=t.memoizedState;if(null!==n&&(null===(n=n.dehydrated)||"$?"===n.data||"$!"===n.data))return t}else if(19===t.tag&&void 0!==t.memoizedProps.revealOrder){if(0!=(64&t.flags))return t}else if(null!==t.child){t.child.return=t,t=t.child;continue}if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Fa=null,Ua=null,Wa=!1;function Va(e,t){var n=qc(5,null,null,0);n.elementType="DELETED",n.type="DELETED",n.stateNode=t,n.return=e,n.flags=8,null!==e.lastEffect?(e.lastEffect.nextEffect=n,e.lastEffect=n):e.firstEffect=e.lastEffect=n}function Ha(e,t){switch(e.tag){case 5:var n=e.type;return null!==(t=1!==t.nodeType||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t)&&(e.stateNode=t,!0);case 6:return null!==(t=""===e.pendingProps||3!==t.nodeType?null:t)&&(e.stateNode=t,!0);default:return!1}}function qa(e){if(Wa){var t=Ua;if(t){var n=t;if(!Ha(e,t)){if(!(t=Qo(n.nextSibling))||!Ha(e,t))return e.flags=-1025&e.flags|2,Wa=!1,void(Fa=e);Va(Fa,n)}Fa=e,Ua=Qo(t.firstChild)}else e.flags=-1025&e.flags|2,Wa=!1,Fa=e}}function Ya(e){for(e=e.return;null!==e&&5!==e.tag&&3!==e.tag&&13!==e.tag;)e=e.return;Fa=e}function Ja(e){if(e!==Fa)return!1;if(!Wa)return Ya(e),Wa=!0,!1;var t=e.type;if(5!==e.tag||"head"!==t&&"body"!==t&&!qo(t,e.memoizedProps))for(t=Ua;t;)Va(e,t),t=Qo(t.nextSibling);if(Ya(e),13===e.tag){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(se(317));e:{for(e=e.nextSibling,t=0;e;){if(8===e.nodeType){var n=e.data;if("/$"===n){if(0===t){Ua=Qo(e.nextSibling);break e}t--}else"$"!==n&&"$!"!==n&&"$?"!==n||t++}e=e.nextSibling}Ua=null}}else Ua=Fa?Qo(e.stateNode.nextSibling):null;return!0}function Ga(){Ua=Fa=null,Wa=!1}var Qa=[];function Ka(){for(var e=0;e<Qa.length;e++)Qa[e]._workInProgressVersionPrimary=null;Qa.length=0}var Xa=Se.ReactCurrentDispatcher,Za=Se.ReactCurrentBatchConfig,el=0,tl=null,nl=null,rl=null,ol=!1,il=!1;function al(){throw Error(se(321))}function ll(e,t){if(null===t)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!fo(e[n],t[n]))return!1;return!0}function sl(e,t,n,r,o,i){if(el=i,tl=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Xa.current=null===e||null===e.memoizedState?Ll:Ml,e=n(r,o),il){i=0;do{if(il=!1,!(25>i))throw Error(se(301));i+=1,rl=nl=null,t.updateQueue=null,Xa.current=Rl,e=n(r,o)}while(il)}if(Xa.current=Tl,t=null!==nl&&null!==nl.next,el=0,rl=nl=tl=null,ol=!1,t)throw Error(se(300));return e}function cl(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return null===rl?tl.memoizedState=rl=e:rl=rl.next=e,rl}function ul(){if(null===nl){var e=tl.alternate;e=null!==e?e.memoizedState:null}else e=nl.next;var t=null===rl?tl.memoizedState:rl.next;if(null!==t)rl=t,nl=e;else{if(null===e)throw Error(se(310));e={memoizedState:(nl=e).memoizedState,baseState:nl.baseState,baseQueue:nl.baseQueue,queue:nl.queue,next:null},null===rl?tl.memoizedState=rl=e:rl=rl.next=e}return rl}function dl(e,t){return"function"==typeof t?t(e):t}function fl(e){var t=ul(),n=t.queue;if(null===n)throw Error(se(311));n.lastRenderedReducer=e;var r=nl,o=r.baseQueue,i=n.pending;if(null!==i){if(null!==o){var a=o.next;o.next=i.next,i.next=a}r.baseQueue=o=i,n.pending=null}if(null!==o){o=o.next,r=r.baseState;var l=a=i=null,s=o;do{var c=s.lane;if((el&c)===c)null!==l&&(l=l.next={lane:0,action:s.action,eagerReducer:s.eagerReducer,eagerState:s.eagerState,next:null}),r=s.eagerReducer===e?s.eagerState:e(r,s.action);else{var u={lane:c,action:s.action,eagerReducer:s.eagerReducer,eagerState:s.eagerState,next:null};null===l?(a=l=u,i=r):l=l.next=u,tl.lanes|=c,Ws|=c}s=s.next}while(null!==s&&s!==o);null===l?i=r:l.next=a,fo(r,t.memoizedState)||($l=!0),t.memoizedState=r,t.baseState=i,t.baseQueue=l,n.lastRenderedState=r}return[t.memoizedState,n.dispatch]}function pl(e){var t=ul(),n=t.queue;if(null===n)throw Error(se(311));n.lastRenderedReducer=e;var r=n.dispatch,o=n.pending,i=t.memoizedState;if(null!==o){n.pending=null;var a=o=o.next;do{i=e(i,a.action),a=a.next}while(a!==o);fo(i,t.memoizedState)||($l=!0),t.memoizedState=i,null===t.baseQueue&&(t.baseState=i),n.lastRenderedState=i}return[i,r]}function ml(e,t,n){var r=t._getVersion;r=r(t._source);var o=t._workInProgressVersionPrimary;if(null!==o?e=o===r:(e=e.mutableReadLanes,(e=(el&e)===e)&&(t._workInProgressVersionPrimary=r,Qa.push(t))),e)return n(t._source);throw Qa.push(t),Error(se(350))}function hl(e,t,n,r){var o=Ms;if(null===o)throw Error(se(349));var i=t._getVersion,a=i(t._source),l=Xa.current,s=l.useState((function(){return ml(o,t,n)})),c=s[1],u=s[0];s=rl;var d=e.memoizedState,f=d.refs,p=f.getSnapshot,m=d.source;d=d.subscribe;var h=tl;return e.memoizedState={refs:f,source:t,subscribe:r},l.useEffect((function(){f.getSnapshot=n,f.setSnapshot=c;var e=i(t._source);if(!fo(a,e)){e=n(t._source),fo(u,e)||(c(e),e=hc(h),o.mutableReadLanes|=e&o.pendingLanes),e=o.mutableReadLanes,o.entangledLanes|=e;for(var r=o.entanglements,l=e;0<l;){var s=31-qn(l),d=1<<s;r[s]|=e,l&=~d}}}),[n,t,r]),l.useEffect((function(){return r(t._source,(function(){var e=f.getSnapshot,n=f.setSnapshot;try{n(e(t._source));var r=hc(h);o.mutableReadLanes|=r&o.pendingLanes}catch(i){n((function(){throw i}))}}))}),[t,r]),fo(p,n)&&fo(m,t)&&fo(d,r)||((e={pending:null,dispatch:null,lastRenderedReducer:dl,lastRenderedState:u}).dispatch=c=Il.bind(null,tl,e),s.queue=e,s.baseQueue=null,u=ml(o,t,n),s.memoizedState=s.baseState=u),u}function gl(e,t,n){return hl(ul(),e,t,n)}function vl(e){var t=cl();return"function"==typeof e&&(e=e()),t.memoizedState=t.baseState=e,e=(e=t.queue={pending:null,dispatch:null,lastRenderedReducer:dl,lastRenderedState:e}).dispatch=Il.bind(null,tl,e),[t.memoizedState,e]}function yl(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},null===(t=tl.updateQueue)?(t={lastEffect:null},tl.updateQueue=t,t.lastEffect=e.next=e):null===(n=t.lastEffect)?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function bl(e){return e={current:e},cl().memoizedState=e}function wl(){return ul().memoizedState}function xl(e,t,n,r){var o=cl();tl.flags|=e,o.memoizedState=yl(1|t,n,void 0,void 0===r?null:r)}function kl(e,t,n,r){var o=ul();r=void 0===r?null:r;var i=void 0;if(null!==nl){var a=nl.memoizedState;if(i=a.destroy,null!==r&&ll(r,a.deps))return void yl(t,n,i,r)}tl.flags|=e,o.memoizedState=yl(1|t,n,i,r)}function Sl(e,t){return xl(516,4,e,t)}function jl(e,t){return kl(516,4,e,t)}function El(e,t){return kl(4,2,e,t)}function Cl(e,t){return"function"==typeof t?(e=e(),t(e),function(){t(null)}):null!=t?(e=e(),t.current=e,function(){t.current=null}):void 0}function Al(e,t,n){return n=null!=n?n.concat([e]):null,kl(4,2,Cl.bind(null,t,e),n)}function Ol(){}function Nl(e,t){var n=ul();t=void 0===t?null:t;var r=n.memoizedState;return null!==r&&null!==t&&ll(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function _l(e,t){var n=ul();t=void 0===t?null:t;var r=n.memoizedState;return null!==r&&null!==t&&ll(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function Pl(e,t){var n=qi();Ji(98>n?98:n,(function(){e(!0)})),Ji(97<n?97:n,(function(){var n=Za.transition;Za.transition=1;try{e(!1),t()}finally{Za.transition=n}}))}function Il(e,t,n){var r=mc(),o=hc(e),i={lane:o,action:n,eagerReducer:null,eagerState:null,next:null},a=t.pending;if(null===a?i.next=i:(i.next=a.next,a.next=i),t.pending=i,a=e.alternate,e===tl||null!==a&&a===tl)il=ol=!0;else{if(0===e.lanes&&(null===a||0===a.lanes)&&null!==(a=t.lastRenderedReducer))try{var l=t.lastRenderedState,s=a(l,n);if(i.eagerReducer=a,i.eagerState=s,fo(s,l))return}catch(qu){}gc(e,o,r)}}var Tl={readContext:sa,useCallback:al,useContext:al,useEffect:al,useImperativeHandle:al,useLayoutEffect:al,useMemo:al,useReducer:al,useRef:al,useState:al,useDebugValue:al,useDeferredValue:al,useTransition:al,useMutableSource:al,useOpaqueIdentifier:al,unstable_isNewReconciler:!1},Ll={readContext:sa,useCallback:function(e,t){return cl().memoizedState=[e,void 0===t?null:t],e},useContext:sa,useEffect:Sl,useImperativeHandle:function(e,t,n){return n=null!=n?n.concat([e]):null,xl(4,2,Cl.bind(null,t,e),n)},useLayoutEffect:function(e,t){return xl(4,2,e,t)},useMemo:function(e,t){var n=cl();return t=void 0===t?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=cl();return t=void 0!==n?n(t):t,r.memoizedState=r.baseState=t,e=(e=r.queue={pending:null,dispatch:null,lastRenderedReducer:e,lastRenderedState:t}).dispatch=Il.bind(null,tl,e),[r.memoizedState,e]},useRef:bl,useState:vl,useDebugValue:Ol,useDeferredValue:function(e){var t=vl(e),n=t[0],r=t[1];return Sl((function(){var t=Za.transition;Za.transition=1;try{r(e)}finally{Za.transition=t}}),[e]),n},useTransition:function(){var e=vl(!1),t=e[0];return bl(e=Pl.bind(null,e[1])),[e,t]},useMutableSource:function(e,t,n){var r=cl();return r.memoizedState={refs:{getSnapshot:t,setSnapshot:null},source:e,subscribe:n},hl(r,e,t,n)},useOpaqueIdentifier:function(){if(Wa){var e=!1,t=function(e){return{$$typeof:ze,toString:e,valueOf:e}}((function(){throw e||(e=!0,n("r:"+(Xo++).toString(36))),Error(se(355))})),n=vl(t)[1];return 0==(2&tl.mode)&&(tl.flags|=516,yl(5,(function(){n("r:"+(Xo++).toString(36))}),void 0,null)),t}return vl(t="r:"+(Xo++).toString(36)),t},unstable_isNewReconciler:!1},Ml={readContext:sa,useCallback:Nl,useContext:sa,useEffect:jl,useImperativeHandle:Al,useLayoutEffect:El,useMemo:_l,useReducer:fl,useRef:wl,useState:function(){return fl(dl)},useDebugValue:Ol,useDeferredValue:function(e){var t=fl(dl),n=t[0],r=t[1];return jl((function(){var t=Za.transition;Za.transition=1;try{r(e)}finally{Za.transition=t}}),[e]),n},useTransition:function(){var e=fl(dl)[0];return[wl().current,e]},useMutableSource:gl,useOpaqueIdentifier:function(){return fl(dl)[0]},unstable_isNewReconciler:!1},Rl={readContext:sa,useCallback:Nl,useContext:sa,useEffect:jl,useImperativeHandle:Al,useLayoutEffect:El,useMemo:_l,useReducer:pl,useRef:wl,useState:function(){return pl(dl)},useDebugValue:Ol,useDeferredValue:function(e){var t=pl(dl),n=t[0],r=t[1];return jl((function(){var t=Za.transition;Za.transition=1;try{r(e)}finally{Za.transition=t}}),[e]),n},useTransition:function(){var e=pl(dl)[0];return[wl().current,e]},useMutableSource:gl,useOpaqueIdentifier:function(){return pl(dl)[0]},unstable_isNewReconciler:!1},zl=Se.ReactCurrentOwner,$l=!1;function Dl(e,t,n,r){t.child=null===e?Na(t,null,n,r):Oa(t,e.child,n,r)}function Bl(e,t,n,r,o){n=n.render;var i=t.ref;return la(t,o),r=sl(e,t,n,r,i,o),null===e||$l?(t.flags|=1,Dl(e,t,r,o),t.child):(t.updateQueue=e.updateQueue,t.flags&=-517,e.lanes&=~o,ls(e,t,o))}function Fl(e,t,n,r,o,i){if(null===e){var a=n.type;return"function"!=typeof a||Yc(a)||void 0!==a.defaultProps||null!==n.compare||void 0!==n.defaultProps?((e=Gc(n.type,null,r,t,t.mode,i)).ref=t.ref,e.return=t,t.child=e):(t.tag=15,t.type=a,Ul(e,t,a,r,o,i))}return a=e.child,0==(o&i)&&(o=a.memoizedProps,(n=null!==(n=n.compare)?n:mo)(o,r)&&e.ref===t.ref)?ls(e,t,i):(t.flags|=1,(e=Jc(a,r)).ref=t.ref,e.return=t,t.child=e)}function Ul(e,t,n,r,o,i){if(null!==e&&mo(e.memoizedProps,r)&&e.ref===t.ref){if($l=!1,0==(i&o))return t.lanes=e.lanes,ls(e,t,i);0!=(16384&e.flags)&&($l=!0)}return Hl(e,t,n,r,i)}function Wl(e,t,n){var r=t.pendingProps,o=r.children,i=null!==e?e.memoizedState:null;if("hidden"===r.mode||"unstable-defer-without-hiding"===r.mode)if(0==(4&t.mode))t.memoizedState={baseLanes:0},jc(t,n);else{if(0==(1073741824&n))return e=null!==i?i.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e},jc(t,e),null;t.memoizedState={baseLanes:0},jc(t,null!==i?i.baseLanes:n)}else null!==i?(r=i.baseLanes|n,t.memoizedState=null):r=n,jc(t,r);return Dl(e,t,o,n),t.child}function Vl(e,t){var n=t.ref;(null===e&&null!==n||null!==e&&e.ref!==n)&&(t.flags|=128)}function Hl(e,t,n,r,o){var i=bi(n)?vi:hi.current;return i=yi(t,i),la(t,o),n=sl(e,t,n,r,i,o),null===e||$l?(t.flags|=1,Dl(e,t,n,o),t.child):(t.updateQueue=e.updateQueue,t.flags&=-517,e.lanes&=~o,ls(e,t,o))}function ql(e,t,n,r,o){if(bi(n)){var i=!0;Si(t)}else i=!1;if(la(t,o),null===t.stateNode)null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),xa(t,n,r),Sa(t,n,r,o),r=!0;else if(null===e){var a=t.stateNode,l=t.memoizedProps;a.props=l;var s=a.context,c=n.contextType;"object"==typeof c&&null!==c?c=sa(c):c=yi(t,c=bi(n)?vi:hi.current);var u=n.getDerivedStateFromProps,d="function"==typeof u||"function"==typeof a.getSnapshotBeforeUpdate;d||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(l!==r||s!==c)&&ka(t,a,r,c),ca=!1;var f=t.memoizedState;a.state=f,ha(t,r,a,o),s=t.memoizedState,l!==r||f!==s||gi.current||ca?("function"==typeof u&&(ya(t,n,u,r),s=t.memoizedState),(l=ca||wa(t,n,l,r,f,s,c))?(d||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||("function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount()),"function"==typeof a.componentDidMount&&(t.flags|=4)):("function"==typeof a.componentDidMount&&(t.flags|=4),t.memoizedProps=r,t.memoizedState=s),a.props=r,a.state=s,a.context=c,r=l):("function"==typeof a.componentDidMount&&(t.flags|=4),r=!1)}else{a=t.stateNode,da(e,t),l=t.memoizedProps,c=t.type===t.elementType?l:Zi(t.type,l),a.props=c,d=t.pendingProps,f=a.context,"object"==typeof(s=n.contextType)&&null!==s?s=sa(s):s=yi(t,s=bi(n)?vi:hi.current);var p=n.getDerivedStateFromProps;(u="function"==typeof p||"function"==typeof a.getSnapshotBeforeUpdate)||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(l!==d||f!==s)&&ka(t,a,r,s),ca=!1,f=t.memoizedState,a.state=f,ha(t,r,a,o);var m=t.memoizedState;l!==d||f!==m||gi.current||ca?("function"==typeof p&&(ya(t,n,p,r),m=t.memoizedState),(c=ca||wa(t,n,c,r,f,m,s))?(u||"function"!=typeof a.UNSAFE_componentWillUpdate&&"function"!=typeof a.componentWillUpdate||("function"==typeof a.componentWillUpdate&&a.componentWillUpdate(r,m,s),"function"==typeof a.UNSAFE_componentWillUpdate&&a.UNSAFE_componentWillUpdate(r,m,s)),"function"==typeof a.componentDidUpdate&&(t.flags|=4),"function"==typeof a.getSnapshotBeforeUpdate&&(t.flags|=256)):("function"!=typeof a.componentDidUpdate||l===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||l===e.memoizedProps&&f===e.memoizedState||(t.flags|=256),t.memoizedProps=r,t.memoizedState=m),a.props=r,a.state=m,a.context=s,r=c):("function"!=typeof a.componentDidUpdate||l===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||l===e.memoizedProps&&f===e.memoizedState||(t.flags|=256),r=!1)}return Yl(e,t,n,r,i,o)}function Yl(e,t,n,r,o,i){Vl(e,t);var a=0!=(64&t.flags);if(!r&&!a)return o&&ji(t,n,!1),ls(e,t,i);r=t.stateNode,zl.current=t;var l=a&&"function"!=typeof n.getDerivedStateFromError?null:r.render();return t.flags|=1,null!==e&&a?(t.child=Oa(t,e.child,null,i),t.child=Oa(t,null,l,i)):Dl(e,t,l,i),t.memoizedState=r.state,o&&ji(t,n,!0),t.child}function Jl(e){var t=e.stateNode;t.pendingContext?xi(0,t.pendingContext,t.pendingContext!==t.context):t.context&&xi(0,t.context,!1),Ma(e,t.containerInfo)}var Gl,Ql,Kl,Xl,Zl={dehydrated:null,retryLane:0};function es(e,t,n){var r,o=t.pendingProps,i=Da.current,a=!1;return(r=0!=(64&t.flags))||(r=(null===e||null!==e.memoizedState)&&0!=(2&i)),r?(a=!0,t.flags&=-65):null!==e&&null===e.memoizedState||void 0===o.fallback||!0===o.unstable_avoidThisFallback||(i|=1),pi(Da,1&i),null===e?(void 0!==o.fallback&&qa(t),e=o.children,i=o.fallback,a?(e=ts(t,e,i,n),t.child.memoizedState={baseLanes:n},t.memoizedState=Zl,e):"number"==typeof o.unstable_expectedLoadTime?(e=ts(t,e,i,n),t.child.memoizedState={baseLanes:n},t.memoizedState=Zl,t.lanes=33554432,e):((n=Kc({mode:"visible",children:e},t.mode,n,null)).return=t,t.child=n)):(e.memoizedState,a?(o=rs(e,t,o.children,o.fallback,n),a=t.child,i=e.child.memoizedState,a.memoizedState=null===i?{baseLanes:n}:{baseLanes:i.baseLanes|n},a.childLanes=e.childLanes&~n,t.memoizedState=Zl,o):(n=ns(e,t,o.children,n),t.memoizedState=null,n))}function ts(e,t,n,r){var o=e.mode,i=e.child;return t={mode:"hidden",children:t},0==(2&o)&&null!==i?(i.childLanes=0,i.pendingProps=t):i=Kc(t,o,0,null),n=Qc(n,o,r,null),i.return=e,n.return=e,i.sibling=n,e.child=i,n}function ns(e,t,n,r){var o=e.child;return e=o.sibling,n=Jc(o,{mode:"visible",children:n}),0==(2&t.mode)&&(n.lanes=r),n.return=t,n.sibling=null,null!==e&&(e.nextEffect=null,e.flags=8,t.firstEffect=t.lastEffect=e),t.child=n}function rs(e,t,n,r,o){var i=t.mode,a=e.child;e=a.sibling;var l={mode:"hidden",children:n};return 0==(2&i)&&t.child!==a?((n=t.child).childLanes=0,n.pendingProps=l,null!==(a=n.lastEffect)?(t.firstEffect=n.firstEffect,t.lastEffect=a,a.nextEffect=null):t.firstEffect=t.lastEffect=null):n=Jc(a,l),null!==e?r=Jc(e,r):(r=Qc(r,i,o,null)).flags|=2,r.return=t,n.return=t,n.sibling=r,t.child=n,r}function os(e,t){e.lanes|=t;var n=e.alternate;null!==n&&(n.lanes|=t),aa(e.return,t)}function is(e,t,n,r,o,i){var a=e.memoizedState;null===a?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:o,lastEffect:i}:(a.isBackwards=t,a.rendering=null,a.renderingStartTime=0,a.last=r,a.tail=n,a.tailMode=o,a.lastEffect=i)}function as(e,t,n){var r=t.pendingProps,o=r.revealOrder,i=r.tail;if(Dl(e,t,r.children,n),0!=(2&(r=Da.current)))r=1&r|2,t.flags|=64;else{if(null!==e&&0!=(64&e.flags))e:for(e=t.child;null!==e;){if(13===e.tag)null!==e.memoizedState&&os(e,n);else if(19===e.tag)os(e,n);else if(null!==e.child){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;null===e.sibling;){if(null===e.return||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(pi(Da,r),0==(2&t.mode))t.memoizedState=null;else switch(o){case"forwards":for(n=t.child,o=null;null!==n;)null!==(e=n.alternate)&&null===Ba(e)&&(o=n),n=n.sibling;null===(n=o)?(o=t.child,t.child=null):(o=n.sibling,n.sibling=null),is(t,!1,o,n,i,t.lastEffect);break;case"backwards":for(n=null,o=t.child,t.child=null;null!==o;){if(null!==(e=o.alternate)&&null===Ba(e)){t.child=o;break}e=o.sibling,o.sibling=n,n=o,o=e}is(t,!0,n,null,i,t.lastEffect);break;case"together":is(t,!1,null,null,void 0,t.lastEffect);break;default:t.memoizedState=null}return t.child}function ls(e,t,n){if(null!==e&&(t.dependencies=e.dependencies),Ws|=t.lanes,0!=(n&t.childLanes)){if(null!==e&&t.child!==e.child)throw Error(se(153));if(null!==t.child){for(n=Jc(e=t.child,e.pendingProps),t.child=n,n.return=t;null!==e.sibling;)e=e.sibling,(n=n.sibling=Jc(e,e.pendingProps)).return=t;n.sibling=null}return t.child}return null}function ss(e,t){if(!Wa)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;null!==t;)null!==t.alternate&&(n=t),t=t.sibling;null===n?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;null!==n;)null!==n.alternate&&(r=n),n=n.sibling;null===r?t||null===e.tail?e.tail=null:e.tail.sibling=null:r.sibling=null}}function cs(e,t,n){var r=t.pendingProps;switch(t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:case 17:return bi(t.type)&&wi(),null;case 3:return Ra(),fi(gi),fi(hi),Ka(),(r=t.stateNode).pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),null!==e&&null!==e.child||(Ja(t)?t.flags|=4:r.hydrate||(t.flags|=256)),Ql(t),null;case 5:$a(t);var o=La(Ta.current);if(n=t.type,null!==e&&null!=t.stateNode)Kl(e,t,n,r,o),e.ref!==t.ref&&(t.flags|=128);else{if(!r){if(null===t.stateNode)throw Error(se(166));return null}if(e=La(Pa.current),Ja(t)){r=t.stateNode,n=t.type;var i=t.memoizedProps;switch(r[ei]=t,r[ti]=i,n){case"dialog":Io("cancel",r),Io("close",r);break;case"iframe":case"object":case"embed":Io("load",r);break;case"video":case"audio":for(e=0;e<Oo.length;e++)Io(Oo[e],r);break;case"source":Io("error",r);break;case"img":case"image":case"link":Io("error",r),Io("load",r);break;case"details":Io("toggle",r);break;case"input":nt(r,i),Io("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!i.multiple},Io("invalid",r);break;case"textarea":ut(r,i),Io("invalid",r)}for(var a in Et(n,i),e=null,i)i.hasOwnProperty(a)&&(o=i[a],"children"===a?"string"==typeof o?r.textContent!==o&&(e=["children",o]):"number"==typeof o&&r.textContent!==""+o&&(e=["children",""+o]):ue.hasOwnProperty(a)&&null!=o&&"onScroll"===a&&Io("scroll",r));switch(n){case"input":Xe(r),it(r,i,!0);break;case"textarea":Xe(r),ft(r);break;case"select":case"option":break;default:"function"==typeof i.onClick&&(r.onclick=Uo)}r=e,t.updateQueue=r,null!==r&&(t.flags|=4)}else{switch(a=9===o.nodeType?o:o.ownerDocument,e===pt.html&&(e=mt(n)),e===pt.html?"script"===n?((e=a.createElement("div")).innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):"string"==typeof r.is?e=a.createElement(n,{is:r.is}):(e=a.createElement(n),"select"===n&&(a=e,r.multiple?a.multiple=!0:r.size&&(a.size=r.size))):e=a.createElementNS(e,n),e[ei]=t,e[ti]=r,Gl(e,t,!1,!1),t.stateNode=e,a=Ct(n,r),n){case"dialog":Io("cancel",e),Io("close",e),o=r;break;case"iframe":case"object":case"embed":Io("load",e),o=r;break;case"video":case"audio":for(o=0;o<Oo.length;o++)Io(Oo[o],e);o=r;break;case"source":Io("error",e),o=r;break;case"img":case"image":case"link":Io("error",e),Io("load",e),o=r;break;case"details":Io("toggle",e),o=r;break;case"input":nt(e,r),o=tt(e,r),Io("invalid",e);break;case"option":o=lt(e,r);break;case"select":e._wrapperState={wasMultiple:!!r.multiple},o=ae({},r,{value:void 0}),Io("invalid",e);break;case"textarea":ut(e,r),o=ct(e,r),Io("invalid",e);break;default:o=r}Et(n,o);var l=o;for(i in l)if(l.hasOwnProperty(i)){var s=l[i];"style"===i?St(e,s):"dangerouslySetInnerHTML"===i?null!=(s=s?s.__html:void 0)&&yt(e,s):"children"===i?"string"==typeof s?("textarea"!==n||""!==s)&&bt(e,s):"number"==typeof s&&bt(e,""+s):"suppressContentEditableWarning"!==i&&"suppressHydrationWarning"!==i&&"autoFocus"!==i&&(ue.hasOwnProperty(i)?null!=s&&"onScroll"===i&&Io("scroll",e):null!=s&&ke(e,i,s,a))}switch(n){case"input":Xe(e),it(e,r,!1);break;case"textarea":Xe(e),ft(e);break;case"option":null!=r.value&&e.setAttribute("value",""+Qe(r.value));break;case"select":e.multiple=!!r.multiple,null!=(i=r.value)?st(e,!!r.multiple,i,!1):null!=r.defaultValue&&st(e,!!r.multiple,r.defaultValue,!0);break;default:"function"==typeof o.onClick&&(e.onclick=Uo)}Ho(n,r)&&(t.flags|=4)}null!==t.ref&&(t.flags|=128)}return null;case 6:if(e&&null!=t.stateNode)Xl(e,t,e.memoizedProps,r);else{if("string"!=typeof r&&null===t.stateNode)throw Error(se(166));n=La(Ta.current),La(Pa.current),Ja(t)?(r=t.stateNode,n=t.memoizedProps,r[ei]=t,r.nodeValue!==n&&(t.flags|=4)):((r=(9===n.nodeType?n:n.ownerDocument).createTextNode(r))[ei]=t,t.stateNode=r)}return null;case 13:return fi(Da),r=t.memoizedState,0!=(64&t.flags)?(t.lanes=n,t):(r=null!==r,n=!1,null===e?void 0!==t.memoizedProps.fallback&&Ja(t):n=null!==e.memoizedState,r&&!n&&0!=(2&t.mode)&&(null===e&&!0!==t.memoizedProps.unstable_avoidThisFallback||0!=(1&Da.current)?0===Bs&&(Bs=3):(0!==Bs&&3!==Bs||(Bs=4),null===Ms||0==(134217727&Ws)&&0==(134217727&Vs)||wc(Ms,zs))),(r||n)&&(t.flags|=4),null);case 4:return Ra(),Ql(t),null===e&&Lo(t.stateNode.containerInfo),null;case 10:return ia(t),null;case 19:if(fi(Da),null===(r=t.memoizedState))return null;if(i=0!=(64&t.flags),null===(a=r.rendering))if(i)ss(r,!1);else{if(0!==Bs||null!==e&&0!=(64&e.flags))for(e=t.child;null!==e;){if(null!==(a=Ba(e))){for(t.flags|=64,ss(r,!1),null!==(i=a.updateQueue)&&(t.updateQueue=i,t.flags|=4),null===r.lastEffect&&(t.firstEffect=null),t.lastEffect=r.lastEffect,r=n,n=t.child;null!==n;)e=r,(i=n).flags&=2,i.nextEffect=null,i.firstEffect=null,i.lastEffect=null,null===(a=i.alternate)?(i.childLanes=0,i.lanes=e,i.child=null,i.memoizedProps=null,i.memoizedState=null,i.updateQueue=null,i.dependencies=null,i.stateNode=null):(i.childLanes=a.childLanes,i.lanes=a.lanes,i.child=a.child,i.memoizedProps=a.memoizedProps,i.memoizedState=a.memoizedState,i.updateQueue=a.updateQueue,i.type=a.type,e=a.dependencies,i.dependencies=null===e?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return pi(Da,1&Da.current|2),t.child}e=e.sibling}null!==r.tail&&Hi()>Js&&(t.flags|=64,i=!0,ss(r,!1),t.lanes=33554432)}else{if(!i)if(null!==(e=Ba(a))){if(t.flags|=64,i=!0,null!==(n=e.updateQueue)&&(t.updateQueue=n,t.flags|=4),ss(r,!0),null===r.tail&&"hidden"===r.tailMode&&!a.alternate&&!Wa)return null!==(t=t.lastEffect=r.lastEffect)&&(t.nextEffect=null),null}else 2*Hi()-r.renderingStartTime>Js&&1073741824!==n&&(t.flags|=64,i=!0,ss(r,!1),t.lanes=33554432);r.isBackwards?(a.sibling=t.child,t.child=a):(null!==(n=r.last)?n.sibling=a:t.child=a,r.last=a)}return null!==r.tail?(n=r.tail,r.rendering=n,r.tail=n.sibling,r.lastEffect=t.lastEffect,r.renderingStartTime=Hi(),n.sibling=null,t=Da.current,pi(Da,i?1&t|2:1&t),n):null;case 23:case 24:return Ec(),null!==e&&null!==e.memoizedState!=(null!==t.memoizedState)&&"unstable-defer-without-hiding"!==r.mode&&(t.flags|=4),null}throw Error(se(156,t.tag))}function us(e){switch(e.tag){case 1:bi(e.type)&&wi();var t=e.flags;return 4096&t?(e.flags=-4097&t|64,e):null;case 3:if(Ra(),fi(gi),fi(hi),Ka(),0!=(64&(t=e.flags)))throw Error(se(285));return e.flags=-4097&t|64,e;case 5:return $a(e),null;case 13:return fi(Da),4096&(t=e.flags)?(e.flags=-4097&t|64,e):null;case 19:return fi(Da),null;case 4:return Ra(),null;case 10:return ia(e),null;case 23:case 24:return Ec(),null;default:return null}}function ds(e,t){try{var n="",r=t;do{n+=Je(r),r=r.return}while(r);var o=n}catch(i){o="\nError generating stack: "+i.message+"\n"+i.stack}return{value:e,source:t,stack:o}}function fs(e,t){try{console.error(t.value)}catch(n){setTimeout((function(){throw n}))}}Gl=function(e,t){for(var n=t.child;null!==n;){if(5===n.tag||6===n.tag)e.appendChild(n.stateNode);else if(4!==n.tag&&null!==n.child){n.child.return=n,n=n.child;continue}if(n===t)break;for(;null===n.sibling;){if(null===n.return||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}},Ql=function(){},Kl=function(e,t,n,r){var o=e.memoizedProps;if(o!==r){e=t.stateNode,La(Pa.current);var i,a=null;switch(n){case"input":o=tt(e,o),r=tt(e,r),a=[];break;case"option":o=lt(e,o),r=lt(e,r),a=[];break;case"select":o=ae({},o,{value:void 0}),r=ae({},r,{value:void 0}),a=[];break;case"textarea":o=ct(e,o),r=ct(e,r),a=[];break;default:"function"!=typeof o.onClick&&"function"==typeof r.onClick&&(e.onclick=Uo)}for(c in Et(n,r),n=null,o)if(!r.hasOwnProperty(c)&&o.hasOwnProperty(c)&&null!=o[c])if("style"===c){var l=o[c];for(i in l)l.hasOwnProperty(i)&&(n||(n={}),n[i]="")}else"dangerouslySetInnerHTML"!==c&&"children"!==c&&"suppressContentEditableWarning"!==c&&"suppressHydrationWarning"!==c&&"autoFocus"!==c&&(ue.hasOwnProperty(c)?a||(a=[]):(a=a||[]).push(c,null));for(c in r){var s=r[c];if(l=null!=o?o[c]:void 0,r.hasOwnProperty(c)&&s!==l&&(null!=s||null!=l))if("style"===c)if(l){for(i in l)!l.hasOwnProperty(i)||s&&s.hasOwnProperty(i)||(n||(n={}),n[i]="");for(i in s)s.hasOwnProperty(i)&&l[i]!==s[i]&&(n||(n={}),n[i]=s[i])}else n||(a||(a=[]),a.push(c,n)),n=s;else"dangerouslySetInnerHTML"===c?(s=s?s.__html:void 0,l=l?l.__html:void 0,null!=s&&l!==s&&(a=a||[]).push(c,s)):"children"===c?"string"!=typeof s&&"number"!=typeof s||(a=a||[]).push(c,""+s):"suppressContentEditableWarning"!==c&&"suppressHydrationWarning"!==c&&(ue.hasOwnProperty(c)?(null!=s&&"onScroll"===c&&Io("scroll",e),a||l===s||(a=[])):"object"==typeof s&&null!==s&&s.$$typeof===ze?s.toString():(a=a||[]).push(c,s))}n&&(a=a||[]).push("style",n);var c=a;(t.updateQueue=c)&&(t.flags|=4)}},Xl=function(e,t,n,r){n!==r&&(t.flags|=4)};var ps="function"==typeof WeakMap?WeakMap:Map;function ms(e,t,n){(n=fa(-1,n)).tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){Xs||(Xs=!0,Zs=r),fs(0,t)},n}function hs(e,t,n){(n=fa(-1,n)).tag=3;var r=e.type.getDerivedStateFromError;if("function"==typeof r){var o=t.value;n.payload=function(){return fs(0,t),r(o)}}var i=e.stateNode;return null!==i&&"function"==typeof i.componentDidCatch&&(n.callback=function(){"function"!=typeof r&&(null===ec?ec=new Set([this]):ec.add(this),fs(0,t));var e=t.stack;this.componentDidCatch(t.value,{componentStack:null!==e?e:""})}),n}var gs="function"==typeof WeakSet?WeakSet:Set;function vs(e){var t=e.ref;if(null!==t)if("function"==typeof t)try{t(null)}catch(n){Uc(e,n)}else t.current=null}function ys(e,t){switch(t.tag){case 0:case 11:case 15:case 22:case 5:case 6:case 4:case 17:return;case 1:if(256&t.flags&&null!==e){var n=e.memoizedProps,r=e.memoizedState;t=(e=t.stateNode).getSnapshotBeforeUpdate(t.elementType===t.type?n:Zi(t.type,n),r),e.__reactInternalSnapshotBeforeUpdate=t}return;case 3:return void(256&t.flags&&Go(t.stateNode.containerInfo))}throw Error(se(163))}function bs(e,t,n){switch(n.tag){case 0:case 11:case 15:case 22:if(null!==(t=null!==(t=n.updateQueue)?t.lastEffect:null)){e=t=t.next;do{if(3==(3&e.tag)){var r=e.create;e.destroy=r()}e=e.next}while(e!==t)}if(null!==(t=null!==(t=n.updateQueue)?t.lastEffect:null)){e=t=t.next;do{var o=e;r=o.next,0!=(4&(o=o.tag))&&0!=(1&o)&&(Dc(n,e),$c(n,e)),e=r}while(e!==t)}return;case 1:return e=n.stateNode,4&n.flags&&(null===t?e.componentDidMount():(r=n.elementType===n.type?t.memoizedProps:Zi(n.type,t.memoizedProps),e.componentDidUpdate(r,t.memoizedState,e.__reactInternalSnapshotBeforeUpdate))),void(null!==(t=n.updateQueue)&&ga(n,t,e));case 3:if(null!==(t=n.updateQueue)){if(e=null,null!==n.child)switch(n.child.tag){case 5:case 1:e=n.child.stateNode}ga(n,t,e)}return;case 5:return e=n.stateNode,void(null===t&&4&n.flags&&Ho(n.type,n.memoizedProps)&&e.focus());case 6:case 4:case 12:case 19:case 17:case 20:case 21:case 23:case 24:return;case 13:return void(null===n.memoizedState&&(n=n.alternate,null!==n&&(n=n.memoizedState,null!==n&&(n=n.dehydrated,null!==n&&jn(n)))))}throw Error(se(163))}function ws(e,t){for(var n=e;;){if(5===n.tag){var r=n.stateNode;if(t)"function"==typeof(r=r.style).setProperty?r.setProperty("display","none","important"):r.display="none";else{r=n.stateNode;var o=n.memoizedProps.style;o=null!=o&&o.hasOwnProperty("display")?o.display:null,r.style.display=kt("display",o)}}else if(6===n.tag)n.stateNode.nodeValue=t?"":n.memoizedProps;else if((23!==n.tag&&24!==n.tag||null===n.memoizedState||n===e)&&null!==n.child){n.child.return=n,n=n.child;continue}if(n===e)break;for(;null===n.sibling;){if(null===n.return||n.return===e)return;n=n.return}n.sibling.return=n.return,n=n.sibling}}function xs(e,t){if(Ci&&"function"==typeof Ci.onCommitFiberUnmount)try{Ci.onCommitFiberUnmount(Ei,t)}catch(i){}switch(t.tag){case 0:case 11:case 14:case 15:case 22:if(null!==(e=t.updateQueue)&&null!==(e=e.lastEffect)){var n=e=e.next;do{var r=n,o=r.destroy;if(r=r.tag,void 0!==o)if(0!=(4&r))Dc(t,n);else{r=t;try{o()}catch(i){Uc(r,i)}}n=n.next}while(n!==e)}break;case 1:if(vs(t),"function"==typeof(e=t.stateNode).componentWillUnmount)try{e.props=t.memoizedProps,e.state=t.memoizedState,e.componentWillUnmount()}catch(i){Uc(t,i)}break;case 5:vs(t);break;case 4:As(e,t)}}function ks(e){e.alternate=null,e.child=null,e.dependencies=null,e.firstEffect=null,e.lastEffect=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.return=null,e.updateQueue=null}function Ss(e){return 5===e.tag||3===e.tag||4===e.tag}function js(e){e:{for(var t=e.return;null!==t;){if(Ss(t))break e;t=t.return}throw Error(se(160))}var n=t;switch(t=n.stateNode,n.tag){case 5:var r=!1;break;case 3:case 4:t=t.containerInfo,r=!0;break;default:throw Error(se(161))}16&n.flags&&(bt(t,""),n.flags&=-17);e:t:for(n=e;;){for(;null===n.sibling;){if(null===n.return||Ss(n.return)){n=null;break e}n=n.return}for(n.sibling.return=n.return,n=n.sibling;5!==n.tag&&6!==n.tag&&18!==n.tag;){if(2&n.flags)continue t;if(null===n.child||4===n.tag)continue t;n.child.return=n,n=n.child}if(!(2&n.flags)){n=n.stateNode;break e}}r?Es(e,n,t):Cs(e,n,t)}function Es(e,t,n){var r=e.tag,o=5===r||6===r;if(o)e=o?e.stateNode:e.stateNode.instance,t?8===n.nodeType?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(8===n.nodeType?(t=n.parentNode).insertBefore(e,n):(t=n).appendChild(e),null!=(n=n._reactRootContainer)||null!==t.onclick||(t.onclick=Uo));else if(4!==r&&null!==(e=e.child))for(Es(e,t,n),e=e.sibling;null!==e;)Es(e,t,n),e=e.sibling}function Cs(e,t,n){var r=e.tag,o=5===r||6===r;if(o)e=o?e.stateNode:e.stateNode.instance,t?n.insertBefore(e,t):n.appendChild(e);else if(4!==r&&null!==(e=e.child))for(Cs(e,t,n),e=e.sibling;null!==e;)Cs(e,t,n),e=e.sibling}function As(e,t){for(var n,r,o=t,i=!1;;){if(!i){i=o.return;e:for(;;){if(null===i)throw Error(se(160));switch(n=i.stateNode,i.tag){case 5:r=!1;break e;case 3:case 4:n=n.containerInfo,r=!0;break e}i=i.return}i=!0}if(5===o.tag||6===o.tag){e:for(var a=e,l=o,s=l;;)if(xs(a,s),null!==s.child&&4!==s.tag)s.child.return=s,s=s.child;else{if(s===l)break e;for(;null===s.sibling;){if(null===s.return||s.return===l)break e;s=s.return}s.sibling.return=s.return,s=s.sibling}r?(a=n,l=o.stateNode,8===a.nodeType?a.parentNode.removeChild(l):a.removeChild(l)):n.removeChild(o.stateNode)}else if(4===o.tag){if(null!==o.child){n=o.stateNode.containerInfo,r=!0,o.child.return=o,o=o.child;continue}}else if(xs(e,o),null!==o.child){o.child.return=o,o=o.child;continue}if(o===t)break;for(;null===o.sibling;){if(null===o.return||o.return===t)return;4===(o=o.return).tag&&(i=!1)}o.sibling.return=o.return,o=o.sibling}}function Os(e,t){switch(t.tag){case 0:case 11:case 14:case 15:case 22:var n=t.updateQueue;if(null!==(n=null!==n?n.lastEffect:null)){var r=n=n.next;do{3==(3&r.tag)&&(e=r.destroy,r.destroy=void 0,void 0!==e&&e()),r=r.next}while(r!==n)}return;case 1:case 12:case 17:return;case 5:if(null!=(n=t.stateNode)){r=t.memoizedProps;var o=null!==e?e.memoizedProps:r;e=t.type;var i=t.updateQueue;if(t.updateQueue=null,null!==i){for(n[ti]=r,"input"===e&&"radio"===r.type&&null!=r.name&&rt(n,r),Ct(e,o),t=Ct(e,r),o=0;o<i.length;o+=2){var a=i[o],l=i[o+1];"style"===a?St(n,l):"dangerouslySetInnerHTML"===a?yt(n,l):"children"===a?bt(n,l):ke(n,a,l,t)}switch(e){case"input":ot(n,r);break;case"textarea":dt(n,r);break;case"select":e=n._wrapperState.wasMultiple,n._wrapperState.wasMultiple=!!r.multiple,null!=(i=r.value)?st(n,!!r.multiple,i,!1):e!==!!r.multiple&&(null!=r.defaultValue?st(n,!!r.multiple,r.defaultValue,!0):st(n,!!r.multiple,r.multiple?[]:"",!1))}}}return;case 6:if(null===t.stateNode)throw Error(se(162));return void(t.stateNode.nodeValue=t.memoizedProps);case 3:return void((n=t.stateNode).hydrate&&(n.hydrate=!1,jn(n.containerInfo)));case 13:return null!==t.memoizedState&&(Ys=Hi(),ws(t.child,!0)),void Ns(t);case 19:return void Ns(t);case 23:case 24:return void ws(t,null!==t.memoizedState)}throw Error(se(163))}function Ns(e){var t=e.updateQueue;if(null!==t){e.updateQueue=null;var n=e.stateNode;null===n&&(n=e.stateNode=new gs),t.forEach((function(t){var r=Vc.bind(null,e,t);n.has(t)||(n.add(t),t.then(r,r))}))}}function _s(e,t){return null!==e&&(null===(e=e.memoizedState)||null!==e.dehydrated)&&(null!==(t=t.memoizedState)&&null===t.dehydrated)}var Ps=Math.ceil,Is=Se.ReactCurrentDispatcher,Ts=Se.ReactCurrentOwner,Ls=0,Ms=null,Rs=null,zs=0,$s=0,Ds=di(0),Bs=0,Fs=null,Us=0,Ws=0,Vs=0,Hs=0,qs=null,Ys=0,Js=1/0;function Gs(){Js=Hi()+500}var Qs,Ks=null,Xs=!1,Zs=null,ec=null,tc=!1,nc=null,rc=90,oc=[],ic=[],ac=null,lc=0,sc=null,cc=-1,uc=0,dc=0,fc=null,pc=!1;function mc(){return 0!=(48&Ls)?Hi():-1!==cc?cc:cc=Hi()}function hc(e){if(0==(2&(e=e.mode)))return 1;if(0==(4&e))return 99===qi()?1:2;if(0===uc&&(uc=Us),0!==Xi.transition){0!==dc&&(dc=null!==qs?qs.pendingLanes:0),e=uc;var t=4186112&~dc;return 0===(t&=-t)&&(0===(t=(e=4186112&~e)&-e)&&(t=8192)),t}return e=qi(),0!=(4&Ls)&&98===e?e=Un(12,uc):e=Un(e=function(e){switch(e){case 99:return 15;case 98:return 10;case 97:case 96:return 8;case 95:return 2;default:return 0}}(e),uc),e}function gc(e,t,n){if(50<lc)throw lc=0,sc=null,Error(se(185));if(null===(e=vc(e,t)))return null;Hn(e,t,n),e===Ms&&(Vs|=t,4===Bs&&wc(e,zs));var r=qi();1===t?0!=(8&Ls)&&0==(48&Ls)?xc(e):(yc(e,n),0===Ls&&(Gs(),Qi())):(0==(4&Ls)||98!==r&&99!==r||(null===ac?ac=new Set([e]):ac.add(e)),yc(e,n)),qs=e}function vc(e,t){e.lanes|=t;var n=e.alternate;for(null!==n&&(n.lanes|=t),n=e,e=e.return;null!==e;)e.childLanes|=t,null!==(n=e.alternate)&&(n.childLanes|=t),n=e,e=e.return;return 3===n.tag?n.stateNode:null}function yc(e,t){for(var n=e.callbackNode,r=e.suspendedLanes,o=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes;0<a;){var l=31-qn(a),s=1<<l,c=i[l];if(-1===c){if(0==(s&r)||0!=(s&o)){c=t,Dn(s);var u=$n;i[l]=10<=u?c+250:6<=u?c+5e3:-1}}else c<=t&&(e.expiredLanes|=s);a&=~s}if(r=Bn(e,e===Ms?zs:0),t=$n,0===r)null!==n&&(n!==Di&&Ni(n),e.callbackNode=null,e.callbackPriority=0);else{if(null!==n){if(e.callbackPriority===t)return;n!==Di&&Ni(n)}15===t?(n=xc.bind(null,e),null===Fi?(Fi=[n],Ui=Oi(Li,Ki)):Fi.push(n),n=Di):14===t?n=Gi(99,xc.bind(null,e)):(n=function(e){switch(e){case 15:case 14:return 99;case 13:case 12:case 11:case 10:return 98;case 9:case 8:case 7:case 6:case 4:case 5:return 97;case 3:case 2:case 1:return 95;case 0:return 90;default:throw Error(se(358,e))}}(t),n=Gi(n,bc.bind(null,e))),e.callbackPriority=t,e.callbackNode=n}}function bc(e){if(cc=-1,dc=uc=0,0!=(48&Ls))throw Error(se(327));var t=e.callbackNode;if(zc()&&e.callbackNode!==t)return null;var n=Bn(e,e===Ms?zs:0);if(0===n)return null;var r=n,o=Ls;Ls|=16;var i=Oc();for(Ms===e&&zs===r||(Gs(),Cc(e,r));;)try{Pc();break}catch(l){Ac(e,l)}if(oa(),Is.current=i,Ls=o,null!==Rs?r=0:(Ms=null,zs=0,r=Bs),0!=(Us&Vs))Cc(e,0);else if(0!==r){if(2===r&&(Ls|=64,e.hydrate&&(e.hydrate=!1,Go(e.containerInfo)),0!==(n=Fn(e))&&(r=Nc(e,n))),1===r)throw t=Fs,Cc(e,0),wc(e,n),yc(e,Hi()),t;switch(e.finishedWork=e.current.alternate,e.finishedLanes=n,r){case 0:case 1:throw Error(se(345));case 2:case 5:Lc(e);break;case 3:if(wc(e,n),(62914560&n)===n&&10<(r=Ys+500-Hi())){if(0!==Bn(e,0))break;if(((o=e.suspendedLanes)&n)!==n){mc(),e.pingedLanes|=e.suspendedLanes&o;break}e.timeoutHandle=Yo(Lc.bind(null,e),r);break}Lc(e);break;case 4:if(wc(e,n),(4186112&n)===n)break;for(r=e.eventTimes,o=-1;0<n;){var a=31-qn(n);i=1<<a,(a=r[a])>o&&(o=a),n&=~i}if(n=o,10<(n=(120>(n=Hi()-n)?120:480>n?480:1080>n?1080:1920>n?1920:3e3>n?3e3:4320>n?4320:1960*Ps(n/1960))-n)){e.timeoutHandle=Yo(Lc.bind(null,e),n);break}Lc(e);break;default:throw Error(se(329))}}return yc(e,Hi()),e.callbackNode===t?bc.bind(null,e):null}function wc(e,t){for(t&=~Hs,t&=~Vs,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-qn(t),r=1<<n;e[n]=-1,t&=~r}}function xc(e){if(0!=(48&Ls))throw Error(se(327));if(zc(),e===Ms&&0!=(e.expiredLanes&zs)){var t=zs,n=Nc(e,t);0!=(Us&Vs)&&(n=Nc(e,t=Bn(e,t)))}else n=Nc(e,t=Bn(e,0));if(0!==e.tag&&2===n&&(Ls|=64,e.hydrate&&(e.hydrate=!1,Go(e.containerInfo)),0!==(t=Fn(e))&&(n=Nc(e,t))),1===n)throw n=Fs,Cc(e,0),wc(e,t),yc(e,Hi()),n;return e.finishedWork=e.current.alternate,e.finishedLanes=t,Lc(e),yc(e,Hi()),null}function kc(e,t){var n=Ls;Ls|=1;try{return e(t)}finally{0===(Ls=n)&&(Gs(),Qi())}}function Sc(e,t){var n=Ls;Ls&=-2,Ls|=8;try{return e(t)}finally{0===(Ls=n)&&(Gs(),Qi())}}function jc(e,t){pi(Ds,$s),$s|=t,Us|=t}function Ec(){$s=Ds.current,fi(Ds)}function Cc(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(-1!==n&&(e.timeoutHandle=-1,Jo(n)),null!==Rs)for(n=Rs.return;null!==n;){var r=n;switch(r.tag){case 1:null!=(r=r.type.childContextTypes)&&wi();break;case 3:Ra(),fi(gi),fi(hi),Ka();break;case 5:$a(r);break;case 4:Ra();break;case 13:case 19:fi(Da);break;case 10:ia(r);break;case 23:case 24:Ec()}n=n.return}Ms=e,Rs=Jc(e.current,null),zs=$s=Us=t,Bs=0,Fs=null,Hs=Vs=Ws=0}function Ac(e,t){for(;;){var n=Rs;try{if(oa(),Xa.current=Tl,ol){for(var r=tl.memoizedState;null!==r;){var o=r.queue;null!==o&&(o.pending=null),r=r.next}ol=!1}if(el=0,rl=nl=tl=null,il=!1,Ts.current=null,null===n||null===n.return){Bs=1,Fs=t,Rs=null;break}e:{var i=e,a=n.return,l=n,s=t;if(t=zs,l.flags|=2048,l.firstEffect=l.lastEffect=null,null!==s&&"object"==typeof s&&"function"==typeof s.then){var c=s;if(0==(2&l.mode)){var u=l.alternate;u?(l.updateQueue=u.updateQueue,l.memoizedState=u.memoizedState,l.lanes=u.lanes):(l.updateQueue=null,l.memoizedState=null)}var d=0!=(1&Da.current),f=a;do{var p;if(p=13===f.tag){var m=f.memoizedState;if(null!==m)p=null!==m.dehydrated;else{var h=f.memoizedProps;p=void 0!==h.fallback&&(!0!==h.unstable_avoidThisFallback||!d)}}if(p){var g=f.updateQueue;if(null===g){var v=new Set;v.add(c),f.updateQueue=v}else g.add(c);if(0==(2&f.mode)){if(f.flags|=64,l.flags|=16384,l.flags&=-2981,1===l.tag)if(null===l.alternate)l.tag=17;else{var y=fa(-1,1);y.tag=2,pa(l,y)}l.lanes|=1;break e}s=void 0,l=t;var b=i.pingCache;if(null===b?(b=i.pingCache=new ps,s=new Set,b.set(c,s)):void 0===(s=b.get(c))&&(s=new Set,b.set(c,s)),!s.has(l)){s.add(l);var w=Wc.bind(null,i,c,l);c.then(w,w)}f.flags|=4096,f.lanes=t;break e}f=f.return}while(null!==f);s=Error((Ge(l.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.")}5!==Bs&&(Bs=2),s=ds(s,l),f=a;do{switch(f.tag){case 3:i=s,f.flags|=4096,t&=-t,f.lanes|=t,ma(f,ms(0,i,t));break e;case 1:i=s;var x=f.type,k=f.stateNode;if(0==(64&f.flags)&&("function"==typeof x.getDerivedStateFromError||null!==k&&"function"==typeof k.componentDidCatch&&(null===ec||!ec.has(k)))){f.flags|=4096,t&=-t,f.lanes|=t,ma(f,hs(f,i,t));break e}}f=f.return}while(null!==f)}Tc(n)}catch(S){t=S,Rs===n&&null!==n&&(Rs=n=n.return);continue}break}}function Oc(){var e=Is.current;return Is.current=Tl,null===e?Tl:e}function Nc(e,t){var n=Ls;Ls|=16;var r=Oc();for(Ms===e&&zs===t||Cc(e,t);;)try{_c();break}catch(Wu){Ac(e,Wu)}if(oa(),Ls=n,Is.current=r,null!==Rs)throw Error(se(261));return Ms=null,zs=0,Bs}function _c(){for(;null!==Rs;)Ic(Rs)}function Pc(){for(;null!==Rs&&!_i();)Ic(Rs)}function Ic(e){var t=Qs(e.alternate,e,$s);e.memoizedProps=e.pendingProps,null===t?Tc(e):Rs=t,Ts.current=null}function Tc(e){var t=e;do{var n=t.alternate;if(e=t.return,0==(2048&t.flags)){if(null!==(n=cs(n,t,$s)))return void(Rs=n);if(24!==(n=t).tag&&23!==n.tag||null===n.memoizedState||0!=(1073741824&$s)||0==(4&n.mode)){for(var r=0,o=n.child;null!==o;)r|=o.lanes|o.childLanes,o=o.sibling;n.childLanes=r}null!==e&&0==(2048&e.flags)&&(null===e.firstEffect&&(e.firstEffect=t.firstEffect),null!==t.lastEffect&&(null!==e.lastEffect&&(e.lastEffect.nextEffect=t.firstEffect),e.lastEffect=t.lastEffect),1<t.flags&&(null!==e.lastEffect?e.lastEffect.nextEffect=t:e.firstEffect=t,e.lastEffect=t))}else{if(null!==(n=us(t)))return n.flags&=2047,void(Rs=n);null!==e&&(e.firstEffect=e.lastEffect=null,e.flags|=2048)}if(null!==(t=t.sibling))return void(Rs=t);Rs=t=e}while(null!==t);0===Bs&&(Bs=5)}function Lc(e){var t=qi();return Ji(99,Mc.bind(null,e,t)),null}function Mc(e,t){do{zc()}while(null!==nc);if(0!=(48&Ls))throw Error(se(327));var n=e.finishedWork;if(null===n)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(se(177));e.callbackNode=null;var r=n.lanes|n.childLanes,o=r,i=e.pendingLanes&~o;e.pendingLanes=o,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=o,e.mutableReadLanes&=o,e.entangledLanes&=o,o=e.entanglements;for(var a=e.eventTimes,l=e.expirationTimes;0<i;){var s=31-qn(i),c=1<<s;o[s]=0,a[s]=-1,l[s]=-1,i&=~c}if(null!==ac&&0==(24&r)&&ac.has(e)&&ac.delete(e),e===Ms&&(Rs=Ms=null,zs=0),1<n.flags?null!==n.lastEffect?(n.lastEffect.nextEffect=n,r=n.firstEffect):r=n:r=n.firstEffect,null!==r){if(o=Ls,Ls|=32,Ts.current=null,Wo=Kn,bo(a=yo())){if("selectionStart"in a)l={start:a.selectionStart,end:a.selectionEnd};else e:if(l=(l=a.ownerDocument)&&l.defaultView||window,(c=l.getSelection&&l.getSelection())&&0!==c.rangeCount){l=c.anchorNode,i=c.anchorOffset,s=c.focusNode,c=c.focusOffset;try{l.nodeType,s.nodeType}catch(E){l=null;break e}var u=0,d=-1,f=-1,p=0,m=0,h=a,g=null;t:for(;;){for(var v;h!==l||0!==i&&3!==h.nodeType||(d=u+i),h!==s||0!==c&&3!==h.nodeType||(f=u+c),3===h.nodeType&&(u+=h.nodeValue.length),null!==(v=h.firstChild);)g=h,h=v;for(;;){if(h===a)break t;if(g===l&&++p===i&&(d=u),g===s&&++m===c&&(f=u),null!==(v=h.nextSibling))break;g=(h=g).parentNode}h=v}l=-1===d||-1===f?null:{start:d,end:f}}else l=null;l=l||{start:0,end:0}}else l=null;Vo={focusedElem:a,selectionRange:l},Kn=!1,fc=null,pc=!1,Ks=r;do{try{Rc()}catch(E){if(null===Ks)throw Error(se(330));Uc(Ks,E),Ks=Ks.nextEffect}}while(null!==Ks);fc=null,Ks=r;do{try{for(a=e;null!==Ks;){var y=Ks.flags;if(16&y&&bt(Ks.stateNode,""),128&y){var b=Ks.alternate;if(null!==b){var w=b.ref;null!==w&&("function"==typeof w?w(null):w.current=null)}}switch(1038&y){case 2:js(Ks),Ks.flags&=-3;break;case 6:js(Ks),Ks.flags&=-3,Os(Ks.alternate,Ks);break;case 1024:Ks.flags&=-1025;break;case 1028:Ks.flags&=-1025,Os(Ks.alternate,Ks);break;case 4:Os(Ks.alternate,Ks);break;case 8:As(a,l=Ks);var x=l.alternate;ks(l),null!==x&&ks(x)}Ks=Ks.nextEffect}}catch(E){if(null===Ks)throw Error(se(330));Uc(Ks,E),Ks=Ks.nextEffect}}while(null!==Ks);if(w=Vo,b=yo(),y=w.focusedElem,a=w.selectionRange,b!==y&&y&&y.ownerDocument&&vo(y.ownerDocument.documentElement,y)){null!==a&&bo(y)&&(b=a.start,void 0===(w=a.end)&&(w=b),"selectionStart"in y?(y.selectionStart=b,y.selectionEnd=Math.min(w,y.value.length)):(w=(b=y.ownerDocument||document)&&b.defaultView||window).getSelection&&(w=w.getSelection(),l=y.textContent.length,x=Math.min(a.start,l),a=void 0===a.end?x:Math.min(a.end,l),!w.extend&&x>a&&(l=a,a=x,x=l),l=go(y,x),i=go(y,a),l&&i&&(1!==w.rangeCount||w.anchorNode!==l.node||w.anchorOffset!==l.offset||w.focusNode!==i.node||w.focusOffset!==i.offset)&&((b=b.createRange()).setStart(l.node,l.offset),w.removeAllRanges(),x>a?(w.addRange(b),w.extend(i.node,i.offset)):(b.setEnd(i.node,i.offset),w.addRange(b))))),b=[];for(w=y;w=w.parentNode;)1===w.nodeType&&b.push({element:w,left:w.scrollLeft,top:w.scrollTop});for("function"==typeof y.focus&&y.focus(),y=0;y<b.length;y++)(w=b[y]).element.scrollLeft=w.left,w.element.scrollTop=w.top}Kn=!!Wo,Vo=Wo=null,e.current=n,Ks=r;do{try{for(y=e;null!==Ks;){var k=Ks.flags;if(36&k&&bs(y,Ks.alternate,Ks),128&k){b=void 0;var S=Ks.ref;if(null!==S){var j=Ks.stateNode;Ks.tag,b=j,"function"==typeof S?S(b):S.current=b}}Ks=Ks.nextEffect}}catch(E){if(null===Ks)throw Error(se(330));Uc(Ks,E),Ks=Ks.nextEffect}}while(null!==Ks);Ks=null,Bi(),Ls=o}else e.current=n;if(tc)tc=!1,nc=e,rc=t;else for(Ks=r;null!==Ks;)t=Ks.nextEffect,Ks.nextEffect=null,8&Ks.flags&&((k=Ks).sibling=null,k.stateNode=null),Ks=t;if(0===(r=e.pendingLanes)&&(ec=null),1===r?e===sc?lc++:(lc=0,sc=e):lc=0,n=n.stateNode,Ci&&"function"==typeof Ci.onCommitFiberRoot)try{Ci.onCommitFiberRoot(Ei,n,void 0,64==(64&n.current.flags))}catch(E){}if(yc(e,Hi()),Xs)throw Xs=!1,e=Zs,Zs=null,e;return 0!=(8&Ls)||Qi(),null}function Rc(){for(;null!==Ks;){var e=Ks.alternate;pc||null===fc||(0!=(8&Ks.flags)?tn(Ks,fc)&&(pc=!0):13===Ks.tag&&_s(e,Ks)&&tn(Ks,fc)&&(pc=!0));var t=Ks.flags;0!=(256&t)&&ys(e,Ks),0==(512&t)||tc||(tc=!0,Gi(97,(function(){return zc(),null}))),Ks=Ks.nextEffect}}function zc(){if(90!==rc){var e=97<rc?97:rc;return rc=90,Ji(e,Bc)}return!1}function $c(e,t){oc.push(t,e),tc||(tc=!0,Gi(97,(function(){return zc(),null})))}function Dc(e,t){ic.push(t,e),tc||(tc=!0,Gi(97,(function(){return zc(),null})))}function Bc(){if(null===nc)return!1;var e=nc;if(nc=null,0!=(48&Ls))throw Error(se(331));var t=Ls;Ls|=32;var n=ic;ic=[];for(var r=0;r<n.length;r+=2){var o=n[r],i=n[r+1],a=o.destroy;if(o.destroy=void 0,"function"==typeof a)try{a()}catch(s){if(null===i)throw Error(se(330));Uc(i,s)}}for(n=oc,oc=[],r=0;r<n.length;r+=2){o=n[r],i=n[r+1];try{var l=o.create;o.destroy=l()}catch(s){if(null===i)throw Error(se(330));Uc(i,s)}}for(l=e.current.firstEffect;null!==l;)e=l.nextEffect,l.nextEffect=null,8&l.flags&&(l.sibling=null,l.stateNode=null),l=e;return Ls=t,Qi(),!0}function Fc(e,t,n){pa(e,t=ms(0,t=ds(n,t),1)),t=mc(),null!==(e=vc(e,1))&&(Hn(e,1,t),yc(e,t))}function Uc(e,t){if(3===e.tag)Fc(e,e,t);else for(var n=e.return;null!==n;){if(3===n.tag){Fc(n,e,t);break}if(1===n.tag){var r=n.stateNode;if("function"==typeof n.type.getDerivedStateFromError||"function"==typeof r.componentDidCatch&&(null===ec||!ec.has(r))){var o=hs(n,e=ds(t,e),1);if(pa(n,o),o=mc(),null!==(n=vc(n,1)))Hn(n,1,o),yc(n,o);else if("function"==typeof r.componentDidCatch&&(null===ec||!ec.has(r)))try{r.componentDidCatch(t,e)}catch(i){}break}}n=n.return}}function Wc(e,t,n){var r=e.pingCache;null!==r&&r.delete(t),t=mc(),e.pingedLanes|=e.suspendedLanes&n,Ms===e&&(zs&n)===n&&(4===Bs||3===Bs&&(62914560&zs)===zs&&500>Hi()-Ys?Cc(e,0):Hs|=n),yc(e,t)}function Vc(e,t){var n=e.stateNode;null!==n&&n.delete(t),0===(t=0)&&(0==(2&(t=e.mode))?t=1:0==(4&t)?t=99===qi()?1:2:(0===uc&&(uc=Us),0===(t=Wn(62914560&~uc))&&(t=4194304))),n=mc(),null!==(e=vc(e,t))&&(Hn(e,t,n),yc(e,n))}function Hc(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.flags=0,this.lastEffect=this.firstEffect=this.nextEffect=null,this.childLanes=this.lanes=0,this.alternate=null}function qc(e,t,n,r){return new Hc(e,t,n,r)}function Yc(e){return!(!(e=e.prototype)||!e.isReactComponent)}function Jc(e,t){var n=e.alternate;return null===n?((n=qc(e.tag,t,e.key,e.mode)).elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.nextEffect=null,n.firstEffect=null,n.lastEffect=null),n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=null===t?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function Gc(e,t,n,r,o,i){var a=2;if(r=e,"function"==typeof e)Yc(e)&&(a=1);else if("string"==typeof e)a=5;else e:switch(e){case Ce:return Qc(n.children,o,i,t);case $e:a=8,o|=16;break;case Ae:a=8,o|=1;break;case Oe:return(e=qc(12,n,t,8|o)).elementType=Oe,e.type=Oe,e.lanes=i,e;case Ie:return(e=qc(13,n,t,o)).type=Ie,e.elementType=Ie,e.lanes=i,e;case Te:return(e=qc(19,n,t,o)).elementType=Te,e.lanes=i,e;case De:return Kc(n,o,i,t);case Be:return(e=qc(24,n,t,o)).elementType=Be,e.lanes=i,e;default:if("object"==typeof e&&null!==e)switch(e.$$typeof){case Ne:a=10;break e;case _e:a=9;break e;case Pe:a=11;break e;case Le:a=14;break e;case Me:a=16,r=null;break e;case Re:a=22;break e}throw Error(se(130,null==e?e:typeof e,""))}return(t=qc(a,n,t,o)).elementType=e,t.type=r,t.lanes=i,t}function Qc(e,t,n,r){return(e=qc(7,e,r,t)).lanes=n,e}function Kc(e,t,n,r){return(e=qc(23,e,r,t)).elementType=De,e.lanes=n,e}function Xc(e,t,n){return(e=qc(6,e,null,t)).lanes=n,e}function Zc(e,t,n){return(t=qc(4,null!==e.children?e.children:[],e.key,t)).lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function eu(e,t,n){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.pendingContext=this.context=null,this.hydrate=n,this.callbackNode=null,this.callbackPriority=0,this.eventTimes=Vn(0),this.expirationTimes=Vn(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Vn(0),this.mutableSourceEagerHydrationData=null}function tu(e,t,n,r){var o=t.current,i=mc(),a=hc(o);e:if(n){t:{if(Kt(n=n._reactInternals)!==n||1!==n.tag)throw Error(se(170));var l=n;do{switch(l.tag){case 3:l=l.stateNode.context;break t;case 1:if(bi(l.type)){l=l.stateNode.__reactInternalMemoizedMergedChildContext;break t}}l=l.return}while(null!==l);throw Error(se(171))}if(1===n.tag){var s=n.type;if(bi(s)){n=ki(n,s,l);break e}}n=l}else n=mi;return null===t.context?t.context=n:t.pendingContext=n,(t=fa(i,a)).payload={element:e},null!==(r=void 0===r?null:r)&&(t.callback=r),pa(o,t),gc(o,a,i),a}function nu(e){return(e=e.current).child?(e.child.tag,e.child.stateNode):null}function ru(e,t){if(null!==(e=e.memoizedState)&&null!==e.dehydrated){var n=e.retryLane;e.retryLane=0!==n&&n<t?n:t}}function ou(e,t){ru(e,t),(e=e.alternate)&&ru(e,t)}function iu(e,t,n){var r=null!=n&&null!=n.hydrationOptions&&n.hydrationOptions.mutableSources||null;if(n=new eu(e,t,null!=n&&!0===n.hydrate),t=qc(3,null,null,2===t?7:1===t?3:0),n.current=t,t.stateNode=n,ua(t),e[ni]=n.current,Lo(8===e.nodeType?e.parentNode:e),r)for(e=0;e<r.length;e++){var o=(t=r[e])._getVersion;o=o(t._source),null==n.mutableSourceEagerHydrationData?n.mutableSourceEagerHydrationData=[t,o]:n.mutableSourceEagerHydrationData.push(t,o)}this._internalRoot=n}function au(e){return!(!e||1!==e.nodeType&&9!==e.nodeType&&11!==e.nodeType&&(8!==e.nodeType||" react-mount-point-unstable "!==e.nodeValue))}function lu(e,t,n,r,o){var i=n._reactRootContainer;if(i){var a=i._internalRoot;if("function"==typeof o){var l=o;o=function(){var e=nu(a);l.call(e)}}tu(t,a,e,o)}else{if(i=n._reactRootContainer=function(e,t){if(t||(t=!(!(t=e?9===e.nodeType?e.documentElement:e.firstChild:null)||1!==t.nodeType||!t.hasAttribute("data-reactroot"))),!t)for(var n;n=e.lastChild;)e.removeChild(n);return new iu(e,0,t?{hydrate:!0}:void 0)}(n,r),a=i._internalRoot,"function"==typeof o){var s=o;o=function(){var e=nu(a);s.call(e)}}Sc((function(){tu(t,a,e,o)}))}return nu(a)}function su(e,t){var n=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!au(t))throw Error(se(200));return function(e,t,n){var r=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:Ee,key:null==r?null:""+r,children:e,containerInfo:t,implementation:n}}(e,t,null,n)}Qs=function(e,t,n){var r=t.lanes;if(null!==e)if(e.memoizedProps!==t.pendingProps||gi.current)$l=!0;else{if(0==(n&r)){switch($l=!1,t.tag){case 3:Jl(t),Ga();break;case 5:za(t);break;case 1:bi(t.type)&&Si(t);break;case 4:Ma(t,t.stateNode.containerInfo);break;case 10:r=t.memoizedProps.value;var o=t.type._context;pi(ea,o._currentValue),o._currentValue=r;break;case 13:if(null!==t.memoizedState)return 0!=(n&t.child.childLanes)?es(e,t,n):(pi(Da,1&Da.current),null!==(t=ls(e,t,n))?t.sibling:null);pi(Da,1&Da.current);break;case 19:if(r=0!=(n&t.childLanes),0!=(64&e.flags)){if(r)return as(e,t,n);t.flags|=64}if(null!==(o=t.memoizedState)&&(o.rendering=null,o.tail=null,o.lastEffect=null),pi(Da,Da.current),r)break;return null;case 23:case 24:return t.lanes=0,Wl(e,t,n)}return ls(e,t,n)}$l=0!=(16384&e.flags)}else $l=!1;switch(t.lanes=0,t.tag){case 2:if(r=t.type,null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),e=t.pendingProps,o=yi(t,hi.current),la(t,n),o=sl(null,t,r,e,o,n),t.flags|=1,"object"==typeof o&&null!==o&&"function"==typeof o.render&&void 0===o.$$typeof){if(t.tag=1,t.memoizedState=null,t.updateQueue=null,bi(r)){var i=!0;Si(t)}else i=!1;t.memoizedState=null!==o.state&&void 0!==o.state?o.state:null,ua(t);var a=r.getDerivedStateFromProps;"function"==typeof a&&ya(t,r,a,e),o.updater=ba,t.stateNode=o,o._reactInternals=t,Sa(t,r,e,n),t=Yl(null,t,r,!0,i,n)}else t.tag=0,Dl(null,t,o,n),t=t.child;return t;case 16:o=t.elementType;e:{switch(null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),e=t.pendingProps,o=(i=o._init)(o._payload),t.type=o,i=t.tag=function(e){if("function"==typeof e)return Yc(e)?1:0;if(null!=e){if((e=e.$$typeof)===Pe)return 11;if(e===Le)return 14}return 2}(o),e=Zi(o,e),i){case 0:t=Hl(null,t,o,e,n);break e;case 1:t=ql(null,t,o,e,n);break e;case 11:t=Bl(null,t,o,e,n);break e;case 14:t=Fl(null,t,o,Zi(o.type,e),r,n);break e}throw Error(se(306,o,""))}return t;case 0:return r=t.type,o=t.pendingProps,Hl(e,t,r,o=t.elementType===r?o:Zi(r,o),n);case 1:return r=t.type,o=t.pendingProps,ql(e,t,r,o=t.elementType===r?o:Zi(r,o),n);case 3:if(Jl(t),r=t.updateQueue,null===e||null===r)throw Error(se(282));if(r=t.pendingProps,o=null!==(o=t.memoizedState)?o.element:null,da(e,t),ha(t,r,null,n),(r=t.memoizedState.element)===o)Ga(),t=ls(e,t,n);else{if((i=(o=t.stateNode).hydrate)&&(Ua=Qo(t.stateNode.containerInfo.firstChild),Fa=t,i=Wa=!0),i){if(null!=(e=o.mutableSourceEagerHydrationData))for(o=0;o<e.length;o+=2)(i=e[o])._workInProgressVersionPrimary=e[o+1],Qa.push(i);for(n=Na(t,null,r,n),t.child=n;n;)n.flags=-3&n.flags|1024,n=n.sibling}else Dl(e,t,r,n),Ga();t=t.child}return t;case 5:return za(t),null===e&&qa(t),r=t.type,o=t.pendingProps,i=null!==e?e.memoizedProps:null,a=o.children,qo(r,o)?a=null:null!==i&&qo(r,i)&&(t.flags|=16),Vl(e,t),Dl(e,t,a,n),t.child;case 6:return null===e&&qa(t),null;case 13:return es(e,t,n);case 4:return Ma(t,t.stateNode.containerInfo),r=t.pendingProps,null===e?t.child=Oa(t,null,r,n):Dl(e,t,r,n),t.child;case 11:return r=t.type,o=t.pendingProps,Bl(e,t,r,o=t.elementType===r?o:Zi(r,o),n);case 7:return Dl(e,t,t.pendingProps,n),t.child;case 8:case 12:return Dl(e,t,t.pendingProps.children,n),t.child;case 10:e:{r=t.type._context,o=t.pendingProps,a=t.memoizedProps,i=o.value;var l=t.type._context;if(pi(ea,l._currentValue),l._currentValue=i,null!==a)if(l=a.value,0===(i=fo(l,i)?0:0|("function"==typeof r._calculateChangedBits?r._calculateChangedBits(l,i):1073741823))){if(a.children===o.children&&!gi.current){t=ls(e,t,n);break e}}else for(null!==(l=t.child)&&(l.return=t);null!==l;){var s=l.dependencies;if(null!==s){a=l.child;for(var c=s.firstContext;null!==c;){if(c.context===r&&0!=(c.observedBits&i)){1===l.tag&&((c=fa(-1,n&-n)).tag=2,pa(l,c)),l.lanes|=n,null!==(c=l.alternate)&&(c.lanes|=n),aa(l.return,n),s.lanes|=n;break}c=c.next}}else a=10===l.tag&&l.type===t.type?null:l.child;if(null!==a)a.return=l;else for(a=l;null!==a;){if(a===t){a=null;break}if(null!==(l=a.sibling)){l.return=a.return,a=l;break}a=a.return}l=a}Dl(e,t,o.children,n),t=t.child}return t;case 9:return o=t.type,r=(i=t.pendingProps).children,la(t,n),r=r(o=sa(o,i.unstable_observedBits)),t.flags|=1,Dl(e,t,r,n),t.child;case 14:return i=Zi(o=t.type,t.pendingProps),Fl(e,t,o,i=Zi(o.type,i),r,n);case 15:return Ul(e,t,t.type,t.pendingProps,r,n);case 17:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:Zi(r,o),null!==e&&(e.alternate=null,t.alternate=null,t.flags|=2),t.tag=1,bi(r)?(e=!0,Si(t)):e=!1,la(t,n),xa(t,r,o),Sa(t,r,o,n),Yl(null,t,r,!0,e,n);case 19:return as(e,t,n);case 23:case 24:return Wl(e,t,n)}throw Error(se(156,t.tag))},iu.prototype.render=function(e){tu(e,this._internalRoot,null,null)},iu.prototype.unmount=function(){var e=this._internalRoot,t=e.containerInfo;tu(null,e,null,(function(){t[ni]=null}))},nn=function(e){13===e.tag&&(gc(e,4,mc()),ou(e,4))},rn=function(e){13===e.tag&&(gc(e,67108864,mc()),ou(e,67108864))},on=function(e){if(13===e.tag){var t=mc(),n=hc(e);gc(e,n,t),ou(e,n)}},an=function(e,t){return t()},Ot=function(e,t,n){switch(t){case"input":if(ot(e,n),t=n.name,"radio"===n.type&&null!=t){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var o=li(r);if(!o)throw Error(se(90));Ze(r),ot(r,o)}}}break;case"textarea":dt(e,n);break;case"select":null!=(t=n.value)&&st(e,!!n.multiple,t,!1)}},Lt=kc,Mt=function(e,t,n,r,o){var i=Ls;Ls|=4;try{return Ji(98,e.bind(null,t,n,r,o))}finally{0===(Ls=i)&&(Gs(),Qi())}},Rt=function(){0==(49&Ls)&&(function(){if(null!==ac){var e=ac;ac=null,e.forEach((function(e){e.expiredLanes|=24&e.pendingLanes,yc(e,Hi())}))}Qi()}(),zc())},zt=function(e,t){var n=Ls;Ls|=2;try{return e(t)}finally{0===(Ls=n)&&(Gs(),Qi())}};var cu={Events:[ii,ai,li,It,Tt,zc,{current:!1}]},uu={findFiberByHostInstance:oi,bundleType:0,version:"17.0.2",rendererPackageName:"react-dom"},du={bundleType:uu.bundleType,version:uu.version,rendererPackageName:uu.rendererPackageName,rendererConfig:uu.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Se.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return null===(e=en(e))?null:e.stateNode},findFiberByHostInstance:uu.findFiberByHostInstance||function(){return null},findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null};if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var fu=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!fu.isDisabled&&fu.supportsFiber)try{Ei=fu.inject(du),Ci=fu}catch(vt){}}te.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=cu,te.createPortal=su,te.findDOMNode=function(e){if(null==e)return null;if(1===e.nodeType)return e;var t=e._reactInternals;if(void 0===t){if("function"==typeof e.render)throw Error(se(188));throw Error(se(268,Object.keys(e)))}return e=null===(e=en(t))?null:e.stateNode},te.flushSync=function(e,t){var n=Ls;if(0!=(48&n))return e(t);Ls|=1;try{if(e)return Ji(99,e.bind(null,t))}finally{Ls=n,Qi()}},te.hydrate=function(e,t,n){if(!au(t))throw Error(se(200));return lu(null,e,t,!0,n)},te.render=function(e,t,n){if(!au(t))throw Error(se(200));return lu(null,e,t,!1,n)},te.unmountComponentAtNode=function(e){if(!au(e))throw Error(se(40));return!!e._reactRootContainer&&(Sc((function(){lu(null,null,e,!1,(function(){e._reactRootContainer=null,e[ni]=null}))})),!0)},te.unstable_batchedUpdates=kc,te.unstable_createPortal=function(e,t){return su(e,t,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null)},te.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!au(n))throw Error(se(200));if(null==e||void 0===e._reactInternals)throw Error(se(38));return lu(e,t,n,!1,r)},te.version="17.0.2",function e(){if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(t){console.error(t)}}(),ee.exports=te;var pu=ee.exports;const mu=n(pu);let hu,gu,vu,yu={data:""},bu=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||yu,wu=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,xu=/\/\*[^]*?\*\/|  +/g,ku=/\n+/g,Su=(e,t)=>{let n="",r="",o="";for(let i in e){let a=e[i];"@"==i[0]?"i"==i[1]?n=i+" "+a+";":r+="f"==i[1]?Su(a,i):i+"{"+Su(a,"k"==i[1]?"":t)+"}":"object"==typeof a?r+=Su(a,t?t.replace(/([^,])+/g,(e=>i.replace(/(^:.*)|([^,])+/g,(t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)))):i):null!=a&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),o+=Su.p?Su.p(i,a):i+":"+a+";")}return n+(t&&o?t+"{"+o+"}":o)+r},ju={},Eu=e=>{if("object"==typeof e){let t="";for(let n in e)t+=n+Eu(e[n]);return t}return e},Cu=(e,t,n,r,o)=>{let i=Eu(e),a=ju[i]||(ju[i]=(e=>{let t=0,n=11;for(;t<e.length;)n=101*n+e.charCodeAt(t++)>>>0;return"go"+n})(i));if(!ju[a]){let t=i!==e?e:(e=>{let t,n,r=[{}];for(;t=wu.exec(e.replace(xu,""));)t[4]?r.shift():t[3]?(n=t[3].replace(ku," ").trim(),r.unshift(r[0][n]=r[0][n]||{})):r[0][t[1]]=t[2].replace(ku," ").trim();return r[0]})(e);ju[a]=Su(o?{["@keyframes "+a]:t}:t,n?"":"."+a)}let l=n&&ju.g?ju.g:null;return n&&(ju.g=ju[a]),s=ju[a],c=t,u=r,(d=l)?c.data=c.data.replace(d,s):-1===c.data.indexOf(s)&&(c.data=u?s+c.data:c.data+s),a;var s,c,u,d},Au=(e,t,n)=>e.reduce(((e,r,o)=>{let i=t[o];if(i&&i.call){let e=i(n),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":Su(e,""):!1===e?"":e}return e+r+(null==i?"":i)}),"");function Ou(e){let t=this||{},n=e.call?e(t.p):e;return Cu(n.unshift?n.raw?Au(n,[].slice.call(arguments,1),t.p):n.reduce(((e,n)=>Object.assign(e,n&&n.call?n(t.p):n)),{}):n,bu(t.target),t.g,t.o,t.k)}Ou.bind({g:1});let Nu=Ou.bind({k:1});function _u(e,t){let n=this||{};return function(){let r=arguments;function o(i,a){let l=Object.assign({},i),s=l.className||o.className;n.p=Object.assign({theme:gu&&gu()},l),n.o=/ *go\d+/.test(s),l.className=Ou.apply(n,r)+(s?" "+s:""),t&&(l.ref=a);let c=e;return e[0]&&(c=l.as||e,delete l.as),vu&&c[0]&&vu(l),hu(c,l)}return t?t(o):o}}var Pu=(e,t)=>(e=>"function"==typeof e)(e)?e(t):e,Iu=(()=>{let e=0;return()=>(++e).toString()})(),Tu=(()=>{let e;return()=>{if(void 0===e&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),Lu=new Map,Mu=e=>{if(Lu.has(e))return;let t=setTimeout((()=>{Lu.delete(e),Du({type:4,toastId:e})}),1e3);Lu.set(e,t)},Ru=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return t.toast.id&&(e=>{let t=Lu.get(e);t&&clearTimeout(t)})(t.toast.id),{...e,toasts:e.toasts.map((e=>e.id===t.toast.id?{...e,...t.toast}:e))};case 2:let{toast:n}=t;return e.toasts.find((e=>e.id===n.id))?Ru(e,{type:1,toast:n}):Ru(e,{type:0,toast:n});case 3:let{toastId:r}=t;return r?Mu(r):e.toasts.forEach((e=>{Mu(e.id)})),{...e,toasts:e.toasts.map((e=>e.id===r||void 0===r?{...e,visible:!1}:e))};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter((e=>e.id!==t.toastId))};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map((e=>({...e,pauseDuration:e.pauseDuration+o})))}}},zu=[],$u={toasts:[],pausedAt:void 0},Du=e=>{$u=Ru($u,e),zu.forEach((e=>{e($u)}))},Bu={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},Fu=e=>(t,n)=>{let r=((e,t="blank",n)=>({createdAt:Date.now(),visible:!0,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...n,id:(null==n?void 0:n.id)||Iu()}))(t,e,n);return Du({type:2,toast:r}),r.id},Uu=(e,t)=>Fu("blank")(e,t);Uu.error=Fu("error"),Uu.success=Fu("success"),Uu.loading=Fu("loading"),Uu.custom=Fu("custom"),Uu.dismiss=e=>{Du({type:3,toastId:e})},Uu.remove=e=>Du({type:4,toastId:e}),Uu.promise=(e,t,n)=>{let r=Uu.loading(t.loading,{...n,...null==n?void 0:n.loading});return e.then((e=>(Uu.success(Pu(t.success,e),{id:r,...n,...null==n?void 0:n.success}),e))).catch((e=>{Uu.error(Pu(t.error,e),{id:r,...n,...null==n?void 0:n.error})})),e};var Wu,Vu,Hu,qu,Yu=e=>{let{toasts:t,pausedAt:n}=((e={})=>{let[t,n]=W.useState($u);W.useEffect((()=>(zu.push(n),()=>{let e=zu.indexOf(n);e>-1&&zu.splice(e,1)})),[t]);let r=t.toasts.map((t=>{var n,r;return{...e,...e[t.type],...t,duration:t.duration||(null==(n=e[t.type])?void 0:n.duration)||(null==e?void 0:e.duration)||Bu[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}}));return{...t,toasts:r}})(e);W.useEffect((()=>{if(n)return;let e=Date.now(),r=t.map((t=>{if(t.duration===1/0)return;let n=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(!(n<0))return setTimeout((()=>Uu.dismiss(t.id)),n);t.visible&&Uu.dismiss(t.id)}));return()=>{r.forEach((e=>e&&clearTimeout(e)))}}),[t,n]);let r=W.useMemo((()=>({startPause:()=>{Du({type:5,time:Date.now()})},endPause:()=>{n&&Du({type:6,time:Date.now()})},updateHeight:(e,t)=>Du({type:1,toast:{id:e,height:t}}),calculateOffset:(e,n)=>{let{reverseOrder:r=!1,gutter:o=8,defaultPosition:i}=n||{},a=t.filter((t=>(t.position||i)===(e.position||i)&&t.height)),l=a.findIndex((t=>t.id===e.id)),s=a.filter(((e,t)=>t<l&&e.visible)).length;return a.filter((e=>e.visible)).slice(...r?[s+1]:[0,s]).reduce(((e,t)=>e+(t.height||0)+o),0)}})),[t,n]);return{toasts:t,handlers:r}},Ju=Nu`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Gu=Nu`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Qu=Nu`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,Ku=_u("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Ju} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Gu} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${Qu} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,Xu=Nu`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,Zu=_u("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${Xu} 1s linear infinite;
`,ed=Nu`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,td=Nu`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,nd=_u("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ed} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${td} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,rd=_u("div")`
  position: absolute;
`,od=_u("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,id=Nu`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ad=_u("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${id} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ld=({toast:e})=>{let{icon:t,type:n,iconTheme:r}=e;return void 0!==t?"string"==typeof t?W.createElement(ad,null,t):t:"blank"===n?null:W.createElement(od,null,W.createElement(Zu,{...r}),"loading"!==n&&W.createElement(rd,null,"error"===n?W.createElement(Ku,{...r}):W.createElement(nd,{...r})))},sd=e=>`\n0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}\n100% {transform: translate3d(0,0,0) scale(1); opacity:1;}\n`,cd=e=>`\n0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}\n100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}\n`,ud=_u("div",W.forwardRef)`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,dd=_u("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,fd=W.memo((({toast:e,position:t,style:n,children:r})=>{let o=null!=e&&e.height?((e,t)=>{let n=e.includes("top")?1:-1,[r,o]=Tu()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[sd(n),cd(n)];return{animation:t?`${Nu(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${Nu(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},i=W.createElement(ld,{toast:e}),a=W.createElement(dd,{...e.ariaProps},Pu(e.message,e));return W.createElement(ud,{className:e.className,style:{...o,...n,...e.style}},"function"==typeof r?r({icon:i,message:a}):W.createElement(W.Fragment,null,i,a))}));Wu=W.createElement,Su.p=Vu,hu=Wu,gu=Hu,vu=qu;var pd=Ou`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,md=({reverseOrder:e,position:t="top-center",toastOptions:n,gutter:r,children:o,containerStyle:i,containerClassName:a})=>{let{toasts:l,handlers:s}=Yu(n);return W.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:a,onMouseEnter:s.startPause,onMouseLeave:s.endPause},l.map((n=>{let i=n.position||t,a=((e,t)=>{let n=e.includes("top"),r=n?{top:0}:{bottom:0},o=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:Tu()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(n?1:-1)}px)`,...r,...o}})(i,s.calculateOffset(n,{reverseOrder:e,gutter:r,defaultPosition:t})),l=n.height?void 0:(e=>t=>{t&&setTimeout((()=>{let n=t.getBoundingClientRect();e(n)}))})((e=>{s.updateHeight(n.id,e.height)}));return W.createElement("div",{ref:l,className:n.visible?pd:"",key:n.id,style:a},"custom"===n.type?Pu(n.message,n):o?o(n):W.createElement(fd,{toast:n,position:i}))})))},hd=Uu;function gd(e,t){return(gd=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(e,t){return e.__proto__=t,e})(e,t)}function vd(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,gd(e,t)}Boolean("localhost"===window.location.hostname||"[::1]"===window.location.hostname||window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));var yd={exports:{}};function bd(){}function wd(){}wd.resetWarningCache=bd;yd.exports=function(){function e(e,t,n,r,o,i){if("SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"!==i){var a=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw a.name="Invariant Violation",a}}function t(){return e}e.isRequired=e;var n={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:t,element:e,elementType:e,instanceOf:t,node:e,objectOf:t,oneOf:t,oneOfType:t,shape:t,exact:t,checkPropTypes:wd,resetWarningCache:bd};return n.PropTypes=n,n}();const xd=n(yd.exports);function kd(){return kd=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},kd.apply(this,arguments)}function Sd(e){return"/"===e.charAt(0)}function jd(e,t){for(var n=t,r=n+1,o=e.length;r<o;n+=1,r+=1)e[n]=e[r];e.pop()}var Ed="Invariant failed";function Cd(e,t){if(!e)throw new Error(Ed)}function Ad(e){return"/"===e.charAt(0)?e:"/"+e}function Od(e,t){return function(e,t){return 0===e.toLowerCase().indexOf(t.toLowerCase())&&-1!=="/?#".indexOf(e.charAt(t.length))}(e,t)?e.substr(t.length):e}function Nd(e){return"/"===e.charAt(e.length-1)?e.slice(0,-1):e}function _d(e){var t=e.pathname,n=e.search,r=e.hash,o=t||"/";return n&&"?"!==n&&(o+="?"===n.charAt(0)?n:"?"+n),r&&"#"!==r&&(o+="#"===r.charAt(0)?r:"#"+r),o}function Pd(e,t,n,r){var o;"string"==typeof e?(o=function(e){var t=e||"/",n="",r="",o=t.indexOf("#");-1!==o&&(r=t.substr(o),t=t.substr(0,o));var i=t.indexOf("?");return-1!==i&&(n=t.substr(i),t=t.substr(0,i)),{pathname:t,search:"?"===n?"":n,hash:"#"===r?"":r}}(e),o.state=t):(void 0===(o=kd({},e)).pathname&&(o.pathname=""),o.search?"?"!==o.search.charAt(0)&&(o.search="?"+o.search):o.search="",o.hash?"#"!==o.hash.charAt(0)&&(o.hash="#"+o.hash):o.hash="",void 0!==t&&void 0===o.state&&(o.state=t));try{o.pathname=decodeURI(o.pathname)}catch(Wu){throw Wu instanceof URIError?new URIError('Pathname "'+o.pathname+'" could not be decoded. This is likely caused by an invalid percent-encoding.'):Wu}return n&&(o.key=n),r?o.pathname?"/"!==o.pathname.charAt(0)&&(o.pathname=function(e,t){void 0===t&&(t="");var n,r=e&&e.split("/")||[],o=t&&t.split("/")||[],i=e&&Sd(e),a=t&&Sd(t),l=i||a;if(e&&Sd(e)?o=r:r.length&&(o.pop(),o=o.concat(r)),!o.length)return"/";if(o.length){var s=o[o.length-1];n="."===s||".."===s||""===s}else n=!1;for(var c=0,u=o.length;u>=0;u--){var d=o[u];"."===d?jd(o,u):".."===d?(jd(o,u),c++):c&&(jd(o,u),c--)}if(!l)for(;c--;c)o.unshift("..");!l||""===o[0]||o[0]&&Sd(o[0])||o.unshift("");var f=o.join("/");return n&&"/"!==f.substr(-1)&&(f+="/"),f}(o.pathname,r.pathname)):o.pathname=r.pathname:o.pathname||(o.pathname="/"),o}function Id(){var e=null;var t=[];return{setPrompt:function(t){return e=t,function(){e===t&&(e=null)}},confirmTransitionTo:function(t,n,r,o){if(null!=e){var i="function"==typeof e?e(t,n):e;"string"==typeof i?"function"==typeof r?r(i,o):o(!0):o(!1!==i)}else o(!0)},appendListener:function(e){var n=!0;function r(){n&&e.apply(void 0,arguments)}return t.push(r),function(){n=!1,t=t.filter((function(e){return e!==r}))}},notifyListeners:function(){for(var e=arguments.length,n=new Array(e),r=0;r<e;r++)n[r]=arguments[r];t.forEach((function(e){return e.apply(void 0,n)}))}}}var Td=!("undefined"==typeof window||!window.document||!window.document.createElement);function Ld(e,t){t(window.confirm(e))}var Md="popstate",Rd="hashchange";function zd(){try{return window.history.state||{}}catch(Wu){return{}}}function $d(e){void 0===e&&(e={}),Td||Cd(!1);var t,n=window.history,r=(-1===(t=window.navigator.userAgent).indexOf("Android 2.")&&-1===t.indexOf("Android 4.0")||-1===t.indexOf("Mobile Safari")||-1!==t.indexOf("Chrome")||-1!==t.indexOf("Windows Phone"))&&window.history&&"pushState"in window.history,o=!(-1===window.navigator.userAgent.indexOf("Trident")),i=e,a=i.forceRefresh,l=void 0!==a&&a,s=i.getUserConfirmation,c=void 0===s?Ld:s,u=i.keyLength,d=void 0===u?6:u,f=e.basename?Nd(Ad(e.basename)):"";function p(e){var t=e||{},n=t.key,r=t.state,o=window.location,i=o.pathname+o.search+o.hash;return f&&(i=Od(i,f)),Pd(i,r,n)}function m(){return Math.random().toString(36).substr(2,d)}var h=Id();function g(e){kd(O,e),O.length=n.length,h.notifyListeners(O.location,O.action)}function v(e){(function(e){return void 0===e.state&&-1===navigator.userAgent.indexOf("CriOS")})(e)||w(p(e.state))}function y(){w(p(zd()))}var b=!1;function w(e){if(b)b=!1,g();else{h.confirmTransitionTo(e,"POP",c,(function(t){t?g({action:"POP",location:e}):function(e){var t=O.location,n=k.indexOf(t.key);-1===n&&(n=0);var r=k.indexOf(e.key);-1===r&&(r=0);var o=n-r;o&&(b=!0,j(o))}(e)}))}}var x=p(zd()),k=[x.key];function S(e){return f+_d(e)}function j(e){n.go(e)}var E=0;function C(e){1===(E+=e)&&1===e?(window.addEventListener(Md,v),o&&window.addEventListener(Rd,y)):0===E&&(window.removeEventListener(Md,v),o&&window.removeEventListener(Rd,y))}var A=!1;var O={length:n.length,action:"POP",location:x,createHref:S,push:function(e,t){var o="PUSH",i=Pd(e,t,m(),O.location);h.confirmTransitionTo(i,o,c,(function(e){if(e){var t=S(i),a=i.key,s=i.state;if(r)if(n.pushState({key:a,state:s},null,t),l)window.location.href=t;else{var c=k.indexOf(O.location.key),u=k.slice(0,c+1);u.push(i.key),k=u,g({action:o,location:i})}else window.location.href=t}}))},replace:function(e,t){var o="REPLACE",i=Pd(e,t,m(),O.location);h.confirmTransitionTo(i,o,c,(function(e){if(e){var t=S(i),a=i.key,s=i.state;if(r)if(n.replaceState({key:a,state:s},null,t),l)window.location.replace(t);else{var c=k.indexOf(O.location.key);-1!==c&&(k[c]=i.key),g({action:o,location:i})}else window.location.replace(t)}}))},go:j,goBack:function(){j(-1)},goForward:function(){j(1)},block:function(e){void 0===e&&(e=!1);var t=h.setPrompt(e);return A||(C(1),A=!0),function(){return A&&(A=!1,C(-1)),t()}},listen:function(e){var t=h.appendListener(e);return C(1),function(){C(-1),t()}}};return O}var Dd={exports:{}},Bd=Array.isArray||function(e){return"[object Array]"==Object.prototype.toString.call(e)};Dd.exports=Qd,Dd.exports.parse=Ud,Dd.exports.compile=function(e,t){return Vd(Ud(e,t),t)},Dd.exports.tokensToFunction=Vd,Dd.exports.tokensToRegExp=Gd;var Fd=new RegExp(["(\\\\.)","([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"].join("|"),"g");function Ud(e,t){for(var n,r=[],o=0,i=0,a="",l=t&&t.delimiter||"/";null!=(n=Fd.exec(e));){var s=n[0],c=n[1],u=n.index;if(a+=e.slice(i,u),i=u+s.length,c)a+=c[1];else{var d=e[i],f=n[2],p=n[3],m=n[4],h=n[5],g=n[6],v=n[7];a&&(r.push(a),a="");var y=null!=f&&null!=d&&d!==f,b="+"===g||"*"===g,w="?"===g||"*"===g,x=n[2]||l,k=m||h;r.push({name:p||o++,prefix:f||"",delimiter:x,optional:w,repeat:b,partial:y,asterisk:!!v,pattern:k?qd(k):v?".*":"[^"+Hd(x)+"]+?"})}}return i<e.length&&(a+=e.substr(i)),a&&r.push(a),r}function Wd(e){return encodeURI(e).replace(/[\/?#]/g,(function(e){return"%"+e.charCodeAt(0).toString(16).toUpperCase()}))}function Vd(e,t){for(var n=new Array(e.length),r=0;r<e.length;r++)"object"==typeof e[r]&&(n[r]=new RegExp("^(?:"+e[r].pattern+")$",Jd(t)));return function(t,r){for(var o="",i=t||{},a=(r||{}).pretty?Wd:encodeURIComponent,l=0;l<e.length;l++){var s=e[l];if("string"!=typeof s){var c,u=i[s.name];if(null==u){if(s.optional){s.partial&&(o+=s.prefix);continue}throw new TypeError('Expected "'+s.name+'" to be defined')}if(Bd(u)){if(!s.repeat)throw new TypeError('Expected "'+s.name+'" to not repeat, but received `'+JSON.stringify(u)+"`");if(0===u.length){if(s.optional)continue;throw new TypeError('Expected "'+s.name+'" to not be empty')}for(var d=0;d<u.length;d++){if(c=a(u[d]),!n[l].test(c))throw new TypeError('Expected all "'+s.name+'" to match "'+s.pattern+'", but received `'+JSON.stringify(c)+"`");o+=(0===d?s.prefix:s.delimiter)+c}}else{if(c=s.asterisk?encodeURI(u).replace(/[?#]/g,(function(e){return"%"+e.charCodeAt(0).toString(16).toUpperCase()})):a(u),!n[l].test(c))throw new TypeError('Expected "'+s.name+'" to match "'+s.pattern+'", but received "'+c+'"');o+=s.prefix+c}}else o+=s}return o}}function Hd(e){return e.replace(/([.+*?=^!:${}()[\]|\/\\])/g,"\\$1")}function qd(e){return e.replace(/([=!:$\/()])/g,"\\$1")}function Yd(e,t){return e.keys=t,e}function Jd(e){return e&&e.sensitive?"":"i"}function Gd(e,t,n){Bd(t)||(n=t||n,t=[]);for(var r=(n=n||{}).strict,o=!1!==n.end,i="",a=0;a<e.length;a++){var l=e[a];if("string"==typeof l)i+=Hd(l);else{var s=Hd(l.prefix),c="(?:"+l.pattern+")";t.push(l),l.repeat&&(c+="(?:"+s+c+")*"),i+=c=l.optional?l.partial?s+"("+c+")?":"(?:"+s+"("+c+"))?":s+"("+c+")"}}var u=Hd(n.delimiter||"/"),d=i.slice(-u.length)===u;return r||(i=(d?i.slice(0,-u.length):i)+"(?:"+u+"(?=$))?"),i+=o?"$":r&&d?"":"(?="+u+"|$)",Yd(new RegExp("^"+i,Jd(n)),t)}function Qd(e,t,n){return Bd(t)||(n=t||n,t=[]),n=n||{},e instanceof RegExp?function(e,t){var n=e.source.match(/\((?!\?)/g);if(n)for(var r=0;r<n.length;r++)t.push({name:r,prefix:null,delimiter:null,optional:!1,repeat:!1,partial:!1,asterisk:!1,pattern:null});return Yd(e,t)}(e,t):Bd(e)?function(e,t,n){for(var r=[],o=0;o<e.length;o++)r.push(Qd(e[o],t,n).source);return Yd(new RegExp("(?:"+r.join("|")+")",Jd(n)),t)}(e,t,n):function(e,t,n){return Gd(Ud(e,n),t,n)}(e,t,n)}const Kd=n(Dd.exports);var Xd={},Zd="function"==typeof Symbol&&Symbol.for,ef=Zd?Symbol.for("react.element"):60103,tf=Zd?Symbol.for("react.portal"):60106,nf=Zd?Symbol.for("react.fragment"):60107,rf=Zd?Symbol.for("react.strict_mode"):60108,of=Zd?Symbol.for("react.profiler"):60114,af=Zd?Symbol.for("react.provider"):60109,lf=Zd?Symbol.for("react.context"):60110,sf=Zd?Symbol.for("react.async_mode"):60111,cf=Zd?Symbol.for("react.concurrent_mode"):60111,uf=Zd?Symbol.for("react.forward_ref"):60112,df=Zd?Symbol.for("react.suspense"):60113,ff=Zd?Symbol.for("react.suspense_list"):60120,pf=Zd?Symbol.for("react.memo"):60115,mf=Zd?Symbol.for("react.lazy"):60116,hf=Zd?Symbol.for("react.block"):60121,gf=Zd?Symbol.for("react.fundamental"):60117,vf=Zd?Symbol.for("react.responder"):60118,yf=Zd?Symbol.for("react.scope"):60119;
/** @license React v16.13.1
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */function bf(e){if("object"==typeof e&&null!==e){var t=e.$$typeof;switch(t){case ef:switch(e=e.type){case sf:case cf:case nf:case of:case rf:case df:return e;default:switch(e=e&&e.$$typeof){case lf:case uf:case mf:case pf:case af:return e;default:return t}}case tf:return t}}}function wf(e){return bf(e)===cf}function xf(e,t){if(null==e)return{};var n,r,o={},i=Object.keys(e);for(r=0;r<i.length;r++)n=i[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}Xd.AsyncMode=sf,Xd.ConcurrentMode=cf,Xd.ContextConsumer=lf,Xd.ContextProvider=af,Xd.Element=ef,Xd.ForwardRef=uf,Xd.Fragment=nf,Xd.Lazy=mf,Xd.Memo=pf,Xd.Portal=tf,Xd.Profiler=of,Xd.StrictMode=rf,Xd.Suspense=df,Xd.isAsyncMode=function(e){return wf(e)||bf(e)===sf},Xd.isConcurrentMode=wf,Xd.isContextConsumer=function(e){return bf(e)===lf},Xd.isContextProvider=function(e){return bf(e)===af},Xd.isElement=function(e){return"object"==typeof e&&null!==e&&e.$$typeof===ef},Xd.isForwardRef=function(e){return bf(e)===uf},Xd.isFragment=function(e){return bf(e)===nf},Xd.isLazy=function(e){return bf(e)===mf},Xd.isMemo=function(e){return bf(e)===pf},Xd.isPortal=function(e){return bf(e)===tf},Xd.isProfiler=function(e){return bf(e)===of},Xd.isStrictMode=function(e){return bf(e)===rf},Xd.isSuspense=function(e){return bf(e)===df},Xd.isValidElementType=function(e){return"string"==typeof e||"function"==typeof e||e===nf||e===cf||e===of||e===rf||e===df||e===ff||"object"==typeof e&&null!==e&&(e.$$typeof===mf||e.$$typeof===pf||e.$$typeof===af||e.$$typeof===lf||e.$$typeof===uf||e.$$typeof===gf||e.$$typeof===vf||e.$$typeof===yf||e.$$typeof===hf)},Xd.typeOf=bf;var kf={exports:{}},Sf={},jf="function"==typeof Symbol&&Symbol.for,Ef=jf?Symbol.for("react.element"):60103,Cf=jf?Symbol.for("react.portal"):60106,Af=jf?Symbol.for("react.fragment"):60107,Of=jf?Symbol.for("react.strict_mode"):60108,Nf=jf?Symbol.for("react.profiler"):60114,_f=jf?Symbol.for("react.provider"):60109,Pf=jf?Symbol.for("react.context"):60110,If=jf?Symbol.for("react.async_mode"):60111,Tf=jf?Symbol.for("react.concurrent_mode"):60111,Lf=jf?Symbol.for("react.forward_ref"):60112,Mf=jf?Symbol.for("react.suspense"):60113,Rf=jf?Symbol.for("react.suspense_list"):60120,zf=jf?Symbol.for("react.memo"):60115,$f=jf?Symbol.for("react.lazy"):60116,Df=jf?Symbol.for("react.block"):60121,Bf=jf?Symbol.for("react.fundamental"):60117,Ff=jf?Symbol.for("react.responder"):60118,Uf=jf?Symbol.for("react.scope"):60119;function Wf(e){if("object"==typeof e&&null!==e){var t=e.$$typeof;switch(t){case Ef:switch(e=e.type){case If:case Tf:case Af:case Nf:case Of:case Mf:return e;default:switch(e=e&&e.$$typeof){case Pf:case Lf:case $f:case zf:case _f:return e;default:return t}}case Cf:return t}}}function Vf(e){return Wf(e)===Tf}Sf.AsyncMode=If,Sf.ConcurrentMode=Tf,Sf.ContextConsumer=Pf,Sf.ContextProvider=_f,Sf.Element=Ef,Sf.ForwardRef=Lf,Sf.Fragment=Af,Sf.Lazy=$f,Sf.Memo=zf,Sf.Portal=Cf,Sf.Profiler=Nf,Sf.StrictMode=Of,Sf.Suspense=Mf,Sf.isAsyncMode=function(e){return Vf(e)||Wf(e)===If},Sf.isConcurrentMode=Vf,Sf.isContextConsumer=function(e){return Wf(e)===Pf},Sf.isContextProvider=function(e){return Wf(e)===_f},Sf.isElement=function(e){return"object"==typeof e&&null!==e&&e.$$typeof===Ef},Sf.isForwardRef=function(e){return Wf(e)===Lf},Sf.isFragment=function(e){return Wf(e)===Af},Sf.isLazy=function(e){return Wf(e)===$f},Sf.isMemo=function(e){return Wf(e)===zf},Sf.isPortal=function(e){return Wf(e)===Cf},Sf.isProfiler=function(e){return Wf(e)===Nf},Sf.isStrictMode=function(e){return Wf(e)===Of},Sf.isSuspense=function(e){return Wf(e)===Mf},Sf.isValidElementType=function(e){return"string"==typeof e||"function"==typeof e||e===Af||e===Tf||e===Nf||e===Of||e===Mf||e===Rf||"object"==typeof e&&null!==e&&(e.$$typeof===$f||e.$$typeof===zf||e.$$typeof===_f||e.$$typeof===Pf||e.$$typeof===Lf||e.$$typeof===Bf||e.$$typeof===Ff||e.$$typeof===Uf||e.$$typeof===Df)},Sf.typeOf=Wf,kf.exports=Sf;var Hf=kf.exports,qf={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},Yf={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},Jf={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},Gf={};function Qf(e){return Hf.isMemo(e)?Jf:Gf[e.$$typeof]||qf}Gf[Hf.ForwardRef]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},Gf[Hf.Memo]=Jf;var Kf=Object.defineProperty,Xf=Object.getOwnPropertyNames,Zf=Object.getOwnPropertySymbols,ep=Object.getOwnPropertyDescriptor,tp=Object.getPrototypeOf,np=Object.prototype;var rp=function e(t,n,r){if("string"!=typeof n){if(np){var o=tp(n);o&&o!==np&&e(t,o,r)}var i=Xf(n);Zf&&(i=i.concat(Zf(n)));for(var a=Qf(t),l=Qf(n),s=0;s<i.length;++s){var c=i[s];if(!(Yf[c]||r&&r[c]||l&&l[c]||a&&a[c])){var u=ep(n,c);try{Kf(t,c,u)}catch(Wu){}}}}return t};const op=n(rp);var ip=1073741823,ap="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{};var lp=V.createContext||function(e,t){var n,r,o,i="__create-react-context-"+((ap[o="__global_unique_id__"]=(ap[o]||0)+1)+"__"),a=function(e){function n(){for(var t,n,r,o=arguments.length,i=new Array(o),a=0;a<o;a++)i[a]=arguments[a];return(t=e.call.apply(e,[this].concat(i))||this).emitter=(n=t.props.value,r=[],{on:function(e){r.push(e)},off:function(e){r=r.filter((function(t){return t!==e}))},get:function(){return n},set:function(e,t){n=e,r.forEach((function(e){return e(n,t)}))}}),t}vd(n,e);var r=n.prototype;return r.getChildContext=function(){var e;return(e={})[i]=this.emitter,e},r.componentWillReceiveProps=function(e){if(this.props.value!==e.value){var n,r=this.props.value,o=e.value;((i=r)===(a=o)?0!==i||1/i==1/a:i!=i&&a!=a)?n=0:(n="function"==typeof t?t(r,o):ip,0!==(n|=0)&&this.emitter.set(e.value,n))}var i,a},r.render=function(){return this.props.children},n}(V.Component);a.childContextTypes=((n={})[i]=xd.object.isRequired,n);var l=function(t){function n(){for(var e,n=arguments.length,r=new Array(n),o=0;o<n;o++)r[o]=arguments[o];return(e=t.call.apply(t,[this].concat(r))||this).observedBits=void 0,e.state={value:e.getValue()},e.onUpdate=function(t,n){0!=((0|e.observedBits)&n)&&e.setState({value:e.getValue()})},e}vd(n,t);var r=n.prototype;return r.componentWillReceiveProps=function(e){var t=e.observedBits;this.observedBits=null==t?ip:t},r.componentDidMount=function(){this.context[i]&&this.context[i].on(this.onUpdate);var e=this.props.observedBits;this.observedBits=null==e?ip:e},r.componentWillUnmount=function(){this.context[i]&&this.context[i].off(this.onUpdate)},r.getValue=function(){return this.context[i]?this.context[i].get():e},r.render=function(){return(e=this.props.children,Array.isArray(e)?e[0]:e)(this.state.value);var e},n}(V.Component);return l.contextTypes=((r={})[i]=xd.object,r),{Provider:a,Consumer:l}},sp=function(e){var t=lp();return t.displayName=e,t},cp=sp("Router-History"),up=sp("Router"),dp=function(e){function t(t){var n;return(n=e.call(this,t)||this).state={location:t.history.location},n._isMounted=!1,n._pendingLocation=null,t.staticContext||(n.unlisten=t.history.listen((function(e){n._pendingLocation=e}))),n}vd(t,e),t.computeRootMatch=function(e){return{path:"/",url:"/",params:{},isExact:"/"===e}};var n=t.prototype;return n.componentDidMount=function(){var e=this;this._isMounted=!0,this.unlisten&&this.unlisten(),this.props.staticContext||(this.unlisten=this.props.history.listen((function(t){e._isMounted&&e.setState({location:t})}))),this._pendingLocation&&this.setState({location:this._pendingLocation})},n.componentWillUnmount=function(){this.unlisten&&(this.unlisten(),this._isMounted=!1,this._pendingLocation=null)},n.render=function(){return V.createElement(up.Provider,{value:{history:this.props.history,location:this.state.location,match:t.computeRootMatch(this.state.location.pathname),staticContext:this.props.staticContext}},V.createElement(cp.Provider,{children:this.props.children||null,value:this.props.history}))},t}(V.Component);V.Component,V.Component;var fp={},pp=1e4,mp=0;function hp(e,t){void 0===t&&(t={}),("string"==typeof t||Array.isArray(t))&&(t={path:t});var n=t,r=n.path,o=n.exact,i=void 0!==o&&o,a=n.strict,l=void 0!==a&&a,s=n.sensitive,c=void 0!==s&&s;return[].concat(r).reduce((function(t,n){if(!n&&""!==n)return null;if(t)return t;var r=function(e,t){var n=""+t.end+t.strict+t.sensitive,r=fp[n]||(fp[n]={});if(r[e])return r[e];var o=[],i={regexp:Kd(e,o,t),keys:o};return mp<pp&&(r[e]=i,mp++),i}(n,{end:i,strict:l,sensitive:c}),o=r.regexp,a=r.keys,s=o.exec(e);if(!s)return null;var u=s[0],d=s.slice(1),f=e===u;return i&&!f?null:{path:n,url:"/"===n&&""===u?"/":u,isExact:f,params:a.reduce((function(e,t,n){return e[t.name]=d[n],e}),{})}}),null)}var gp=function(e){function t(){return e.apply(this,arguments)||this}return vd(t,e),t.prototype.render=function(){var e=this;return V.createElement(up.Consumer,null,(function(t){t||Cd(!1);var n=e.props.location||t.location,r=kd({},t,{location:n,match:e.props.computedMatch?e.props.computedMatch:e.props.path?hp(n.pathname,e.props):t.match}),o=e.props,i=o.children,a=o.component,l=o.render;return Array.isArray(i)&&function(e){return 0===V.Children.count(e)}(i)&&(i=null),V.createElement(up.Provider,{value:r},r.match?i?"function"==typeof i?i(r):i:a?V.createElement(a,r):l?l(r):null:"function"==typeof i?i(r):null)}))},t}(V.Component);V.Component,V.Component;var vp=V.useContext;function yp(){return vp(cp)}function bp(){var e=vp(up).match;return e?e.params:{}}var wp=function(e){function t(){for(var t,n=arguments.length,r=new Array(n),o=0;o<n;o++)r[o]=arguments[o];return(t=e.call.apply(e,[this].concat(r))||this).history=$d(t.props),t}return vd(t,e),t.prototype.render=function(){return V.createElement(dp,{history:this.history,children:this.props.children})},t}(V.Component);V.Component;var xp=function(e,t){return"function"==typeof e?e(t):e},kp=function(e,t){return"string"==typeof e?Pd(e,null,null,t):e},Sp=function(e){return e},jp=V.forwardRef;void 0===jp&&(jp=Sp);var Ep=jp((function(e,t){var n=e.innerRef,r=e.navigate,o=e.onClick,i=xf(e,["innerRef","navigate","onClick"]),a=i.target,l=kd({},i,{onClick:function(e){try{o&&o(e)}catch(nw){throw e.preventDefault(),nw}e.defaultPrevented||0!==e.button||a&&"_self"!==a||function(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}(e)||(e.preventDefault(),r())}});return l.ref=Sp!==jp&&t||n,V.createElement("a",l)})),Cp=jp((function(e,t){var n=e.component,r=void 0===n?Ep:n,o=e.replace,i=e.to,a=e.innerRef,l=xf(e,["component","replace","to","innerRef"]);return V.createElement(up.Consumer,null,(function(e){e||Cd(!1);var n=e.history,s=kp(xp(i,e.location),e.location),c=s?n.createHref(s):"",u=kd({},l,{href:c,navigate:function(){var t=xp(i,e.location),r=_d(e.location)===_d(kp(t));(o||r?n.replace:n.push)(t)}});return Sp!==jp?u.ref=t||a:u.innerRef=a,V.createElement(r,u)}))})),Ap=function(e){return e},Op=V.forwardRef;void 0===Op&&(Op=Ap),Op((function(e,t){var n=e["aria-current"],r=void 0===n?"page":n,o=e.activeClassName,i=void 0===o?"active":o,a=e.activeStyle,l=e.className,s=e.exact,c=e.isActive,u=e.location,d=e.sensitive,f=e.strict,p=e.style,m=e.to,h=e.innerRef,g=xf(e,["aria-current","activeClassName","activeStyle","className","exact","isActive","location","sensitive","strict","style","to","innerRef"]);return V.createElement(up.Consumer,null,(function(e){e||Cd(!1);var n=u||e.location,o=kp(xp(m,n),n),v=o.pathname,y=v&&v.replace(/([.+*?=^!:${}()[\]|/\\])/g,"\\$1"),b=y?hp(n.pathname,{path:y,exact:s,sensitive:d,strict:f}):null,w=!!(c?c(b,n):b),x="function"==typeof l?l(w):l,k="function"==typeof p?p(w):p;w&&(x=function(){for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];return t.filter((function(e){return e})).join(" ")}(x,i),k=kd({},k,a));var S=kd({"aria-current":w&&r||null,className:x,style:k,to:o},g);return Ap!==Op?S.ref=t||h:S.innerRef=h,V.createElement(Cp,S)}))}));var Np,_p={exports:{}},Pp={},Ip=Symbol.for("react.element"),Tp=Symbol.for("react.portal"),Lp=Symbol.for("react.fragment"),Mp=Symbol.for("react.strict_mode"),Rp=Symbol.for("react.profiler"),zp=Symbol.for("react.provider"),$p=Symbol.for("react.context"),Dp=Symbol.for("react.server_context"),Bp=Symbol.for("react.forward_ref"),Fp=Symbol.for("react.suspense"),Up=Symbol.for("react.suspense_list"),Wp=Symbol.for("react.memo"),Vp=Symbol.for("react.lazy"),Hp=Symbol.for("react.offscreen");function qp(e){if("object"==typeof e&&null!==e){var t=e.$$typeof;switch(t){case Ip:switch(e=e.type){case Lp:case Rp:case Mp:case Fp:case Up:return e;default:switch(e=e&&e.$$typeof){case Dp:case $p:case Bp:case Vp:case Wp:case zp:return e;default:return t}}case Tp:return t}}}Np=Symbol.for("react.module.reference"),Pp.ContextConsumer=$p,Pp.ContextProvider=zp,Pp.Element=Ip,Pp.ForwardRef=Bp,Pp.Fragment=Lp,Pp.Lazy=Vp,Pp.Memo=Wp,Pp.Portal=Tp,Pp.Profiler=Rp,Pp.StrictMode=Mp,Pp.Suspense=Fp,Pp.SuspenseList=Up,Pp.isAsyncMode=function(){return!1},Pp.isConcurrentMode=function(){return!1},Pp.isContextConsumer=function(e){return qp(e)===$p},Pp.isContextProvider=function(e){return qp(e)===zp},Pp.isElement=function(e){return"object"==typeof e&&null!==e&&e.$$typeof===Ip},Pp.isForwardRef=function(e){return qp(e)===Bp},Pp.isFragment=function(e){return qp(e)===Lp},Pp.isLazy=function(e){return qp(e)===Vp},Pp.isMemo=function(e){return qp(e)===Wp},Pp.isPortal=function(e){return qp(e)===Tp},Pp.isProfiler=function(e){return qp(e)===Rp},Pp.isStrictMode=function(e){return qp(e)===Mp},Pp.isSuspense=function(e){return qp(e)===Fp},Pp.isSuspenseList=function(e){return qp(e)===Up},Pp.isValidElementType=function(e){return"string"==typeof e||"function"==typeof e||e===Lp||e===Rp||e===Mp||e===Fp||e===Up||e===Hp||"object"==typeof e&&null!==e&&(e.$$typeof===Vp||e.$$typeof===Wp||e.$$typeof===zp||e.$$typeof===$p||e.$$typeof===Bp||e.$$typeof===Np||void 0!==e.getModuleId)},Pp.typeOf=qp,_p.exports=Pp;var Yp=_p.exports;function Jp(e){function t(e,r,s,c,f){for(var p,m,h,g,w,k=0,S=0,j=0,E=0,C=0,I=0,L=h=p=0,R=0,z=0,$=0,D=0,B=s.length,F=B-1,U="",W="",V="",H="";R<B;){if(m=s.charCodeAt(R),R===F&&0!==S+E+j+k&&(0!==S&&(m=47===S?10:47),E=j=k=0,B++,F++),0===S+E+j+k){if(R===F&&(0<z&&(U=U.replace(d,"")),0<U.trim().length)){switch(m){case 32:case 9:case 59:case 13:case 10:break;default:U+=s.charAt(R)}m=59}switch(m){case 123:for(p=(U=U.trim()).charCodeAt(0),h=1,D=++R;R<B;){switch(m=s.charCodeAt(R)){case 123:h++;break;case 125:h--;break;case 47:switch(m=s.charCodeAt(R+1)){case 42:case 47:e:{for(L=R+1;L<F;++L)switch(s.charCodeAt(L)){case 47:if(42===m&&42===s.charCodeAt(L-1)&&R+2!==L){R=L+1;break e}break;case 10:if(47===m){R=L+1;break e}}R=L}}break;case 91:m++;case 40:m++;case 34:case 39:for(;R++<F&&s.charCodeAt(R)!==m;);}if(0===h)break;R++}if(h=s.substring(D,R),0===p&&(p=(U=U.replace(u,"").trim()).charCodeAt(0)),64===p){switch(0<z&&(U=U.replace(d,"")),m=U.charCodeAt(1)){case 100:case 109:case 115:case 45:z=r;break;default:z=P}if(D=(h=t(r,z,h,m,f+1)).length,0<T&&(w=l(3,h,z=n(P,U,$),r,O,A,D,m,f,c),U=z.join(""),void 0!==w&&0===(D=(h=w.trim()).length)&&(m=0,h="")),0<D)switch(m){case 115:U=U.replace(x,a);case 100:case 109:case 45:h=U+"{"+h+"}";break;case 107:h=(U=U.replace(v,"$1 $2"))+"{"+h+"}",h=1===_||2===_&&i("@"+h,3)?"@-webkit-"+h+"@"+h:"@"+h;break;default:h=U+h,112===c&&(W+=h,h="")}else h=""}else h=t(r,n(r,U,$),h,c,f+1);V+=h,h=$=z=L=p=0,U="",m=s.charCodeAt(++R);break;case 125:case 59:if(1<(D=(U=(0<z?U.replace(d,""):U).trim()).length))switch(0===L&&(p=U.charCodeAt(0),45===p||96<p&&123>p)&&(D=(U=U.replace(" ",":")).length),0<T&&void 0!==(w=l(1,U,r,e,O,A,W.length,c,f,c))&&0===(D=(U=w.trim()).length)&&(U="\0\0"),p=U.charCodeAt(0),m=U.charCodeAt(1),p){case 0:break;case 64:if(105===m||99===m){H+=U+s.charAt(R);break}default:58!==U.charCodeAt(D-1)&&(W+=o(U,p,m,U.charCodeAt(2)))}$=z=L=p=0,U="",m=s.charCodeAt(++R)}}switch(m){case 13:case 10:47===S?S=0:0===1+p&&107!==c&&0<U.length&&(z=1,U+="\0"),0<T*M&&l(0,U,r,e,O,A,W.length,c,f,c),A=1,O++;break;case 59:case 125:if(0===S+E+j+k){A++;break}default:switch(A++,g=s.charAt(R),m){case 9:case 32:if(0===E+k+S)switch(C){case 44:case 58:case 9:case 32:g="";break;default:32!==m&&(g=" ")}break;case 0:g="\\0";break;case 12:g="\\f";break;case 11:g="\\v";break;case 38:0===E+S+k&&(z=$=1,g="\f"+g);break;case 108:if(0===E+S+k+N&&0<L)switch(R-L){case 2:112===C&&58===s.charCodeAt(R-3)&&(N=C);case 8:111===I&&(N=I)}break;case 58:0===E+S+k&&(L=R);break;case 44:0===S+j+E+k&&(z=1,g+="\r");break;case 34:case 39:0===S&&(E=E===m?0:0===E?m:E);break;case 91:0===E+S+j&&k++;break;case 93:0===E+S+j&&k--;break;case 41:0===E+S+k&&j--;break;case 40:if(0===E+S+k){if(0===p)if(2*C+3*I==533);else p=1;j++}break;case 64:0===S+j+E+k+L+h&&(h=1);break;case 42:case 47:if(!(0<E+k+j))switch(S){case 0:switch(2*m+3*s.charCodeAt(R+1)){case 235:S=47;break;case 220:D=R,S=42}break;case 42:47===m&&42===C&&D+2!==R&&(33===s.charCodeAt(D+2)&&(W+=s.substring(D,R+1)),g="",S=0)}}0===S&&(U+=g)}I=C,C=m,R++}if(0<(D=W.length)){if(z=r,0<T&&(void 0!==(w=l(2,W,z,e,O,A,D,c,f,c))&&0===(W=w).length))return H+W+V;if(W=z.join(",")+"{"+W+"}",0!=_*N){switch(2!==_||i(W,2)||(N=0),N){case 111:W=W.replace(b,":-moz-$1")+W;break;case 112:W=W.replace(y,"::-webkit-input-$1")+W.replace(y,"::-moz-$1")+W.replace(y,":-ms-input-$1")+W}N=0}}return H+W+V}function n(e,t,n){var o=t.trim().split(h);t=o;var i=o.length,a=e.length;switch(a){case 0:case 1:var l=0;for(e=0===a?"":e[0]+" ";l<i;++l)t[l]=r(e,t[l],n).trim();break;default:var s=l=0;for(t=[];l<i;++l)for(var c=0;c<a;++c)t[s++]=r(e[c]+" ",o[l],n).trim()}return t}function r(e,t,n){var r=t.charCodeAt(0);switch(33>r&&(r=(t=t.trim()).charCodeAt(0)),r){case 38:return t.replace(g,"$1"+e.trim());case 58:return e.trim()+t.replace(g,"$1"+e.trim());default:if(0<1*n&&0<t.indexOf("\f"))return t.replace(g,(58===e.charCodeAt(0)?"":"$1")+e.trim())}return e+t}function o(e,t,n,r){var a=e+";",l=2*t+3*n+4*r;if(944===l){e=a.indexOf(":",9)+1;var s=a.substring(e,a.length-1).trim();return s=a.substring(0,e).trim()+s+";",1===_||2===_&&i(s,1)?"-webkit-"+s+s:s}if(0===_||2===_&&!i(a,1))return a;switch(l){case 1015:return 97===a.charCodeAt(10)?"-webkit-"+a+a:a;case 951:return 116===a.charCodeAt(3)?"-webkit-"+a+a:a;case 963:return 110===a.charCodeAt(5)?"-webkit-"+a+a:a;case 1009:if(100!==a.charCodeAt(4))break;case 969:case 942:return"-webkit-"+a+a;case 978:return"-webkit-"+a+"-moz-"+a+a;case 1019:case 983:return"-webkit-"+a+"-moz-"+a+"-ms-"+a+a;case 883:if(45===a.charCodeAt(8))return"-webkit-"+a+a;if(0<a.indexOf("image-set(",11))return a.replace(C,"$1-webkit-$2")+a;break;case 932:if(45===a.charCodeAt(4))switch(a.charCodeAt(5)){case 103:return"-webkit-box-"+a.replace("-grow","")+"-webkit-"+a+"-ms-"+a.replace("grow","positive")+a;case 115:return"-webkit-"+a+"-ms-"+a.replace("shrink","negative")+a;case 98:return"-webkit-"+a+"-ms-"+a.replace("basis","preferred-size")+a}return"-webkit-"+a+"-ms-"+a+a;case 964:return"-webkit-"+a+"-ms-flex-"+a+a;case 1023:if(99!==a.charCodeAt(8))break;return"-webkit-box-pack"+(s=a.substring(a.indexOf(":",15)).replace("flex-","").replace("space-between","justify"))+"-webkit-"+a+"-ms-flex-pack"+s+a;case 1005:return p.test(a)?a.replace(f,":-webkit-")+a.replace(f,":-moz-")+a:a;case 1e3:switch(t=(s=a.substring(13).trim()).indexOf("-")+1,s.charCodeAt(0)+s.charCodeAt(t)){case 226:s=a.replace(w,"tb");break;case 232:s=a.replace(w,"tb-rl");break;case 220:s=a.replace(w,"lr");break;default:return a}return"-webkit-"+a+"-ms-"+s+a;case 1017:if(-1===a.indexOf("sticky",9))break;case 975:switch(t=(a=e).length-10,l=(s=(33===a.charCodeAt(t)?a.substring(0,t):a).substring(e.indexOf(":",7)+1).trim()).charCodeAt(0)+(0|s.charCodeAt(7))){case 203:if(111>s.charCodeAt(8))break;case 115:a=a.replace(s,"-webkit-"+s)+";"+a;break;case 207:case 102:a=a.replace(s,"-webkit-"+(102<l?"inline-":"")+"box")+";"+a.replace(s,"-webkit-"+s)+";"+a.replace(s,"-ms-"+s+"box")+";"+a}return a+";";case 938:if(45===a.charCodeAt(5))switch(a.charCodeAt(6)){case 105:return s=a.replace("-items",""),"-webkit-"+a+"-webkit-box-"+s+"-ms-flex-"+s+a;case 115:return"-webkit-"+a+"-ms-flex-item-"+a.replace(S,"")+a;default:return"-webkit-"+a+"-ms-flex-line-pack"+a.replace("align-content","").replace(S,"")+a}break;case 973:case 989:if(45!==a.charCodeAt(3)||122===a.charCodeAt(4))break;case 931:case 953:if(!0===E.test(e))return 115===(s=e.substring(e.indexOf(":")+1)).charCodeAt(0)?o(e.replace("stretch","fill-available"),t,n,r).replace(":fill-available",":stretch"):a.replace(s,"-webkit-"+s)+a.replace(s,"-moz-"+s.replace("fill-",""))+a;break;case 962:if(a="-webkit-"+a+(102===a.charCodeAt(5)?"-ms-"+a:"")+a,211===n+r&&105===a.charCodeAt(13)&&0<a.indexOf("transform",10))return a.substring(0,a.indexOf(";",27)+1).replace(m,"$1-webkit-$2")+a}return a}function i(e,t){var n=e.indexOf(1===t?":":"{"),r=e.substring(0,3!==t?n:10);return n=e.substring(n+1,e.length-1),L(2!==t?r:r.replace(j,"$1"),n,t)}function a(e,t){var n=o(t,t.charCodeAt(0),t.charCodeAt(1),t.charCodeAt(2));return n!==t+";"?n.replace(k," or ($1)").substring(4):"("+t+")"}function l(e,t,n,r,o,i,a,l,s,u){for(var d,f=0,p=t;f<T;++f)switch(d=I[f].call(c,e,p,n,r,o,i,a,l,s,u)){case void 0:case!1:case!0:case null:break;default:p=d}if(p!==t)return p}function s(e){return void 0!==(e=e.prefix)&&(L=null,e?"function"!=typeof e?_=1:(_=2,L=e):_=0),s}function c(e,n){var r=e;if(33>r.charCodeAt(0)&&(r=r.trim()),r=[r],0<T){var o=l(-1,n,r,r,O,A,0,0,0,0);void 0!==o&&"string"==typeof o&&(n=o)}var i=t(P,r,n,0,0);return 0<T&&(void 0!==(o=l(-2,i,r,r,O,A,i.length,0,0,0))&&(i=o)),"",N=0,A=O=1,i}var u=/^\0+/g,d=/[\0\r\f]/g,f=/: */g,p=/zoo|gra/,m=/([,: ])(transform)/g,h=/,\r+?/g,g=/([\t\r\n ])*\f?&/g,v=/@(k\w+)\s*(\S*)\s*/,y=/::(place)/g,b=/:(read-only)/g,w=/[svh]\w+-[tblr]{2}/,x=/\(\s*(.*)\s*\)/g,k=/([\s\S]*?);/g,S=/-self|flex-/g,j=/[^]*?(:[rp][el]a[\w-]+)[^]*/,E=/stretch|:\s*\w+\-(?:conte|avail)/,C=/([^-])(image-set\()/,A=1,O=1,N=0,_=1,P=[],I=[],T=0,L=null,M=0;return c.use=function e(t){switch(t){case void 0:case null:T=I.length=0;break;default:if("function"==typeof t)I[T++]=t;else if("object"==typeof t)for(var n=0,r=t.length;n<r;++n)e(t[n]);else M=0|!!t}return e},c.set=s,void 0!==e&&s(e),c}var Gp={animationIterationCount:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1};function Qp(e){var t=Object.create(null);return function(n){return void 0===t[n]&&(t[n]=e(n)),t[n]}}var Kp=/^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,Xp=Qp((function(e){return Kp.test(e)||111===e.charCodeAt(0)&&110===e.charCodeAt(1)&&e.charCodeAt(2)<91})),Zp={};function em(){return(em=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}var tm=function(e,t){for(var n=[e[0]],r=0,o=t.length;r<o;r+=1)n.push(t[r],e[r+1]);return n},nm=function(e){return null!==e&&"object"==typeof e&&"[object Object]"===(e.toString?e.toString():Object.prototype.toString.call(e))&&!Yp.typeOf(e)},rm=Object.freeze([]),om=Object.freeze({});function im(e){return"function"==typeof e}function am(e){return e.displayName||e.name||"Component"}function lm(e){return e&&"string"==typeof e.styledComponentId}var sm="undefined"!=typeof process&&(Zp.REACT_APP_SC_ATTR||Zp.SC_ATTR)||"data-styled",cm="undefined"!=typeof window&&"HTMLElement"in window,um=Boolean("boolean"==typeof SC_DISABLE_SPEEDY?SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==Zp.REACT_APP_SC_DISABLE_SPEEDY&&""!==Zp.REACT_APP_SC_DISABLE_SPEEDY?"false"!==Zp.REACT_APP_SC_DISABLE_SPEEDY&&Zp.REACT_APP_SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==Zp.SC_DISABLE_SPEEDY&&""!==Zp.SC_DISABLE_SPEEDY&&("false"!==Zp.SC_DISABLE_SPEEDY&&Zp.SC_DISABLE_SPEEDY));function dm(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];throw new Error("An error occurred. See https://git.io/JUIaE#"+e+" for more information."+(n.length>0?" Args: "+n.join(", "):""))}var fm=function(){function e(e){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=e}var t=e.prototype;return t.indexOfGroup=function(e){for(var t=0,n=0;n<e;n++)t+=this.groupSizes[n];return t},t.insertRules=function(e,t){if(e>=this.groupSizes.length){for(var n=this.groupSizes,r=n.length,o=r;e>=o;)(o<<=1)<0&&dm(16,""+e);this.groupSizes=new Uint32Array(o),this.groupSizes.set(n),this.length=o;for(var i=r;i<o;i++)this.groupSizes[i]=0}for(var a=this.indexOfGroup(e+1),l=0,s=t.length;l<s;l++)this.tag.insertRule(a,t[l])&&(this.groupSizes[e]++,a++)},t.clearGroup=function(e){if(e<this.length){var t=this.groupSizes[e],n=this.indexOfGroup(e),r=n+t;this.groupSizes[e]=0;for(var o=n;o<r;o++)this.tag.deleteRule(n)}},t.getGroup=function(e){var t="";if(e>=this.length||0===this.groupSizes[e])return t;for(var n=this.groupSizes[e],r=this.indexOfGroup(e),o=r+n,i=r;i<o;i++)t+=this.tag.getRule(i)+"/*!sc*/\n";return t},e}(),pm=new Map,mm=new Map,hm=1,gm=function(e){if(pm.has(e))return pm.get(e);for(;mm.has(hm);)hm++;var t=hm++;return pm.set(e,t),mm.set(t,e),t},vm=function(e){return mm.get(e)},ym=function(e,t){t>=hm&&(hm=t+1),pm.set(e,t),mm.set(t,e)},bm="style["+sm+'][data-styled-version="5.3.5"]',wm=new RegExp("^"+sm+'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)'),xm=function(e,t,n){for(var r,o=n.split(","),i=0,a=o.length;i<a;i++)(r=o[i])&&e.registerName(t,r)},km=function(e,t){for(var n=(t.textContent||"").split("/*!sc*/\n"),r=[],o=0,i=n.length;o<i;o++){var a=n[o].trim();if(a){var l=a.match(wm);if(l){var s=0|parseInt(l[1],10),c=l[2];0!==s&&(ym(c,s),xm(e,c,l[3]),e.getTag().insertRules(s,r)),r.length=0}else r.push(a)}}},Sm=function(e){var t=document.head,n=e||t,r=document.createElement("style"),o=function(e){for(var t=e.childNodes,n=t.length;n>=0;n--){var r=t[n];if(r&&1===r.nodeType&&r.hasAttribute(sm))return r}}(n),i=void 0!==o?o.nextSibling:null;r.setAttribute(sm,"active"),r.setAttribute("data-styled-version","5.3.5");var a="undefined"!=typeof window&&void 0!==window.__webpack_nonce__?window.__webpack_nonce__:null;return a&&r.setAttribute("nonce",a),n.insertBefore(r,i),r},jm=function(){function e(e){var t=this.element=Sm(e);t.appendChild(document.createTextNode("")),this.sheet=function(e){if(e.sheet)return e.sheet;for(var t=document.styleSheets,n=0,r=t.length;n<r;n++){var o=t[n];if(o.ownerNode===e)return o}dm(17)}(t),this.length=0}var t=e.prototype;return t.insertRule=function(e,t){try{return this.sheet.insertRule(t,e),this.length++,!0}catch(n){return!1}},t.deleteRule=function(e){this.sheet.deleteRule(e),this.length--},t.getRule=function(e){var t=this.sheet.cssRules[e];return void 0!==t&&"string"==typeof t.cssText?t.cssText:""},e}(),Em=function(){function e(e){var t=this.element=Sm(e);this.nodes=t.childNodes,this.length=0}var t=e.prototype;return t.insertRule=function(e,t){if(e<=this.length&&e>=0){var n=document.createTextNode(t),r=this.nodes[e];return this.element.insertBefore(n,r||null),this.length++,!0}return!1},t.deleteRule=function(e){this.element.removeChild(this.nodes[e]),this.length--},t.getRule=function(e){return e<this.length?this.nodes[e].textContent:""},e}(),Cm=function(){function e(e){this.rules=[],this.length=0}var t=e.prototype;return t.insertRule=function(e,t){return e<=this.length&&(this.rules.splice(e,0,t),this.length++,!0)},t.deleteRule=function(e){this.rules.splice(e,1),this.length--},t.getRule=function(e){return e<this.length?this.rules[e]:""},e}(),Am=cm,Om={isServer:!cm,useCSSOMInjection:!um},Nm=function(){function e(e,t,n){void 0===e&&(e=om),void 0===t&&(t={}),this.options=em({},Om,{},e),this.gs=t,this.names=new Map(n),this.server=!!e.isServer,!this.server&&cm&&Am&&(Am=!1,function(e){for(var t=document.querySelectorAll(bm),n=0,r=t.length;n<r;n++){var o=t[n];o&&"active"!==o.getAttribute(sm)&&(km(e,o),o.parentNode&&o.parentNode.removeChild(o))}}(this))}e.registerId=function(e){return gm(e)};var t=e.prototype;return t.reconstructWithOptions=function(t,n){return void 0===n&&(n=!0),new e(em({},this.options,{},t),this.gs,n&&this.names||void 0)},t.allocateGSInstance=function(e){return this.gs[e]=(this.gs[e]||0)+1},t.getTag=function(){return this.tag||(this.tag=(n=(t=this.options).isServer,r=t.useCSSOMInjection,o=t.target,e=n?new Cm(o):r?new jm(o):new Em(o),new fm(e)));var e,t,n,r,o},t.hasNameForId=function(e,t){return this.names.has(e)&&this.names.get(e).has(t)},t.registerName=function(e,t){if(gm(e),this.names.has(e))this.names.get(e).add(t);else{var n=new Set;n.add(t),this.names.set(e,n)}},t.insertRules=function(e,t,n){this.registerName(e,t),this.getTag().insertRules(gm(e),n)},t.clearNames=function(e){this.names.has(e)&&this.names.get(e).clear()},t.clearRules=function(e){this.getTag().clearGroup(gm(e)),this.clearNames(e)},t.clearTag=function(){this.tag=void 0},t.toString=function(){return function(e){for(var t=e.getTag(),n=t.length,r="",o=0;o<n;o++){var i=vm(o);if(void 0!==i){var a=e.names.get(i),l=t.getGroup(o);if(a&&l&&a.size){var s=sm+".g"+o+'[id="'+i+'"]',c="";void 0!==a&&a.forEach((function(e){e.length>0&&(c+=e+",")})),r+=""+l+s+'{content:"'+c+'"}/*!sc*/\n'}}}return r}(this)},e}(),_m=/(a)(d)/gi,Pm=function(e){return String.fromCharCode(e+(e>25?39:97))};function Im(e){var t,n="";for(t=Math.abs(e);t>52;t=t/52|0)n=Pm(t%52)+n;return(Pm(t%52)+n).replace(_m,"$1-$2")}var Tm=function(e,t){for(var n=t.length;n;)e=33*e^t.charCodeAt(--n);return e},Lm=function(e){return Tm(5381,e)};var Mm=Lm("5.3.5"),Rm=function(){function e(e,t,n){this.rules=e,this.staticRulesId="",this.isStatic=(void 0===n||n.isStatic)&&function(e){for(var t=0;t<e.length;t+=1){var n=e[t];if(im(n)&&!lm(n))return!1}return!0}(e),this.componentId=t,this.baseHash=Tm(Mm,t),this.baseStyle=n,Nm.registerId(t)}return e.prototype.generateAndInjectStyles=function(e,t,n){var r=this.componentId,o=[];if(this.baseStyle&&o.push(this.baseStyle.generateAndInjectStyles(e,t,n)),this.isStatic&&!n.hash)if(this.staticRulesId&&t.hasNameForId(r,this.staticRulesId))o.push(this.staticRulesId);else{var i=Qm(this.rules,e,t,n).join(""),a=Im(Tm(this.baseHash,i)>>>0);if(!t.hasNameForId(r,a)){var l=n(i,"."+a,void 0,r);t.insertRules(r,a,l)}o.push(a),this.staticRulesId=a}else{for(var s=this.rules.length,c=Tm(this.baseHash,n.hash),u="",d=0;d<s;d++){var f=this.rules[d];if("string"==typeof f)u+=f;else if(f){var p=Qm(f,e,t,n),m=Array.isArray(p)?p.join(""):p;c=Tm(c,m+d),u+=m}}if(u){var h=Im(c>>>0);if(!t.hasNameForId(r,h)){var g=n(u,"."+h,void 0,r);t.insertRules(r,h,g)}o.push(h)}}return o.join(" ")},e}(),zm=/^\s*\/\/.*$/gm,$m=[":","[",".","#"];var Dm=V.createContext();Dm.Consumer;var Bm=V.createContext(),Fm=(Bm.Consumer,new Nm),Um=function(e){var t,n,r,o,i=void 0===e?om:e,a=i.options,l=void 0===a?om:a,s=i.plugins,c=void 0===s?rm:s,u=new Jp(l),d=[],f=function(e){function t(t){if(t)try{e(t+"}")}catch(n){}}return function(n,r,o,i,a,l,s,c,u,d){switch(n){case 1:if(0===u&&64===r.charCodeAt(0))return e(r+";"),"";break;case 2:if(0===c)return r+"/*|*/";break;case 3:switch(c){case 102:case 112:return e(o[0]+r),"";default:return r+(0===d?"/*|*/":"")}case-2:r.split("/*|*/}").forEach(t)}}}((function(e){d.push(e)})),p=function(e,r,i){return 0===r&&-1!==$m.indexOf(i[n.length])||i.match(o)?e:"."+t};function m(e,i,a,l){void 0===l&&(l="&");var s=e.replace(zm,""),c=i&&a?a+" "+i+" { "+s+" }":s;return t=l,n=i,r=new RegExp("\\"+n+"\\b","g"),o=new RegExp("(\\"+n+"\\b){2,}"),u(a||!i?"":i,c)}return u.use([].concat(c,[function(e,t,o){2===e&&o.length&&o[0].lastIndexOf(n)>0&&(o[0]=o[0].replace(r,p))},f,function(e){if(-2===e){var t=d;return d=[],t}}])),m.hash=c.length?c.reduce((function(e,t){return t.name||dm(15),Tm(e,t.name)}),5381).toString():"",m}();var Wm=function(){function e(e,t){var n=this;this.inject=function(e,t){void 0===t&&(t=Um);var r=n.name+t.hash;e.hasNameForId(n.id,r)||e.insertRules(n.id,r,t(n.rules,r,"@keyframes"))},this.toString=function(){return dm(12,String(n.name))},this.name=e,this.id="sc-keyframes-"+e,this.rules=t}return e.prototype.getName=function(e){return void 0===e&&(e=Um),this.name+e.hash},e}(),Vm=/([A-Z])/,Hm=/([A-Z])/g,qm=/^ms-/,Ym=function(e){return"-"+e.toLowerCase()};function Jm(e){return Vm.test(e)?e.replace(Hm,Ym).replace(qm,"-ms-"):e}var Gm=function(e){return null==e||!1===e||""===e};function Qm(e,t,n,r){if(Array.isArray(e)){for(var o,i=[],a=0,l=e.length;a<l;a+=1)""!==(o=Qm(e[a],t,n,r))&&(Array.isArray(o)?i.push.apply(i,o):i.push(o));return i}return Gm(e)?"":lm(e)?"."+e.styledComponentId:im(e)?"function"!=typeof(s=e)||s.prototype&&s.prototype.isReactComponent||!t?e:Qm(e(t),t,n,r):e instanceof Wm?n?(e.inject(n,r),e.getName(r)):e:nm(e)?function e(t,n){var r,o,i=[];for(var a in t)t.hasOwnProperty(a)&&!Gm(t[a])&&(Array.isArray(t[a])&&t[a].isCss||im(t[a])?i.push(Jm(a)+":",t[a],";"):nm(t[a])?i.push.apply(i,e(t[a],a)):i.push(Jm(a)+": "+(r=a,(null==(o=t[a])||"boolean"==typeof o||""===o?"":"number"!=typeof o||0===o||r in Gp?String(o).trim():o+"px")+";")));return n?[n+" {"].concat(i,["}"]):i}(e):e.toString();var s}var Km=function(e){return Array.isArray(e)&&(e.isCss=!0),e};function Xm(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];return im(e)||nm(e)?Km(Qm(tm(rm,[e].concat(n)))):0===n.length&&1===e.length&&"string"==typeof e[0]?e:Km(Qm(tm(e,n)))}var Zm=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,eh=/(^-|-$)/g;function th(e){return e.replace(Zm,"-").replace(eh,"")}var nh=function(e){return Im(Lm(e)>>>0)};function rh(e){return"string"==typeof e&&!0}var oh=function(e){return"function"==typeof e||"object"==typeof e&&null!==e&&!Array.isArray(e)},ih=function(e){return"__proto__"!==e&&"constructor"!==e&&"prototype"!==e};function ah(e,t,n){var r=e[n];oh(t)&&oh(r)?lh(r,t):e[n]=t}function lh(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];for(var o=0,i=n;o<i.length;o++){var a=i[o];if(oh(a))for(var l in a)ih(l)&&ah(e,a[l],l)}return e}var sh=V.createContext();sh.Consumer;var ch={};function uh(e,t,n){var r,o=lm(e),i=!rh(e),a=t.attrs,l=void 0===a?rm:a,s=t.componentId,c=void 0===s?function(e,t){var n="string"!=typeof e?"sc":th(e);ch[n]=(ch[n]||0)+1;var r=n+"-"+nh("5.3.5"+n+ch[n]);return t?t+"-"+r:r}(t.displayName,t.parentComponentId):s,u=t.displayName,d=void 0===u?rh(r=e)?"styled."+r:"Styled("+am(r)+")":u,f=t.displayName&&t.componentId?th(t.displayName)+"-"+t.componentId:t.componentId||c,p=o&&e.attrs?Array.prototype.concat(e.attrs,l).filter(Boolean):l,m=t.shouldForwardProp;o&&e.shouldForwardProp&&(m=t.shouldForwardProp?function(n,r,o){return e.shouldForwardProp(n,r,o)&&t.shouldForwardProp(n,r,o)}:e.shouldForwardProp);var h,g=new Rm(n,f,o?e.componentStyle:void 0),v=g.isStatic&&0===l.length,y=function(e,t){return function(e,t,n,r){var o,i,a,l,s,c=e.attrs,u=e.componentStyle,d=e.defaultProps,f=e.foldedComponentIds,p=e.shouldForwardProp,m=e.styledComponentId,h=e.target,g=function(e,t,n){void 0===e&&(e=om);var r=em({},t,{theme:e}),o={};return n.forEach((function(e){var t,n,i,a=e;for(t in im(a)&&(a=a(r)),a)r[t]=o[t]="className"===t?(n=o[t],i=a[t],n&&i?n+" "+i:n||i):a[t]})),[r,o]}(function(e,t,n){return void 0===n&&(n=om),e.theme!==n.theme&&e.theme||t||n.theme}(t,W.useContext(sh),d)||om,t,c),v=g[0],y=g[1],b=(o=u,i=r,a=v,l=W.useContext(Dm)||Fm,s=W.useContext(Bm)||Um,i?o.generateAndInjectStyles(om,l,s):o.generateAndInjectStyles(a,l,s)),w=n,x=y.$as||t.$as||y.as||t.as||h,k=rh(x),S=y!==t?em({},t,{},y):t,j={};for(var E in S)"$"!==E[0]&&"as"!==E&&("forwardedAs"===E?j.as=S[E]:(p?p(E,Xp,x):!k||Xp(E))&&(j[E]=S[E]));return t.style&&y.style!==t.style&&(j.style=em({},t.style,{},y.style)),j.className=Array.prototype.concat(f,m,b!==m?b:null,t.className,y.className).filter(Boolean).join(" "),j.ref=w,W.createElement(x,j)}(h,e,t,v)};return y.displayName=d,(h=V.forwardRef(y)).attrs=p,h.componentStyle=g,h.displayName=d,h.shouldForwardProp=m,h.foldedComponentIds=o?Array.prototype.concat(e.foldedComponentIds,e.styledComponentId):rm,h.styledComponentId=f,h.target=o?e.target:e,h.withComponent=function(e){var r=t.componentId,o=function(e,t){if(null==e)return{};var n,r,o={},i=Object.keys(e);for(r=0;r<i.length;r++)n=i[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(t,["componentId"]),i=r&&r+"-"+(rh(e)?e:th(am(e)));return uh(e,em({},o,{attrs:p,componentId:i}),n)},Object.defineProperty(h,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(t){this._foldedDefaultProps=o?lh({},e.defaultProps,t):t}}),h.toString=function(){return"."+h.styledComponentId},i&&op(h,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0,withComponent:!0}),h}var dh=function(e){return function e(t,n,r){if(void 0===r&&(r=om),!Yp.isValidElementType(n))return dm(1,String(n));var o=function(){return t(n,r,Xm.apply(void 0,arguments))};return o.withConfig=function(o){return e(t,n,em({},r,{},o))},o.attrs=function(o){return e(t,n,em({},r,{attrs:Array.prototype.concat(r.attrs,o).filter(Boolean)}))},o}(uh,e)};function fh(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];var o=Xm.apply(void 0,[e].concat(n)).join(""),i=nh(o);return new Wm(i,o)}["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","textPath","tspan"].forEach((function(e){dh[e]=dh(e)}));const ph=dh.div`
  width: 100%;
  min-height: 100%;
  position: absolute;
  opacity: ${e=>e.visible?1:0};
  transition: opacity ease 300ms;
`;function mh({render:e,children:t}){const[n,r]=W.useState(!1),[o,i]=W.useState(!1);return W.useEffect((()=>{e?(i(!0),r(!0)):(i(!1),setTimeout((()=>{r(!1)}),300))}),[e]),Z.jsx(W.Fragment,{children:n&&Z.jsx(ph,{visible:o,children:t})})}const hh="data:image/svg+xml,%3c!DOCTYPE%20svg%20PUBLIC%20'-//W3C//DTD%20SVG%2020010904//EN'%20'http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd'%3e%3csvg%20version='1.0'%20xmlns='http://www.w3.org/2000/svg'%20width='294px'%20height='85px'%20viewBox='0%200%202940%20850'%20preserveAspectRatio='xMidYMid%20meet'%3e%3cg%20id='layer101'%20fill='%23db202c'%20stroke='none'%3e%3cpath%20d='M2776%20711%20l-39%20-6%20-36%20-122%20c-20%20-67%20-39%20-119%20-42%20-115%20-4%204%20-22%2053%20-40%20110%20l-33%20102%20-43%200%20c-24%200%20-43%20-4%20-43%20-8%200%20-5%2023%20-73%2051%20-151%20l50%20-142%20-45%20-130%20c-25%20-72%20-46%20-134%20-46%20-140%200%20-5%2021%20-9%2048%20-9%20l47%200%2029%2096%20c16%2052%2032%2097%2036%2099%203%202%2021%20-41%2039%20-96%20l32%20-99%2044%200%2044%200%20-45%20132%20c-24%2073%20-44%20141%20-44%20151%200%2010%2021%2085%2046%20165%2026%2081%2047%20151%2048%20156%202%2012%20-13%2014%20-58%207z'/%3e%3cpath%20d='M114%20673%20c3%20-21%2021%20-139%2040%20-263%2019%20-124%2038%20-244%2042%20-268%20l7%20-43%2071%203%2071%203%2046%20280%20c25%20154%2044%20283%2042%20288%20-2%204%20-24%207%20-47%207%20-47%200%20-56%20-11%20-56%20-73%200%20-28%20-1%20-28%20-57%20-25%20l-58%203%20-10%2060%20-10%2060%20-44%203%20-43%203%206%20-38z%20m196%20-184%20c0%20-15%20-31%20-213%20-37%20-239%20-7%20-27%20-41%20152%20-42%20220%20-1%2035%20-1%2036%2039%2032%2022%20-2%2040%20-8%2040%20-13z'/%3e%3cpath%20d='M480%20385%20l0%20-285%2059%200%2060%200%2015%2053%20c8%2028%2027%2097%2043%20152%20l28%20100%203%20-152%203%20-153%2044%200%2045%200%20-2%20273%20-3%20272%20-50%203%20-50%203%20-49%20-178%20c-27%20-98%20-53%20-182%20-57%20-188%20-5%20-5%20-9%2074%20-9%20182%200%20207%201%20203%20-56%20203%20l-24%200%200%20-285z'/%3e%3cpath%20d='M2378%20663%20c-17%20-4%20-18%20-26%20-18%20-284%20l0%20-279%2045%200%2045%200%200%20285%200%20285%20-27%20-1%20c-16%20-1%20-36%20-3%20-45%20-6z'/%3e%3cpath%20d='M2275%20655%20c-5%20-2%20-54%20-7%20-107%20-10%20l-98%20-7%200%20-269%200%20-269%2045%200%2045%200%202%20233%203%20232%2075%205%2075%205%200%2040%20c0%2038%20-12%2050%20-40%2040z'/%3e%3cpath%20d='M840%20371%20l0%20-271%2050%200%2050%200%20-2%20268%20-3%20267%20-47%203%20-48%203%200%20-270z'/%3e%3cpath%20d='M1000%20366%20l0%20-266%2068%200%2068%200%2028%20157%20c16%2087%2032%20166%2035%20176%204%2010%2020%20-61%2035%20-158%20l29%20-175%2068%200%2069%200%200%20260%200%20260%20-45%200%20-45%200%200%20-172%20c0%20-94%20-3%20-169%20-6%20-166%20-3%203%20-17%2079%20-32%20169%20l-28%20164%20-46%203%20-46%203%20-16%20-93%20c-45%20-250%20-40%20-243%20-46%20-63%20l-5%20160%20-42%203%20-43%203%200%20-265z'/%3e%3cpath%20d='M1780%20365%20l0%20-265%20126%200%20125%200%20-3%2033%20-3%2032%20-77%203%20-78%203%200%2079%200%2080%2060%200%2060%200%200%2035%200%2035%20-60%200%20-60%200%200%20115%200%20115%20-45%200%20-45%200%200%20-265z'/%3e%3cpath%20d='M1460%20360%20l0%20-260%20130%200%20130%200%200%2035%200%2035%20-80%200%20-80%200%200%2075%200%2075%2065%200%2065%200%200%2035%200%2035%20-65%200%20-65%200%200%2074%200%2075%2080%207%2080%207%200%2033%200%2034%20-130%200%20-130%200%200%20-260z'/%3e%3c/g%3e%3c/svg%3e";var gh,vh={},yh={exports:{}};(gh=yh).exports=function(e){return e&&e.__esModule?e:{default:e}},gh.exports.__esModule=!0,gh.exports.default=gh.exports;var bh=yh.exports,wh={};function xh(e){return null!==e&&"object"==typeof e&&e.constructor===Object}function kh(e){if(!xh(e))return e;const t={};return Object.keys(e).forEach((n=>{t[n]=kh(e[n])})),t}function Sh(e,t,n={clone:!0}){const r=n.clone?kd({},e):e;return xh(e)&&xh(t)&&Object.keys(t).forEach((o=>{"__proto__"!==o&&(xh(t[o])&&o in e&&xh(e[o])?r[o]=Sh(e[o],t[o],n):n.clone?r[o]=xh(t[o])?kh(t[o]):t[o]:r[o]=t[o])})),r}function jh(e){let t="https://mui.com/production-error/?code="+e;for(let n=1;n<arguments.length;n+=1)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified MUI error #"+e+"; visit "+t+" for the full message."}function Eh(e){if("string"!=typeof e)throw new Error(jh(7));return e.charAt(0).toUpperCase()+e.slice(1)}function Ch(e){return e&&e.ownerDocument||document}function Ah(e,t){"function"==typeof e?e(t):e&&(e.current=t)}const Oh="undefined"!=typeof window?W.useLayoutEffect:W.useEffect;let Nh=0;const _h=H["useId".toString()];let Ph,Ih=!0,Th=!1;const Lh={text:!0,search:!0,url:!0,tel:!0,email:!0,password:!0,number:!0,date:!0,month:!0,week:!0,time:!0,datetime:!0,"datetime-local":!0};function Mh(e){e.metaKey||e.altKey||e.ctrlKey||(Ih=!0)}function Rh(){Ih=!1}function zh(){"hidden"===this.visibilityState&&Th&&(Ih=!0)}function $h(e){const{target:t}=e;try{return t.matches(":focus-visible")}catch(n){}return Ih||function(e){const{type:t,tagName:n}=e;return!("INPUT"!==n||!Lh[t]||e.readOnly)||"TEXTAREA"===n&&!e.readOnly||!!e.isContentEditable}(t)}function Dh(e,t){const n=kd({},t);return Object.keys(e).forEach((r=>{if(r.toString().match(/^(components|slots)$/))n[r]=kd({},e[r],n[r]);else if(r.toString().match(/^(componentsProps|slotProps)$/)){const o=e[r]||{},i=t[r];n[r]={},i&&Object.keys(i)?o&&Object.keys(o)?(n[r]=kd({},i),Object.keys(o).forEach((e=>{n[r][e]=Dh(o[e],i[e])}))):n[r]=i:n[r]=o}else void 0===n[r]&&(n[r]=e[r])})),n}const Bh=e=>e,Fh=(()=>{let e=Bh;return{configure(t){e=t},generate:t=>e(t),reset(){e=Bh}}})(),Uh={active:"active",checked:"checked",completed:"completed",disabled:"disabled",error:"error",expanded:"expanded",focused:"focused",focusVisible:"focusVisible",open:"open",readOnly:"readOnly",required:"required",selected:"selected"};function Wh(e,t,n="Mui"){const r=Uh[t];return r?`${n}-${r}`:`${Fh.generate(e)}-${t}`}function Vh(e){var t,n,r="";if("string"==typeof e||"number"==typeof e)r+=e;else if("object"==typeof e)if(Array.isArray(e))for(t=0;t<e.length;t++)e[t]&&(n=Vh(e[t]))&&(r&&(r+=" "),r+=n);else for(t in e)e[t]&&(r&&(r+=" "),r+=t);return r}function Hh(){for(var e,t,n=0,r="";n<arguments.length;)(e=arguments[n++])&&(t=Vh(e))&&(r&&(r+=" "),r+=t);return r}var qh=function(){function e(e){var t=this;this._insertTag=function(e){var n;n=0===t.tags.length?t.insertionPoint?t.insertionPoint.nextSibling:t.prepend?t.container.firstChild:t.before:t.tags[t.tags.length-1].nextSibling,t.container.insertBefore(e,n),t.tags.push(e)},this.isSpeedy=void 0===e.speedy||e.speedy,this.tags=[],this.ctr=0,this.nonce=e.nonce,this.key=e.key,this.container=e.container,this.prepend=e.prepend,this.insertionPoint=e.insertionPoint,this.before=null}var t=e.prototype;return t.hydrate=function(e){e.forEach(this._insertTag)},t.insert=function(e){this.ctr%(this.isSpeedy?65e3:1)==0&&this._insertTag(function(e){var t=document.createElement("style");return t.setAttribute("data-emotion",e.key),void 0!==e.nonce&&t.setAttribute("nonce",e.nonce),t.appendChild(document.createTextNode("")),t.setAttribute("data-s",""),t}(this));var t=this.tags[this.tags.length-1];if(this.isSpeedy){var n=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]}(t);try{n.insertRule(e,n.cssRules.length)}catch(Wu){}}else t.appendChild(document.createTextNode(e));this.ctr++},t.flush=function(){this.tags.forEach((function(e){return e.parentNode&&e.parentNode.removeChild(e)})),this.tags=[],this.ctr=0},e}(),Yh="-ms-",Jh="-moz-",Gh="-webkit-",Qh="comm",Kh="rule",Xh="decl",Zh="@keyframes",eg=Math.abs,tg=String.fromCharCode,ng=Object.assign;function rg(e){return e.trim()}function og(e,t,n){return e.replace(t,n)}function ig(e,t){return e.indexOf(t)}function ag(e,t){return 0|e.charCodeAt(t)}function lg(e,t,n){return e.slice(t,n)}function sg(e){return e.length}function cg(e){return e.length}function ug(e,t){return t.push(e),e}var dg=1,fg=1,pg=0,mg=0,hg=0,gg="";function vg(e,t,n,r,o,i,a){return{value:e,root:t,parent:n,type:r,props:o,children:i,line:dg,column:fg,length:a,return:""}}function yg(e,t){return ng(vg("",null,null,"",null,null,0),e,{length:-e.length},t)}function bg(){return hg=mg<pg?ag(gg,mg++):0,fg++,10===hg&&(fg=1,dg++),hg}function wg(){return ag(gg,mg)}function xg(){return mg}function kg(e,t){return lg(gg,e,t)}function Sg(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function jg(e){return dg=fg=1,pg=sg(gg=e),mg=0,[]}function Eg(e){return gg="",e}function Cg(e){return rg(kg(mg-1,Ng(91===e?e+2:40===e?e+1:e)))}function Ag(e){for(;(hg=wg())&&hg<33;)bg();return Sg(e)>2||Sg(hg)>3?"":" "}function Og(e,t){for(;--t&&bg()&&!(hg<48||hg>102||hg>57&&hg<65||hg>70&&hg<97););return kg(e,xg()+(t<6&&32==wg()&&32==bg()))}function Ng(e){for(;bg();)switch(hg){case e:return mg;case 34:case 39:34!==e&&39!==e&&Ng(hg);break;case 40:41===e&&Ng(e);break;case 92:bg()}return mg}function _g(e,t){for(;bg()&&e+hg!==57&&(e+hg!==84||47!==wg()););return"/*"+kg(t,mg-1)+"*"+tg(47===e?e:bg())}function Pg(e){for(;!Sg(wg());)bg();return kg(e,mg)}function Ig(e){return Eg(Tg("",null,null,null,[""],e=jg(e),0,[0],e))}function Tg(e,t,n,r,o,i,a,l,s){for(var c=0,u=0,d=a,f=0,p=0,m=0,h=1,g=1,v=1,y=0,b="",w=o,x=i,k=r,S=b;g;)switch(m=y,y=bg()){case 40:if(108!=m&&58==ag(S,d-1)){-1!=ig(S+=og(Cg(y),"&","&\f"),"&\f")&&(v=-1);break}case 34:case 39:case 91:S+=Cg(y);break;case 9:case 10:case 13:case 32:S+=Ag(m);break;case 92:S+=Og(xg()-1,7);continue;case 47:switch(wg()){case 42:case 47:ug(Mg(_g(bg(),xg()),t,n),s);break;default:S+="/"}break;case 123*h:l[c++]=sg(S)*v;case 125*h:case 59:case 0:switch(y){case 0:case 125:g=0;case 59+u:-1==v&&(S=og(S,/\f/g,"")),p>0&&sg(S)-d&&ug(p>32?Rg(S+";",r,n,d-1):Rg(og(S," ","")+";",r,n,d-2),s);break;case 59:S+=";";default:if(ug(k=Lg(S,t,n,c,u,o,l,b,w=[],x=[],d),i),123===y)if(0===u)Tg(S,t,k,k,w,i,d,l,x);else switch(99===f&&110===ag(S,3)?100:f){case 100:case 108:case 109:case 115:Tg(e,k,k,r&&ug(Lg(e,k,k,0,0,o,l,b,o,w=[],d),x),o,x,d,l,r?w:x);break;default:Tg(S,k,k,k,[""],x,0,l,x)}}c=u=p=0,h=v=1,b=S="",d=a;break;case 58:d=1+sg(S),p=m;default:if(h<1)if(123==y)--h;else if(125==y&&0==h++&&125==(hg=mg>0?ag(gg,--mg):0,fg--,10===hg&&(fg=1,dg--),hg))continue;switch(S+=tg(y),y*h){case 38:v=u>0?1:(S+="\f",-1);break;case 44:l[c++]=(sg(S)-1)*v,v=1;break;case 64:45===wg()&&(S+=Cg(bg())),f=wg(),u=d=sg(b=S+=Pg(xg())),y++;break;case 45:45===m&&2==sg(S)&&(h=0)}}return i}function Lg(e,t,n,r,o,i,a,l,s,c,u){for(var d=o-1,f=0===o?i:[""],p=cg(f),m=0,h=0,g=0;m<r;++m)for(var v=0,y=lg(e,d+1,d=eg(h=a[m])),b=e;v<p;++v)(b=rg(h>0?f[v]+" "+y:og(y,/&\f/g,f[v])))&&(s[g++]=b);return vg(e,t,n,0===o?Kh:l,s,c,u)}function Mg(e,t,n){return vg(e,t,n,Qh,tg(hg),lg(e,2,-2),0)}function Rg(e,t,n,r){return vg(e,t,n,Xh,lg(e,0,r),lg(e,r+1,-1),r)}function zg(e,t){for(var n="",r=cg(e),o=0;o<r;o++)n+=t(e[o],o,e,t)||"";return n}function $g(e,t,n,r){switch(e.type){case"@layer":if(e.children.length)break;case"@import":case Xh:return e.return=e.return||e.value;case Qh:return"";case Zh:return e.return=e.value+"{"+zg(e.children,r)+"}";case Kh:e.value=e.props.join(",")}return sg(n=zg(e.children,r))?e.return=e.value+"{"+n+"}":""}var Dg=function(e,t,n){for(var r=0,o=0;r=o,o=wg(),38===r&&12===o&&(t[n]=1),!Sg(o);)bg();return kg(e,mg)},Bg=function(e,t){return Eg(function(e,t){var n=-1,r=44;do{switch(Sg(r)){case 0:38===r&&12===wg()&&(t[n]=1),e[n]+=Dg(mg-1,t,n);break;case 2:e[n]+=Cg(r);break;case 4:if(44===r){e[++n]=58===wg()?"&\f":"",t[n]=e[n].length;break}default:e[n]+=tg(r)}}while(r=bg());return e}(jg(e),t))},Fg=new WeakMap,Ug=function(e){if("rule"===e.type&&e.parent&&!(e.length<1)){for(var t=e.value,n=e.parent,r=e.column===n.column&&e.line===n.line;"rule"!==n.type;)if(!(n=n.parent))return;if((1!==e.props.length||58===t.charCodeAt(0)||Fg.get(n))&&!r){Fg.set(e,!0);for(var o=[],i=Bg(t,o),a=n.props,l=0,s=0;l<i.length;l++)for(var c=0;c<a.length;c++,s++)e.props[s]=o[l]?i[l].replace(/&\f/g,a[c]):a[c]+" "+i[l]}}},Wg=function(e){if("decl"===e.type){var t=e.value;108===t.charCodeAt(0)&&98===t.charCodeAt(2)&&(e.return="",e.value="")}};function Vg(e,t){switch(function(e,t){return 45^ag(e,0)?(((t<<2^ag(e,0))<<2^ag(e,1))<<2^ag(e,2))<<2^ag(e,3):0}(e,t)){case 5103:return Gh+"print-"+e+e;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return Gh+e+e;case 5349:case 4246:case 4810:case 6968:case 2756:return Gh+e+Jh+e+Yh+e+e;case 6828:case 4268:return Gh+e+Yh+e+e;case 6165:return Gh+e+Yh+"flex-"+e+e;case 5187:return Gh+e+og(e,/(\w+).+(:[^]+)/,Gh+"box-$1$2"+Yh+"flex-$1$2")+e;case 5443:return Gh+e+Yh+"flex-item-"+og(e,/flex-|-self/,"")+e;case 4675:return Gh+e+Yh+"flex-line-pack"+og(e,/align-content|flex-|-self/,"")+e;case 5548:return Gh+e+Yh+og(e,"shrink","negative")+e;case 5292:return Gh+e+Yh+og(e,"basis","preferred-size")+e;case 6060:return Gh+"box-"+og(e,"-grow","")+Gh+e+Yh+og(e,"grow","positive")+e;case 4554:return Gh+og(e,/([^-])(transform)/g,"$1"+Gh+"$2")+e;case 6187:return og(og(og(e,/(zoom-|grab)/,Gh+"$1"),/(image-set)/,Gh+"$1"),e,"")+e;case 5495:case 3959:return og(e,/(image-set\([^]*)/,Gh+"$1$`$1");case 4968:return og(og(e,/(.+:)(flex-)?(.*)/,Gh+"box-pack:$3"+Yh+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+Gh+e+e;case 4095:case 3583:case 4068:case 2532:return og(e,/(.+)-inline(.+)/,Gh+"$1$2")+e;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(sg(e)-1-t>6)switch(ag(e,t+1)){case 109:if(45!==ag(e,t+4))break;case 102:return og(e,/(.+:)(.+)-([^]+)/,"$1"+Gh+"$2-$3$1"+Jh+(108==ag(e,t+3)?"$3":"$2-$3"))+e;case 115:return~ig(e,"stretch")?Vg(og(e,"stretch","fill-available"),t)+e:e}break;case 4949:if(115!==ag(e,t+1))break;case 6444:switch(ag(e,sg(e)-3-(~ig(e,"!important")&&10))){case 107:return og(e,":",":"+Gh)+e;case 101:return og(e,/(.+:)([^;!]+)(;|!.+)?/,"$1"+Gh+(45===ag(e,14)?"inline-":"")+"box$3$1"+Gh+"$2$3$1"+Yh+"$2box$3")+e}break;case 5936:switch(ag(e,t+11)){case 114:return Gh+e+Yh+og(e,/[svh]\w+-[tblr]{2}/,"tb")+e;case 108:return Gh+e+Yh+og(e,/[svh]\w+-[tblr]{2}/,"tb-rl")+e;case 45:return Gh+e+Yh+og(e,/[svh]\w+-[tblr]{2}/,"lr")+e}return Gh+e+Yh+e+e}return e}var Hg=[function(e,t,n,r){if(e.length>-1&&!e.return)switch(e.type){case Xh:e.return=Vg(e.value,e.length);break;case Zh:return zg([yg(e,{value:og(e.value,"@","@"+Gh)})],r);case Kh:if(e.length)return function(e,t){return e.map(t).join("")}(e.props,(function(t){switch(function(e,t){return(e=t.exec(e))?e[0]:e}(t,/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":return zg([yg(e,{props:[og(t,/:(read-\w+)/,":-moz-$1")]})],r);case"::placeholder":return zg([yg(e,{props:[og(t,/:(plac\w+)/,":"+Gh+"input-$1")]}),yg(e,{props:[og(t,/:(plac\w+)/,":-moz-$1")]}),yg(e,{props:[og(t,/:(plac\w+)/,Yh+"input-$1")]})],r)}return""}))}}],qg=function(e){var t=e.key;if("css"===t){var n=document.querySelectorAll("style[data-emotion]:not([data-s])");Array.prototype.forEach.call(n,(function(e){-1!==e.getAttribute("data-emotion").indexOf(" ")&&(document.head.appendChild(e),e.setAttribute("data-s",""))}))}var r,o,i=e.stylisPlugins||Hg,a={},l=[];r=e.container||document.head,Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="'+t+' "]'),(function(e){for(var t=e.getAttribute("data-emotion").split(" "),n=1;n<t.length;n++)a[t[n]]=!0;l.push(e)}));var s,c,u,d,f=[$g,(d=function(e){s.insert(e)},function(e){e.root||(e=e.return)&&d(e)})],p=(c=[Ug,Wg].concat(i,f),u=cg(c),function(e,t,n,r){for(var o="",i=0;i<u;i++)o+=c[i](e,t,n,r)||"";return o});o=function(e,t,n,r){s=n,zg(Ig(e?e+"{"+t.styles+"}":t.styles),p),r&&(m.inserted[t.name]=!0)};var m={key:t,sheet:new qh({key:t,container:r,nonce:e.nonce,speedy:e.speedy,prepend:e.prepend,insertionPoint:e.insertionPoint}),nonce:e.nonce,inserted:a,registered:{},insert:o};return m.sheet.hydrate(l),m};var Yg=function(e,t,n){var r=e.key+"-"+t.name;!1===n&&void 0===e.registered[r]&&(e.registered[r]=t.styles)};var Jg={animationIterationCount:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},Gg=/[A-Z]|^ms/g,Qg=/_EMO_([^_]+?)_([^]*?)_EMO_/g,Kg=function(e){return 45===e.charCodeAt(1)},Xg=function(e){return null!=e&&"boolean"!=typeof e},Zg=Qp((function(e){return Kg(e)?e:e.replace(Gg,"-$&").toLowerCase()})),ev=function(e,t){switch(e){case"animation":case"animationName":if("string"==typeof t)return t.replace(Qg,(function(e,t,n){return nv={name:t,styles:n,next:nv},t}))}return 1===Jg[e]||Kg(e)||"number"!=typeof t||0===t?t:t+"px"};function tv(e,t,n){if(null==n)return"";if(void 0!==n.__emotion_styles)return n;switch(typeof n){case"boolean":return"";case"object":if(1===n.anim)return nv={name:n.name,styles:n.styles,next:nv},n.name;if(void 0!==n.styles){var r=n.next;if(void 0!==r)for(;void 0!==r;)nv={name:r.name,styles:r.styles,next:nv},r=r.next;return n.styles+";"}return function(e,t,n){var r="";if(Array.isArray(n))for(var o=0;o<n.length;o++)r+=tv(e,t,n[o])+";";else for(var i in n){var a=n[i];if("object"!=typeof a)null!=t&&void 0!==t[a]?r+=i+"{"+t[a]+"}":Xg(a)&&(r+=Zg(i)+":"+ev(i,a)+";");else if(!Array.isArray(a)||"string"!=typeof a[0]||null!=t&&void 0!==t[a[0]]){var l=tv(e,t,a);switch(i){case"animation":case"animationName":r+=Zg(i)+":"+l+";";break;default:r+=i+"{"+l+"}"}}else for(var s=0;s<a.length;s++)Xg(a[s])&&(r+=Zg(i)+":"+ev(i,a[s])+";")}return r}(e,t,n);case"function":if(void 0!==e){var o=nv,i=n(e);return nv=o,tv(e,t,i)}}if(null==t)return n;var a=t[n];return void 0!==a?a:n}var nv,rv=/label:\s*([^\s;\n{]+)\s*(;|$)/g,ov=!!W.useInsertionEffect&&W.useInsertionEffect||function(e){return e()},iv=W.createContext("undefined"!=typeof HTMLElement?qg({key:"css"}):null);iv.Provider;var av=W.createContext({}),lv=Xp,sv=function(e){return"theme"!==e},cv=function(e){return"string"==typeof e&&e.charCodeAt(0)>96?lv:sv},uv=function(e,t,n){var r;if(t){var o=t.shouldForwardProp;r=e.__emotion_forwardProp&&o?function(t){return e.__emotion_forwardProp(t)&&o(t)}:o}return"function"!=typeof r&&n&&(r=e.__emotion_forwardProp),r},dv=function(e){var t=e.cache,n=e.serialized,r=e.isStringTag;return Yg(t,n,r),ov((function(){return function(e,t,n){Yg(e,t,n);var r=e.key+"-"+t.name;if(void 0===e.inserted[t.name]){var o=t;do{e.insert(t===o?"."+r:"",o,e.sheet,!0),o=o.next}while(void 0!==o)}}(t,n,r)})),null},fv=function e(t,n){var r,o,i=t.__emotion_real===t,a=i&&t.__emotion_base||t;void 0!==n&&(r=n.label,o=n.target);var l=uv(t,n,i),s=l||cv(a),c=!s("as");return function(){var u=arguments,d=i&&void 0!==t.__emotion_styles?t.__emotion_styles.slice(0):[];if(void 0!==r&&d.push("label:"+r+";"),null==u[0]||void 0===u[0].raw)d.push.apply(d,u);else{d.push(u[0][0]);for(var f=u.length,p=1;p<f;p++)d.push(u[p],u[0][p])}var m,h=(m=function(e,t,n){var r,i,u,f,p=c&&e.as||a,m="",h=[],g=e;if(null==e.theme){for(var v in g={},e)g[v]=e[v];g.theme=W.useContext(av)}"string"==typeof e.className?(r=t.registered,i=h,u=e.className,f="",u.split(" ").forEach((function(e){void 0!==r[e]?i.push(r[e]+";"):f+=e+" "})),m=f):null!=e.className&&(m=e.className+" ");var y=function(e,t,n){if(1===e.length&&"object"==typeof e[0]&&null!==e[0]&&void 0!==e[0].styles)return e[0];var r=!0,o="";nv=void 0;var i=e[0];null==i||void 0===i.raw?(r=!1,o+=tv(n,t,i)):o+=i[0];for(var a=1;a<e.length;a++)o+=tv(n,t,e[a]),r&&(o+=i[a]);rv.lastIndex=0;for(var l,s="";null!==(l=rv.exec(o));)s+="-"+l[1];var c=function(e){for(var t,n=0,r=0,o=e.length;o>=4;++r,o-=4)t=1540483477*(65535&(t=255&e.charCodeAt(r)|(255&e.charCodeAt(++r))<<8|(255&e.charCodeAt(++r))<<16|(255&e.charCodeAt(++r))<<24))+(59797*(t>>>16)<<16),n=1540483477*(65535&(t^=t>>>24))+(59797*(t>>>16)<<16)^1540483477*(65535&n)+(59797*(n>>>16)<<16);switch(o){case 3:n^=(255&e.charCodeAt(r+2))<<16;case 2:n^=(255&e.charCodeAt(r+1))<<8;case 1:n=1540483477*(65535&(n^=255&e.charCodeAt(r)))+(59797*(n>>>16)<<16)}return(((n=1540483477*(65535&(n^=n>>>13))+(59797*(n>>>16)<<16))^n>>>15)>>>0).toString(36)}(o)+s;return{name:c,styles:o,next:nv}}(d.concat(h),t.registered,g);m+=t.key+"-"+y.name,void 0!==o&&(m+=" "+o);var b=c&&void 0===l?cv(p):s,w={};for(var x in e)c&&"as"===x||b(x)&&(w[x]=e[x]);return w.className=m,w.ref=n,W.createElement(W.Fragment,null,W.createElement(dv,{cache:t,serialized:y,isStringTag:"string"==typeof p}),W.createElement(p,w))},W.forwardRef((function(e,t){var n=W.useContext(iv);return m(e,n,t)})));return h.displayName=void 0!==r?r:"Styled("+("string"==typeof a?a:a.displayName||a.name||"Component")+")",h.defaultProps=t.defaultProps,h.__emotion_real=h,h.__emotion_base=a,h.__emotion_styles=d,h.__emotion_forwardProp=l,Object.defineProperty(h,"toString",{value:function(){return"."+o}}),h.withComponent=function(t,r){return e(t,kd({},n,r,{shouldForwardProp:uv(h,r,!0)})).apply(void 0,d)},h}}.bind();["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"].forEach((function(e){fv[e]=fv(e)}));const pv=["values","unit","step"],mv=e=>{const t=Object.keys(e).map((t=>({key:t,val:e[t]})))||[];return t.sort(((e,t)=>e.val-t.val)),t.reduce(((e,t)=>kd({},e,{[t.key]:t.val})),{})};const hv={borderRadius:4};function gv(e,t){return t?Sh(e,t,{clone:!1}):e}const vv={xs:0,sm:600,md:900,lg:1200,xl:1536},yv={keys:["xs","sm","md","lg","xl"],up:e=>`@media (min-width:${vv[e]}px)`};function bv(e,t,n){const r=e.theme||{};if(Array.isArray(t)){const e=r.breakpoints||yv;return t.reduce(((r,o,i)=>(r[e.up(e.keys[i])]=n(t[i]),r)),{})}if("object"==typeof t){const e=r.breakpoints||yv;return Object.keys(t).reduce(((r,o)=>{if(-1!==Object.keys(e.values||vv).indexOf(o)){r[e.up(o)]=n(t[o],o)}else{const e=o;r[e]=t[e]}return r}),{})}return n(t)}function wv(e,t,n=!0){if(!t||"string"!=typeof t)return null;if(e&&e.vars&&n){const n=`vars.${t}`.split(".").reduce(((e,t)=>e&&e[t]?e[t]:null),e);if(null!=n)return n}return t.split(".").reduce(((e,t)=>e&&null!=e[t]?e[t]:null),e)}function xv(e,t,n,r=n){let o;return o="function"==typeof e?e(n):Array.isArray(e)?e[n]||r:wv(e,n)||r,t&&(o=t(o,r,e)),o}function kv(e){const{prop:t,cssProperty:n=e.prop,themeKey:r,transform:o}=e,i=e=>{if(null==e[t])return null;const i=e[t],a=wv(e.theme,r)||{};return bv(e,i,(e=>{let r=xv(a,o,e);return e===r&&"string"==typeof e&&(r=xv(a,o,`${t}${"default"===e?"":Eh(e)}`,e)),!1===n?r:{[n]:r}}))};return i.propTypes={},i.filterProps=[t],i}const Sv={m:"margin",p:"padding"},jv={t:"Top",r:"Right",b:"Bottom",l:"Left",x:["Left","Right"],y:["Top","Bottom"]},Ev={marginX:"mx",marginY:"my",paddingX:"px",paddingY:"py"},Cv=function(e){const t={};return n=>(void 0===t[n]&&(t[n]=e(n)),t[n])}((e=>{if(e.length>2){if(!Ev[e])return[e];e=Ev[e]}const[t,n]=e.split(""),r=Sv[t],o=jv[n]||"";return Array.isArray(o)?o.map((e=>r+e)):[r+o]})),Av=["m","mt","mr","mb","ml","mx","my","margin","marginTop","marginRight","marginBottom","marginLeft","marginX","marginY","marginInline","marginInlineStart","marginInlineEnd","marginBlock","marginBlockStart","marginBlockEnd"],Ov=["p","pt","pr","pb","pl","px","py","padding","paddingTop","paddingRight","paddingBottom","paddingLeft","paddingX","paddingY","paddingInline","paddingInlineStart","paddingInlineEnd","paddingBlock","paddingBlockStart","paddingBlockEnd"];function Nv(e,t,n,r){var o;const i=null!=(o=wv(e,t,!1))?o:n;return"number"==typeof i?e=>"string"==typeof e?e:i*e:Array.isArray(i)?e=>"string"==typeof e?e:i[e]:"function"==typeof i?i:()=>{}}function _v(e){return Nv(e,"spacing",8)}function Pv(e,t){if("string"==typeof t||null==t)return t;const n=e(Math.abs(t));return t>=0?n:"number"==typeof n?-n:`-${n}`}function Iv(e,t,n,r){if(-1===t.indexOf(n))return null;const o=function(e,t){return n=>e.reduce(((e,r)=>(e[r]=Pv(t,n),e)),{})}(Cv(n),r);return bv(e,e[n],o)}function Tv(e,t){const n=_v(e.theme);return Object.keys(e).map((r=>Iv(e,t,r,n))).reduce(gv,{})}function Lv(e){return Tv(e,Av)}function Mv(e){return Tv(e,Ov)}function Rv(...e){const t=e.reduce(((e,t)=>(t.filterProps.forEach((n=>{e[n]=t})),e)),{}),n=e=>Object.keys(e).reduce(((n,r)=>t[r]?gv(n,t[r](e)):n),{});return n.propTypes={},n.filterProps=e.reduce(((e,t)=>e.concat(t.filterProps)),[]),n}function zv(e){return"number"!=typeof e?e:`${e}px solid`}Lv.propTypes={},Lv.filterProps=Av,Mv.propTypes={},Mv.filterProps=Ov;const $v=kv({prop:"border",themeKey:"borders",transform:zv}),Dv=kv({prop:"borderTop",themeKey:"borders",transform:zv}),Bv=kv({prop:"borderRight",themeKey:"borders",transform:zv}),Fv=kv({prop:"borderBottom",themeKey:"borders",transform:zv}),Uv=kv({prop:"borderLeft",themeKey:"borders",transform:zv}),Wv=kv({prop:"borderColor",themeKey:"palette"}),Vv=kv({prop:"borderTopColor",themeKey:"palette"}),Hv=kv({prop:"borderRightColor",themeKey:"palette"}),qv=kv({prop:"borderBottomColor",themeKey:"palette"}),Yv=kv({prop:"borderLeftColor",themeKey:"palette"}),Jv=e=>{if(void 0!==e.borderRadius&&null!==e.borderRadius){const t=Nv(e.theme,"shape.borderRadius",4),n=e=>({borderRadius:Pv(t,e)});return bv(e,e.borderRadius,n)}return null};Jv.propTypes={},Jv.filterProps=["borderRadius"],Rv($v,Dv,Bv,Fv,Uv,Wv,Vv,Hv,qv,Yv,Jv);const Gv=e=>{if(void 0!==e.gap&&null!==e.gap){const t=Nv(e.theme,"spacing",8),n=e=>({gap:Pv(t,e)});return bv(e,e.gap,n)}return null};Gv.propTypes={},Gv.filterProps=["gap"];const Qv=e=>{if(void 0!==e.columnGap&&null!==e.columnGap){const t=Nv(e.theme,"spacing",8),n=e=>({columnGap:Pv(t,e)});return bv(e,e.columnGap,n)}return null};Qv.propTypes={},Qv.filterProps=["columnGap"];const Kv=e=>{if(void 0!==e.rowGap&&null!==e.rowGap){const t=Nv(e.theme,"spacing",8),n=e=>({rowGap:Pv(t,e)});return bv(e,e.rowGap,n)}return null};Kv.propTypes={},Kv.filterProps=["rowGap"];function Xv(e,t){return"grey"===t?t:e}Rv(Gv,Qv,Kv,kv({prop:"gridColumn"}),kv({prop:"gridRow"}),kv({prop:"gridAutoFlow"}),kv({prop:"gridAutoColumns"}),kv({prop:"gridAutoRows"}),kv({prop:"gridTemplateColumns"}),kv({prop:"gridTemplateRows"}),kv({prop:"gridTemplateAreas"}),kv({prop:"gridArea"}));function Zv(e){return e<=1&&0!==e?100*e+"%":e}Rv(kv({prop:"color",themeKey:"palette",transform:Xv}),kv({prop:"bgcolor",cssProperty:"backgroundColor",themeKey:"palette",transform:Xv}),kv({prop:"backgroundColor",themeKey:"palette",transform:Xv}));const ey=kv({prop:"width",transform:Zv}),ty=e=>{if(void 0!==e.maxWidth&&null!==e.maxWidth){const t=t=>{var n,r;const o=(null==(n=e.theme)||null==(n=n.breakpoints)||null==(n=n.values)?void 0:n[t])||vv[t];return o?"px"!==(null==(r=e.theme)||null==(r=r.breakpoints)?void 0:r.unit)?{maxWidth:`${o}${e.theme.breakpoints.unit}`}:{maxWidth:o}:{maxWidth:Zv(t)}};return bv(e,e.maxWidth,t)}return null};ty.filterProps=["maxWidth"];const ny=kv({prop:"minWidth",transform:Zv}),ry=kv({prop:"height",transform:Zv}),oy=kv({prop:"maxHeight",transform:Zv}),iy=kv({prop:"minHeight",transform:Zv});kv({prop:"size",cssProperty:"width",transform:Zv}),kv({prop:"size",cssProperty:"height",transform:Zv});Rv(ey,ty,ny,ry,oy,iy,kv({prop:"boxSizing"}));const ay={border:{themeKey:"borders",transform:zv},borderTop:{themeKey:"borders",transform:zv},borderRight:{themeKey:"borders",transform:zv},borderBottom:{themeKey:"borders",transform:zv},borderLeft:{themeKey:"borders",transform:zv},borderColor:{themeKey:"palette"},borderTopColor:{themeKey:"palette"},borderRightColor:{themeKey:"palette"},borderBottomColor:{themeKey:"palette"},borderLeftColor:{themeKey:"palette"},borderRadius:{themeKey:"shape.borderRadius",style:Jv},color:{themeKey:"palette",transform:Xv},bgcolor:{themeKey:"palette",cssProperty:"backgroundColor",transform:Xv},backgroundColor:{themeKey:"palette",transform:Xv},p:{style:Mv},pt:{style:Mv},pr:{style:Mv},pb:{style:Mv},pl:{style:Mv},px:{style:Mv},py:{style:Mv},padding:{style:Mv},paddingTop:{style:Mv},paddingRight:{style:Mv},paddingBottom:{style:Mv},paddingLeft:{style:Mv},paddingX:{style:Mv},paddingY:{style:Mv},paddingInline:{style:Mv},paddingInlineStart:{style:Mv},paddingInlineEnd:{style:Mv},paddingBlock:{style:Mv},paddingBlockStart:{style:Mv},paddingBlockEnd:{style:Mv},m:{style:Lv},mt:{style:Lv},mr:{style:Lv},mb:{style:Lv},ml:{style:Lv},mx:{style:Lv},my:{style:Lv},margin:{style:Lv},marginTop:{style:Lv},marginRight:{style:Lv},marginBottom:{style:Lv},marginLeft:{style:Lv},marginX:{style:Lv},marginY:{style:Lv},marginInline:{style:Lv},marginInlineStart:{style:Lv},marginInlineEnd:{style:Lv},marginBlock:{style:Lv},marginBlockStart:{style:Lv},marginBlockEnd:{style:Lv},displayPrint:{cssProperty:!1,transform:e=>({"@media print":{display:e}})},display:{},overflow:{},textOverflow:{},visibility:{},whiteSpace:{},flexBasis:{},flexDirection:{},flexWrap:{},justifyContent:{},alignItems:{},alignContent:{},order:{},flex:{},flexGrow:{},flexShrink:{},alignSelf:{},justifyItems:{},justifySelf:{},gap:{style:Gv},rowGap:{style:Kv},columnGap:{style:Qv},gridColumn:{},gridRow:{},gridAutoFlow:{},gridAutoColumns:{},gridAutoRows:{},gridTemplateColumns:{},gridTemplateRows:{},gridTemplateAreas:{},gridArea:{},position:{},zIndex:{themeKey:"zIndex"},top:{},right:{},bottom:{},left:{},boxShadow:{themeKey:"shadows"},width:{transform:Zv},maxWidth:{style:ty},minWidth:{transform:Zv},height:{transform:Zv},maxHeight:{transform:Zv},minHeight:{transform:Zv},boxSizing:{},fontFamily:{themeKey:"typography"},fontSize:{themeKey:"typography"},fontStyle:{themeKey:"typography"},fontWeight:{themeKey:"typography"},letterSpacing:{},textTransform:{},lineHeight:{},textAlign:{},typography:{cssProperty:!1,themeKey:"typography"}};const ly=function(){function e(e,t,n,r){const o={[e]:t,theme:n},i=r[e];if(!i)return{[e]:t};const{cssProperty:a=e,themeKey:l,transform:s,style:c}=i;if(null==t)return null;if("typography"===l&&"inherit"===t)return{[e]:t};const u=wv(n,l)||{};if(c)return c(o);return bv(o,t,(t=>{let n=xv(u,s,t);return t===n&&"string"==typeof t&&(n=xv(u,s,`${e}${"default"===t?"":Eh(t)}`,t)),!1===a?n:{[a]:n}}))}return function t(n){var r;const{sx:o,theme:i={}}=n||{};if(!o)return null;const a=null!=(r=i.unstable_sxConfig)?r:ay;function l(n){let r=n;if("function"==typeof n)r=n(i);else if("object"!=typeof n)return n;if(!r)return null;const o=function(e={}){var t;return(null==(t=e.keys)?void 0:t.reduce(((t,n)=>(t[e.up(n)]={},t)),{}))||{}}(i.breakpoints),l=Object.keys(o);let s=o;return Object.keys(r).forEach((n=>{const o=(l=r[n],c=i,"function"==typeof l?l(c):l);var l,c;if(null!=o)if("object"==typeof o)if(a[n])s=gv(s,e(n,o,i,a));else{const e=bv({theme:i},o,(e=>({[n]:e})));!function(...e){const t=e.reduce(((e,t)=>e.concat(Object.keys(t))),[]),n=new Set(t);return e.every((e=>n.size===Object.keys(e).length))}(e,o)?s=gv(s,e):s[n]=t({sx:o,theme:i})}else s=gv(s,e(n,o,i,a))})),c=s,l.reduce(((e,t)=>{const n=e[t];return(!n||0===Object.keys(n).length)&&delete e[t],e}),c);var c}return Array.isArray(o)?o.map(l):l(o)}}();ly.filterProps=["sx"];const sy=["breakpoints","palette","spacing","shape"];function cy(e={},...t){const{breakpoints:n={},palette:r={},spacing:o,shape:i={}}=e,a=xf(e,sy),l=function(e){const{values:t={xs:0,sm:600,md:900,lg:1200,xl:1536},unit:n="px",step:r=5}=e,o=xf(e,pv),i=mv(t),a=Object.keys(i);function l(e){return`@media (min-width:${"number"==typeof t[e]?t[e]:e}${n})`}function s(e){return`@media (max-width:${("number"==typeof t[e]?t[e]:e)-r/100}${n})`}function c(e,o){const i=a.indexOf(o);return`@media (min-width:${"number"==typeof t[e]?t[e]:e}${n}) and (max-width:${(-1!==i&&"number"==typeof t[a[i]]?t[a[i]]:o)-r/100}${n})`}return kd({keys:a,values:i,up:l,down:s,between:c,only:function(e){return a.indexOf(e)+1<a.length?c(e,a[a.indexOf(e)+1]):l(e)},not:function(e){const t=a.indexOf(e);return 0===t?l(a[1]):t===a.length-1?s(a[t]):c(e,a[a.indexOf(e)+1]).replace("@media","@media not all and")},unit:n},o)}(n),s=function(e=8){if(e.mui)return e;const t=_v({spacing:e}),n=(...e)=>(0===e.length?[1]:e).map((e=>{const n=t(e);return"number"==typeof n?`${n}px`:n})).join(" ");return n.mui=!0,n}(o);let c=Sh({breakpoints:l,direction:"ltr",components:{},palette:kd({mode:"light"},r),spacing:s,shape:kd({},hv,i)},a);return c=t.reduce(((e,t)=>Sh(e,t)),c),c.unstable_sxConfig=kd({},ay,null==a?void 0:a.unstable_sxConfig),c.unstable_sx=function(e){return ly({sx:e,theme:this})},c}function uy(e=null){const t=W.useContext(av);return t&&(n=t,0!==Object.keys(n).length)?t:e;var n}const dy=cy();const fy=["variant"];function py(e){return 0===e.length}function my(e){const{variant:t}=e,n=xf(e,fy);let r=t||"";return Object.keys(n).sort().forEach((t=>{r+="color"===t?py(r)?e[t]:Eh(e[t]):`${py(r)?t:Eh(t)}${Eh(e[t].toString())}`})),r}const hy=["name","slot","skipVariantsResolver","skipSx","overridesResolver"];const gy=e=>{const t={};return e&&e.forEach((e=>{const n=my(e.props);t[n]=e.style})),t},vy=(e,t,n)=>{const{ownerState:r={}}=e,o=[];return n&&n.forEach((n=>{let i=!0;Object.keys(n.props).forEach((t=>{r[t]!==n.props[t]&&e[t]!==n.props[t]&&(i=!1)})),i&&o.push(t[my(n.props)])})),o};function yy(e){return"ownerState"!==e&&"theme"!==e&&"sx"!==e&&"as"!==e}const by=cy(),wy=e=>e?e.charAt(0).toLowerCase()+e.slice(1):e;function xy({defaultTheme:e,theme:t,themeId:n}){return r=t,0===Object.keys(r).length?e:t[n]||t;var r}function ky(e){return e?(t,n)=>n[e]:null}const Sy=({styledArg:e,props:t,defaultTheme:n,themeId:r})=>{const o=e(kd({},t,{theme:xy(kd({},t,{defaultTheme:n,themeId:r}))}));let i;if(o&&o.variants&&(i=o.variants,delete o.variants),i){return[o,...vy(t,gy(i),i)]}return o};function jy(e){const{theme:t,name:n,props:r}=e;return t&&t.components&&t.components[n]&&t.components[n].defaultProps?Dh(t.components[n].defaultProps,r):r}function Ey({props:e,name:t,defaultTheme:n,themeId:r}){let o=function(e=dy){return uy(e)}(n);r&&(o=o[r]||o);return jy({theme:o,name:t,props:e})}function Cy(e,t=0,n=1){return Math.min(Math.max(t,e),n)}function Ay(e){if(e.type)return e;if("#"===e.charAt(0))return Ay(function(e){e=e.slice(1);const t=new RegExp(`.{1,${e.length>=6?2:1}}`,"g");let n=e.match(t);return n&&1===n[0].length&&(n=n.map((e=>e+e))),n?`rgb${4===n.length?"a":""}(${n.map(((e,t)=>t<3?parseInt(e,16):Math.round(parseInt(e,16)/255*1e3)/1e3)).join(", ")})`:""}(e));const t=e.indexOf("("),n=e.substring(0,t);if(-1===["rgb","rgba","hsl","hsla","color"].indexOf(n))throw new Error(jh(9,e));let r,o=e.substring(t+1,e.length-1);if("color"===n){if(o=o.split(" "),r=o.shift(),4===o.length&&"/"===o[3].charAt(0)&&(o[3]=o[3].slice(1)),-1===["srgb","display-p3","a98-rgb","prophoto-rgb","rec-2020"].indexOf(r))throw new Error(jh(10,r))}else o=o.split(",");return o=o.map((e=>parseFloat(e))),{type:n,values:o,colorSpace:r}}function Oy(e){const{type:t,colorSpace:n}=e;let{values:r}=e;return-1!==t.indexOf("rgb")?r=r.map(((e,t)=>t<3?parseInt(e,10):e)):-1!==t.indexOf("hsl")&&(r[1]=`${r[1]}%`,r[2]=`${r[2]}%`),r=-1!==t.indexOf("color")?`${n} ${r.join(" ")}`:`${r.join(", ")}`,`${t}(${r})`}function Ny(e){let t="hsl"===(e=Ay(e)).type||"hsla"===e.type?Ay(function(e){e=Ay(e);const{values:t}=e,n=t[0],r=t[1]/100,o=t[2]/100,i=r*Math.min(o,1-o),a=(e,t=(e+n/30)%12)=>o-i*Math.max(Math.min(t-3,9-t,1),-1);let l="rgb";const s=[Math.round(255*a(0)),Math.round(255*a(8)),Math.round(255*a(4))];return"hsla"===e.type&&(l+="a",s.push(t[3])),Oy({type:l,values:s})}(e)).values:e.values;return t=t.map((t=>("color"!==e.type&&(t/=255),t<=.03928?t/12.92:((t+.055)/1.055)**2.4))),Number((.2126*t[0]+.7152*t[1]+.0722*t[2]).toFixed(3))}const _y={black:"#000",white:"#fff"},Py={50:"#fafafa",100:"#f5f5f5",200:"#eeeeee",300:"#e0e0e0",400:"#bdbdbd",500:"#9e9e9e",600:"#757575",700:"#616161",800:"#424242",900:"#212121",A100:"#f5f5f5",A200:"#eeeeee",A400:"#bdbdbd",A700:"#616161"},Iy={50:"#f3e5f5",100:"#e1bee7",200:"#ce93d8",300:"#ba68c8",400:"#ab47bc",500:"#9c27b0",600:"#8e24aa",700:"#7b1fa2",800:"#6a1b9a",900:"#4a148c",A100:"#ea80fc",A200:"#e040fb",A400:"#d500f9",A700:"#aa00ff"},Ty={50:"#ffebee",100:"#ffcdd2",200:"#ef9a9a",300:"#e57373",400:"#ef5350",500:"#f44336",600:"#e53935",700:"#d32f2f",800:"#c62828",900:"#b71c1c",A100:"#ff8a80",A200:"#ff5252",A400:"#ff1744",A700:"#d50000"},Ly={50:"#fff3e0",100:"#ffe0b2",200:"#ffcc80",300:"#ffb74d",400:"#ffa726",500:"#ff9800",600:"#fb8c00",700:"#f57c00",800:"#ef6c00",900:"#e65100",A100:"#ffd180",A200:"#ffab40",A400:"#ff9100",A700:"#ff6d00"},My={50:"#e3f2fd",100:"#bbdefb",200:"#90caf9",300:"#64b5f6",400:"#42a5f5",500:"#2196f3",600:"#1e88e5",700:"#1976d2",800:"#1565c0",900:"#0d47a1",A100:"#82b1ff",A200:"#448aff",A400:"#2979ff",A700:"#2962ff"},Ry={50:"#e1f5fe",100:"#b3e5fc",200:"#81d4fa",300:"#4fc3f7",400:"#29b6f6",500:"#03a9f4",600:"#039be5",700:"#0288d1",800:"#0277bd",900:"#01579b",A100:"#80d8ff",A200:"#40c4ff",A400:"#00b0ff",A700:"#0091ea"},zy={50:"#e8f5e9",100:"#c8e6c9",200:"#a5d6a7",300:"#81c784",400:"#66bb6a",500:"#4caf50",600:"#43a047",700:"#388e3c",800:"#2e7d32",900:"#1b5e20",A100:"#b9f6ca",A200:"#69f0ae",A400:"#00e676",A700:"#00c853"},$y=["mode","contrastThreshold","tonalOffset"],Dy={text:{primary:"rgba(0, 0, 0, 0.87)",secondary:"rgba(0, 0, 0, 0.6)",disabled:"rgba(0, 0, 0, 0.38)"},divider:"rgba(0, 0, 0, 0.12)",background:{paper:_y.white,default:_y.white},action:{active:"rgba(0, 0, 0, 0.54)",hover:"rgba(0, 0, 0, 0.04)",hoverOpacity:.04,selected:"rgba(0, 0, 0, 0.08)",selectedOpacity:.08,disabled:"rgba(0, 0, 0, 0.26)",disabledBackground:"rgba(0, 0, 0, 0.12)",disabledOpacity:.38,focus:"rgba(0, 0, 0, 0.12)",focusOpacity:.12,activatedOpacity:.12}},By={text:{primary:_y.white,secondary:"rgba(255, 255, 255, 0.7)",disabled:"rgba(255, 255, 255, 0.5)",icon:"rgba(255, 255, 255, 0.5)"},divider:"rgba(255, 255, 255, 0.12)",background:{paper:"#121212",default:"#121212"},action:{active:_y.white,hover:"rgba(255, 255, 255, 0.08)",hoverOpacity:.08,selected:"rgba(255, 255, 255, 0.16)",selectedOpacity:.16,disabled:"rgba(255, 255, 255, 0.3)",disabledBackground:"rgba(255, 255, 255, 0.12)",disabledOpacity:.38,focus:"rgba(255, 255, 255, 0.12)",focusOpacity:.12,activatedOpacity:.24}};function Fy(e,t,n,r){const o=r.light||r,i=r.dark||1.5*r;e[t]||(e.hasOwnProperty(n)?e[t]=e[n]:"light"===t?e.light=function(e,t){if(e=Ay(e),t=Cy(t),-1!==e.type.indexOf("hsl"))e.values[2]+=(100-e.values[2])*t;else if(-1!==e.type.indexOf("rgb"))for(let n=0;n<3;n+=1)e.values[n]+=(255-e.values[n])*t;else if(-1!==e.type.indexOf("color"))for(let n=0;n<3;n+=1)e.values[n]+=(1-e.values[n])*t;return Oy(e)}(e.main,o):"dark"===t&&(e.dark=function(e,t){if(e=Ay(e),t=Cy(t),-1!==e.type.indexOf("hsl"))e.values[2]*=1-t;else if(-1!==e.type.indexOf("rgb")||-1!==e.type.indexOf("color"))for(let n=0;n<3;n+=1)e.values[n]*=1-t;return Oy(e)}(e.main,i)))}function Uy(e){const{mode:t="light",contrastThreshold:n=3,tonalOffset:r=.2}=e,o=xf(e,$y),i=e.primary||function(e="light"){return"dark"===e?{main:My[200],light:My[50],dark:My[400]}:{main:My[700],light:My[400],dark:My[800]}}(t),a=e.secondary||function(e="light"){return"dark"===e?{main:Iy[200],light:Iy[50],dark:Iy[400]}:{main:Iy[500],light:Iy[300],dark:Iy[700]}}(t),l=e.error||function(e="light"){return"dark"===e?{main:Ty[500],light:Ty[300],dark:Ty[700]}:{main:Ty[700],light:Ty[400],dark:Ty[800]}}(t),s=e.info||function(e="light"){return"dark"===e?{main:Ry[400],light:Ry[300],dark:Ry[700]}:{main:Ry[700],light:Ry[500],dark:Ry[900]}}(t),c=e.success||function(e="light"){return"dark"===e?{main:zy[400],light:zy[300],dark:zy[700]}:{main:zy[800],light:zy[500],dark:zy[900]}}(t),u=e.warning||function(e="light"){return"dark"===e?{main:Ly[400],light:Ly[300],dark:Ly[700]}:{main:"#ed6c02",light:Ly[500],dark:Ly[900]}}(t);function d(e){const t=function(e,t){const n=Ny(e),r=Ny(t);return(Math.max(n,r)+.05)/(Math.min(n,r)+.05)}(e,By.text.primary)>=n?By.text.primary:Dy.text.primary;return t}const f=({color:e,name:t,mainShade:n=500,lightShade:o=300,darkShade:i=700})=>{if(!(e=kd({},e)).main&&e[n]&&(e.main=e[n]),!e.hasOwnProperty("main"))throw new Error(jh(11,t?` (${t})`:"",n));if("string"!=typeof e.main)throw new Error(jh(12,t?` (${t})`:"",JSON.stringify(e.main)));return Fy(e,"light",o,r),Fy(e,"dark",i,r),e.contrastText||(e.contrastText=d(e.main)),e},p={dark:By,light:Dy};return Sh(kd({common:kd({},_y),mode:t,primary:f({color:i,name:"primary"}),secondary:f({color:a,name:"secondary",mainShade:"A400",lightShade:"A200",darkShade:"A700"}),error:f({color:l,name:"error"}),warning:f({color:u,name:"warning"}),info:f({color:s,name:"info"}),success:f({color:c,name:"success"}),grey:Py,contrastThreshold:n,getContrastText:d,augmentColor:f,tonalOffset:r},p[t]),o)}const Wy=["fontFamily","fontSize","fontWeightLight","fontWeightRegular","fontWeightMedium","fontWeightBold","htmlFontSize","allVariants","pxToRem"];const Vy={textTransform:"uppercase"},Hy='"Roboto", "Helvetica", "Arial", sans-serif';function qy(e,t){const n="function"==typeof t?t(e):t,{fontFamily:r=Hy,fontSize:o=14,fontWeightLight:i=300,fontWeightRegular:a=400,fontWeightMedium:l=500,fontWeightBold:s=700,htmlFontSize:c=16,allVariants:u,pxToRem:d}=n,f=xf(n,Wy),p=o/14,m=d||(e=>e/c*p+"rem"),h=(e,t,n,o,i)=>{return kd({fontFamily:r,fontWeight:e,fontSize:m(t),lineHeight:n},r===Hy?{letterSpacing:(a=o/t,Math.round(1e5*a)/1e5)+"em"}:{},i,u);var a},g={h1:h(i,96,1.167,-1.5),h2:h(i,60,1.2,-.5),h3:h(a,48,1.167,0),h4:h(a,34,1.235,.25),h5:h(a,24,1.334,0),h6:h(l,20,1.6,.15),subtitle1:h(a,16,1.75,.15),subtitle2:h(l,14,1.57,.1),body1:h(a,16,1.5,.15),body2:h(a,14,1.43,.15),button:h(l,14,1.75,.4,Vy),caption:h(a,12,1.66,.4),overline:h(a,12,2.66,1,Vy),inherit:{fontFamily:"inherit",fontWeight:"inherit",fontSize:"inherit",lineHeight:"inherit",letterSpacing:"inherit"}};return Sh(kd({htmlFontSize:c,pxToRem:m,fontFamily:r,fontSize:o,fontWeightLight:i,fontWeightRegular:a,fontWeightMedium:l,fontWeightBold:s},g),f,{clone:!1})}function Yy(...e){return[`${e[0]}px ${e[1]}px ${e[2]}px ${e[3]}px rgba(0,0,0,0.2)`,`${e[4]}px ${e[5]}px ${e[6]}px ${e[7]}px rgba(0,0,0,0.14)`,`${e[8]}px ${e[9]}px ${e[10]}px ${e[11]}px rgba(0,0,0,0.12)`].join(",")}const Jy=["none",Yy(0,2,1,-1,0,1,1,0,0,1,3,0),Yy(0,3,1,-2,0,2,2,0,0,1,5,0),Yy(0,3,3,-2,0,3,4,0,0,1,8,0),Yy(0,2,4,-1,0,4,5,0,0,1,10,0),Yy(0,3,5,-1,0,5,8,0,0,1,14,0),Yy(0,3,5,-1,0,6,10,0,0,1,18,0),Yy(0,4,5,-2,0,7,10,1,0,2,16,1),Yy(0,5,5,-3,0,8,10,1,0,3,14,2),Yy(0,5,6,-3,0,9,12,1,0,3,16,2),Yy(0,6,6,-3,0,10,14,1,0,4,18,3),Yy(0,6,7,-4,0,11,15,1,0,4,20,3),Yy(0,7,8,-4,0,12,17,2,0,5,22,4),Yy(0,7,8,-4,0,13,19,2,0,5,24,4),Yy(0,7,9,-4,0,14,21,2,0,5,26,4),Yy(0,8,9,-5,0,15,22,2,0,6,28,5),Yy(0,8,10,-5,0,16,24,2,0,6,30,5),Yy(0,8,11,-5,0,17,26,2,0,6,32,5),Yy(0,9,11,-5,0,18,28,2,0,7,34,6),Yy(0,9,12,-6,0,19,29,2,0,7,36,6),Yy(0,10,13,-6,0,20,31,3,0,8,38,7),Yy(0,10,13,-6,0,21,33,3,0,8,40,7),Yy(0,10,14,-6,0,22,35,3,0,8,42,7),Yy(0,11,14,-7,0,23,36,3,0,9,44,8),Yy(0,11,15,-7,0,24,38,3,0,9,46,8)],Gy=["duration","easing","delay"],Qy={easeInOut:"cubic-bezier(0.4, 0, 0.2, 1)",easeOut:"cubic-bezier(0.0, 0, 0.2, 1)",easeIn:"cubic-bezier(0.4, 0, 1, 1)",sharp:"cubic-bezier(0.4, 0, 0.6, 1)"},Ky={shortest:150,shorter:200,short:250,standard:300,complex:375,enteringScreen:225,leavingScreen:195};function Xy(e){return`${Math.round(e)}ms`}function Zy(e){if(!e)return 0;const t=e/36;return Math.round(10*(4+15*t**.25+t/5))}function eb(e){const t=kd({},Qy,e.easing),n=kd({},Ky,e.duration);return kd({getAutoHeightDuration:Zy,create:(e=["all"],r={})=>{const{duration:o=n.standard,easing:i=t.easeInOut,delay:a=0}=r;return xf(r,Gy),(Array.isArray(e)?e:[e]).map((e=>`${e} ${"string"==typeof o?o:Xy(o)} ${i} ${"string"==typeof a?a:Xy(a)}`)).join(",")}},e,{easing:t,duration:n})}const tb={mobileStepper:1e3,fab:1050,speedDial:1050,appBar:1100,drawer:1200,modal:1300,snackbar:1400,tooltip:1500},nb=["breakpoints","mixins","spacing","palette","transitions","typography","shape"];const rb=function(e={},...t){const{mixins:n={},palette:r={},transitions:o={},typography:i={}}=e,a=xf(e,nb);if(e.vars)throw new Error(jh(18));const l=Uy(r),s=cy(e);let c=Sh(s,{mixins:(u=s.breakpoints,d=n,kd({toolbar:{minHeight:56,[u.up("xs")]:{"@media (orientation: landscape)":{minHeight:48}},[u.up("sm")]:{minHeight:64}}},d)),palette:l,shadows:Jy.slice(),typography:qy(l,i),transitions:eb(o),zIndex:kd({},tb)});var u,d;return c=Sh(c,a),c=t.reduce(((e,t)=>Sh(e,t)),c),c.unstable_sxConfig=kd({},ay,null==a?void 0:a.unstable_sxConfig),c.unstable_sx=function(e){return ly({sx:e,theme:this})},c}(),ob="$$material";const ib=function(e={}){const{themeId:t,defaultTheme:n=by,rootShouldForwardProp:r=yy,slotShouldForwardProp:o=yy}=e,i=e=>ly(kd({},e,{theme:xy(kd({},e,{defaultTheme:n,themeId:t}))}));return i.__mui_systemSx=!0,(e,a={})=>{((e,t)=>{Array.isArray(e.__emotion_styles)&&(e.__emotion_styles=t(e.__emotion_styles))})(e,(e=>e.filter((e=>!(null!=e&&e.__mui_systemSx)))));const{name:l,slot:s,skipVariantsResolver:c,skipSx:u,overridesResolver:d=ky(wy(s))}=a,f=xf(a,hy),p=void 0!==c?c:s&&"Root"!==s&&"root"!==s||!1,m=u||!1;let h=yy;"Root"===s||"root"===s?h=r:s?h=o:function(e){return"string"==typeof e&&e.charCodeAt(0)>96}(e)&&(h=void 0);const g=function(e,t){return fv(e,t)}(e,kd({shouldForwardProp:h,label:undefined},f)),v=(r,...o)=>{const a=o?o.map((e=>{if("function"==typeof e&&e.__emotion_real!==e)return r=>Sy({styledArg:e,props:r,defaultTheme:n,themeId:t});if(xh(e)){let t,n=e;return e&&e.variants&&(t=e.variants,delete n.variants,n=n=>{let r=e;return vy(n,gy(t),t).forEach((e=>{r=Sh(r,e)})),r}),n}return e})):[];let s=r;if(xh(r)){let e;r&&r.variants&&(e=r.variants,delete s.variants,s=t=>{let n=r;return vy(t,gy(e),e).forEach((e=>{n=Sh(n,e)})),n})}else"function"==typeof r&&r.__emotion_real!==r&&(s=e=>Sy({styledArg:r,props:e,defaultTheme:n,themeId:t}));l&&d&&a.push((e=>{const r=xy(kd({},e,{defaultTheme:n,themeId:t})),o=((e,t)=>t.components&&t.components[e]&&t.components[e].styleOverrides?t.components[e].styleOverrides:null)(l,r);if(o){const t={};return Object.entries(o).forEach((([n,o])=>{t[n]="function"==typeof o?o(kd({},e,{theme:r})):o})),d(e,t)}return null})),l&&!p&&a.push((e=>{const r=xy(kd({},e,{defaultTheme:n,themeId:t}));return((e,t,n,r)=>{var o;const i=null==n||null==(o=n.components)||null==(o=o[r])?void 0:o.variants;return vy(e,t,i)})(e,((e,t)=>{let n=[];return t&&t.components&&t.components[e]&&t.components[e].variants&&(n=t.components[e].variants),gy(n)})(l,r),r,l)})),m||a.push(i);const c=a.length-o.length;if(Array.isArray(r)&&c>0){const e=new Array(c).fill("");s=[...r,...e],s.raw=[...r.raw,...e]}const u=g(s,...a);return e.muiName&&(u.muiName=e.muiName),u};return g.withConfig&&(v.withConfig=g.withConfig),v}}({themeId:ob,defaultTheme:rb,rootShouldForwardProp:e=>yy(e)&&"classes"!==e});function ab(e){return Wh("MuiSvgIcon",e)}!function(e,t,n="Mui"){const r={};t.forEach((t=>{r[t]=Wh(e,t,n)}))}("MuiSvgIcon",["root","colorPrimary","colorSecondary","colorAction","colorError","colorDisabled","fontSizeInherit","fontSizeSmall","fontSizeMedium","fontSizeLarge"]);const lb=["children","className","color","component","fontSize","htmlColor","inheritViewBox","titleAccess","viewBox"],sb=e=>{const{color:t,fontSize:n,classes:r}=e;return function(e,t,n){const r={};return Object.keys(e).forEach((o=>{r[o]=e[o].reduce(((e,r)=>{if(r){const o=t(r);""!==o&&e.push(o),n&&n[r]&&e.push(n[r])}return e}),[]).join(" ")})),r}({root:["root","inherit"!==t&&`color${Eh(t)}`,`fontSize${Eh(n)}`]},ab,r)},cb=ib("svg",{name:"MuiSvgIcon",slot:"Root",overridesResolver:(e,t)=>{const{ownerState:n}=e;return[t.root,"inherit"!==n.color&&t[`color${Eh(n.color)}`],t[`fontSize${Eh(n.fontSize)}`]]}})((({theme:e,ownerState:t})=>{var n,r,o,i,a,l,s,c,u,d,f,p,m;return{userSelect:"none",width:"1em",height:"1em",display:"inline-block",fill:t.hasSvgAsChild?void 0:"currentColor",flexShrink:0,transition:null==(n=e.transitions)||null==(r=n.create)?void 0:r.call(n,"fill",{duration:null==(o=e.transitions)||null==(o=o.duration)?void 0:o.shorter}),fontSize:{inherit:"inherit",small:(null==(i=e.typography)||null==(a=i.pxToRem)?void 0:a.call(i,20))||"1.25rem",medium:(null==(l=e.typography)||null==(s=l.pxToRem)?void 0:s.call(l,24))||"1.5rem",large:(null==(c=e.typography)||null==(u=c.pxToRem)?void 0:u.call(c,35))||"2.1875rem"}[t.fontSize],color:null!=(d=null==(f=(e.vars||e).palette)||null==(f=f[t.color])?void 0:f.main)?d:{action:null==(p=(e.vars||e).palette)||null==(p=p.action)?void 0:p.active,disabled:null==(m=(e.vars||e).palette)||null==(m=m.action)?void 0:m.disabled,inherit:void 0}[t.color]}})),ub=W.forwardRef((function(e,t){const n=function({props:e,name:t}){return Ey({props:e,name:t,defaultTheme:rb,themeId:ob})}({props:e,name:"MuiSvgIcon"}),{children:r,className:o,color:i="inherit",component:a="svg",fontSize:l="medium",htmlColor:s,inheritViewBox:c=!1,titleAccess:u,viewBox:d="0 0 24 24"}=n,f=xf(n,lb),p=W.isValidElement(r)&&"svg"===r.type,m=kd({},n,{color:i,component:a,fontSize:l,instanceFontSize:e.fontSize,inheritViewBox:c,viewBox:d,hasSvgAsChild:p}),h={};c||(h.viewBox=d);const g=sb(m);return Z.jsxs(cb,kd({as:a,className:Hh(g.root,o),focusable:"false",color:s,"aria-hidden":!u||void 0,role:u?"img":void 0,ref:t},h,f,p&&r.props,{ownerState:m,children:[p?r.props.children:r,u?Z.jsx("title",{children:u}):null]}))}));ub.muiName="SvgIcon";const db={configure:e=>{Fh.configure(e)}},fb=Object.freeze(Object.defineProperty({__proto__:null,capitalize:Eh,createChainedFunction:function(...e){return e.reduce(((e,t)=>null==t?e:function(...n){e.apply(this,n),t.apply(this,n)}),(()=>{}))},createSvgIcon:function(e,t){function n(n,r){return Z.jsx(ub,kd({"data-testid":`${t}Icon`,ref:r},n,{children:e}))}return n.muiName=ub.muiName,W.memo(W.forwardRef(n))},debounce:function(e,t=166){let n;function r(...r){clearTimeout(n),n=setTimeout((()=>{e.apply(this,r)}),t)}return r.clear=()=>{clearTimeout(n)},r},deprecatedPropType:function(e,t){return()=>null},isMuiElement:function(e,t){var n,r;return W.isValidElement(e)&&-1!==t.indexOf(null!=(n=e.type.muiName)?n:null==(r=e.type)||null==(r=r._payload)||null==(r=r.value)?void 0:r.muiName)},ownerDocument:Ch,ownerWindow:function(e){return Ch(e).defaultView||window},requirePropFactory:function(e,t){return()=>null},setRef:Ah,unstable_ClassNameGenerator:db,unstable_useEnhancedEffect:Oh,unstable_useId:function(e){if(void 0!==_h){const t=_h();return null!=e?e:t}return function(e){const[t,n]=W.useState(e),r=e||t;return W.useEffect((()=>{null==t&&(Nh+=1,n(`mui-${Nh}`))}),[t]),r}(e)},unsupportedProp:function(e,t,n,r,o){return null},useControlled:function({controlled:e,default:t,name:n,state:r="value"}){const{current:o}=W.useRef(void 0!==e),[i,a]=W.useState(t);return[o?e:i,W.useCallback((e=>{o||a(e)}),[])]},useEventCallback:function(e){const t=W.useRef(e);return Oh((()=>{t.current=e})),W.useRef(((...e)=>(0,t.current)(...e))).current},useForkRef:function(...e){return W.useMemo((()=>e.every((e=>null==e))?null:t=>{e.forEach((e=>{Ah(e,t)}))}),e)},useIsFocusVisible:function(){const e=W.useCallback((e=>{var t;null!=e&&((t=e.ownerDocument).addEventListener("keydown",Mh,!0),t.addEventListener("mousedown",Rh,!0),t.addEventListener("pointerdown",Rh,!0),t.addEventListener("touchstart",Rh,!0),t.addEventListener("visibilitychange",zh,!0))}),[]),t=W.useRef(!1);return{isFocusVisibleRef:t,onFocus:function(e){return!!$h(e)&&(t.current=!0,!0)},onBlur:function(){return!!t.current&&(Th=!0,window.clearTimeout(Ph),Ph=window.setTimeout((()=>{Th=!1}),100),t.current=!1,!0)},ref:e}}},Symbol.toStringTag,{value:"Module"})),pb=r(fb);var mb;function hb(){return mb||(mb=1,function(e){Object.defineProperty(e,"__esModule",{value:!0}),Object.defineProperty(e,"default",{enumerable:!0,get:function(){return t.createSvgIcon}});var t=pb}(wh)),wh}var gb=bh;Object.defineProperty(vh,"__esModule",{value:!0});var vb=vh.default=void 0,yb=gb(hb()),bb=Z,wb=(0,yb.default)((0,bb.jsx)("path",{d:"M9.29 6.71c-.39.39-.39 1.02 0 1.41L13.17 12l-3.88 3.88c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l4.59-4.59c.39-.39.39-1.02 0-1.41L10.7 6.7c-.38-.38-1.02-.38-1.41.01z"}),"ChevronRightRounded");vb=vh.default=wb;const xb=fh`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`,kb=fh`
  from {
    opacity: 0;
    transform: scale(.8);
  }

  to {
    opacity: 1;
    transform: scale(1);
  }
`,Sb=fh`
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
`,jb=fh`
  from {
    opacity: 1;
    transform: scale(1);
  }

  to {
    opacity: 0;
    transform: scale(.95);
  }
`,Eb=fh`
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
`,Cb=dh.header`
  width: 100vw;
  height: max(3rem, 3.5vw);
  z-index: 4;
  position: fixed;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2.5vw;
  box-sizing: border-box;
  bottom: 0;

  @media (min-width: 600px) {
    background: linear-gradient(180deg, #141414, transparent), rgba(14, 14, 14, ${e=>e.opacity});
    transition: background ease 200ms;
    top: 0;
  }
`,Ab=dh(Cp)`
  height: max(2rem, 2vw);
  justify-content: center;
  display: flex;

  @media (max-width: 600px) {
    display: none;
  }

  img {
    max-height: 100%;
  }
`,Ob=dh.main`
  display: flex;
  align-items: center;

  @media (max-width: 600px) {
    display: none;
  }
`,Nb=dh.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;

  @media (max-width: 600px) {
    display: none;
  }
`;dh.button`
  color: #fff;
  cursor: pointer;
  margin-right: 2vw;
  background: none;

  @media (min-width: 600px) {
    display: none;
  }
`,dh.div`
  width: 10em;
  height: fit-content;
  position: absolute;
  left: 0;
  border-top: 5px solid #e50404;
  background: #000;
  transform: translateX(${e=>e.hide?"-100%":"0"});
  transition: transform ease 300ms;

  section {
    display: flex;
    flex-direction: column;
    font-size: 1.3em;
    padding: 1rem 1rem;
  }

  section + section {
    border-top: 1px solid #333;
  }

  a + a {
    margin-top: 1rem;
  }

  @media (min-width: 600px) {
    display: none;
  }
`,dh.div`
  color: #fff;
  margin-left: 2vw;
  font-size: 75%;

  a {
    text-decoration: none;
    transition: opacity ease 200ms;

    &:hover {
      opacity: 0.6;
    }
  }

  a + a {
    margin-left: max(1vw, .5rem);
  }

  @media (max-width: 600px) {
    display: none;
  }
`,dh.div`
  width: max(10rem, 7.5vw);
  margin-left: .5vw;
  display: flex;
  align-items: center;
  justify-content: space-between;

  @media (max-width: 600px) {
    display: none;
  }
`;const _b=fh`
10%, 90% {
  transform: translate3d(-1px, 0, 0);
}

20%, 80% {
  transform: translate3d(2px, 0, 0);
}

30%, 50%, 70% {
  transform: translate3d(-4px, 0, 0);
}

40%, 60% {
  transform: translate3d(4px, 0, 0);
}
`,Pb=dh(vb)`
  animation-name: ${_b};
  animation-duration: 2s;
  animation-iteration-count: 2;
  @media (max-width: 600px) {
    opacity 0;
  }
`,Ib=dh.div`
  height: 100%;
  width: 0;
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  z-index: 11;
  flex-direction:column;
  background-image: linear-gradient(to right, rgba(255,255,255,.1), rgba(0,0,6, 0) 80%);
  background-color: #101010; /* Black*/
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 15px; /* Place content 60px from the top */
  transition: 0.5s; /* 0.5 second transition effect to slide in the sidenav */

  @media (max-width: 600px) {
    display: none;
  }

  a {
    &:hover {
      text-decoration: none;
      color: #f1f1f1;
      font-size: 1.6em;
    }
  }

  p {
    &:hover {
      text-decoration: none;
      color: #f1f1f1;
      font-size: .95em;
    }
  }
`,Tb=dh(Cp)`
  padding: 0px 0px 0px 32px;
  height: 46px;
  text-decoration: none;
  white-space: nowrap;
  font-size: 1.5em;
  cursor: pointer;
  font-family: Helvetica;
  color: #818181;
  display: block;
  transition: 0.3s;

  @media (max-width: 600px) {
    font-size: 2.1em;
    padding: 0 0 0 0;
    margin-top: 1rem;
  }
`,Lb=dh.main`
  @media (max-height: 600px) {
    display: none;
  }
`,Mb=dh.p`
  padding: 0px 0px 0px 32px;
  height: 26px;
  text-decoration: none;
  font-size: .9em;
  font-family: Helvetica;
  white-space: nowrap;
  cursor:pointer;
  color: #818181;
  display: block;
  transition: 0.3s
`;dh.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  height: 4rem;
  margin: 0 auto;
	padding: 0 1.25rem;
`;const Rb=dh.div`
  position: fixed;
  left: 0;
  bottom: -1px;
  display: grid;
  align-content: center;
  width: 100%;
  height: 6.5rem;
  padding: 0 1rem;
  background: #000;
  box-shadow: 0 -4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  
  @media (min-width: 600px) {
    display: none;
  }
`,zb=dh.ul`
  display: flex;
  align-items: center;
  justify-content: space-around;

  @media (max-height: 576px) {
    justify-content: center;
		column-gap: 3rem;
  }
`,$b=dh(Cp)`
  display: flex;
  text-decoration: none !important;
  -webkit-tap-highlight-color: transparent;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: none;
  outline: none;
  color: #555555;

  &.active {
		color: #db202c;
  }
`,Db=dh.li`
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  list-style: none;
  list-style-type: none;
`,Bb=dh.span`
  display: block;
  font-family: inherit;
  font-size: 1.5rem;
  font-weight: 500;
  line-height: 1.25;
  visibility: visible;
  text-transform: capitalize;

  @media (max-height: 800px) {
    display: block;
		visibility: visible;
  }
`,Fb=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .9);
  overflow-y: auto;
  animation: ${Sb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}
`,Ub=fh`
  from {
    width: clamp(2rem, 2vw, 4rem);
  }

  to {
    width: clamp(12rem, 15vw, 25rem);
  }
`,Wb=fh`
  from {
    width: clamp(12rem, 15vw, 25rem);
  }

  to {
    width: clamp(2rem, 2vw, 4rem);
  }
`,Vb=dh.div`
  width: clamp(2rem, 2vw, 4rem);
  height: clamp(2rem, 2vw, 5rem);
  position: relative;

  ${e=>e.show&&Xm`
    animation: ${Ub} 300ms forwards;
  `}

  ${e=>!e.show&&0!==e.show&&Xm`
    animation-direction: reverse;
    animation: ${Wb} 300ms forwards;
  `}

  @media (max-width: 600px) {
    display: none;
  }
`,Hb=dh.button`
  width: clamp(1rem, 2vw, 4rem);
  height: 100%;
  position: absolute;
  z-index: 1;
  background: none;
  color: #fff;
  cursor: pointer;
  transform: scale(.9);

  :disabled {
    cursor: initial;
  }
`,qb=dh.input`
  width: 99%;
  height: 100%;
  font-size: 85%;
  padding: 0 clamp(1.5rem, 2vw, 4rem);
  padding-right: 0;
  box-sizing: border-box;
  background: #000;
  color: #fff;
  border: 1.2px solid #e5e5e5;
  box-shadow: inset 0 0 2px #333;
  opacity: ${e=>e.show?1:0};
  transition: opacity 300ms;
  outline: none;

  &:-webkit-autofill,
  &:-webkit-autofill:focus {
      transition: background-color 600000s 0s, color 600000s 0s;
  }
  &[data-autocompleted] {
      background-color: transparent !important;
  }
`;var Yb={},Jb=bh;Object.defineProperty(Yb,"__esModule",{value:!0});var Gb=Yb.default=void 0,Qb=Jb(hb()),Kb=Z,Xb=(0,Qb.default)((0,Kb.jsx)("path",{d:"M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"}),"Search");Gb=Yb.default=Xb;var Zb={},ew={exports:{}};!function(e,n){!function(t,r){var o="function",i="undefined",a="object",l="string",s="major",c="model",u="name",d="type",f="vendor",p="version",m="architecture",h="console",g="mobile",v="tablet",y="smarttv",b="wearable",w="embedded",x="Amazon",k="Apple",S="ASUS",j="BlackBerry",E="Browser",C="Chrome",A="Firefox",O="Google",N="Huawei",_="LG",P="Microsoft",I="Motorola",T="Opera",L="Samsung",M="Sharp",R="Sony",z="Xiaomi",$="Zebra",D="Facebook",B="Chromium OS",F="Mac OS",U=function(e){for(var t={},n=0;n<e.length;n++)t[e[n].toUpperCase()]=e[n];return t},W=function(e,t){return typeof e===l&&-1!==V(t).indexOf(V(e))},V=function(e){return e.toLowerCase()},H=function(e,t){if(typeof e===l)return e=e.replace(/^\s\s*/,""),typeof t===i?e:e.substring(0,350)},q=function(e,t){for(var n,i,l,s,c,u,d=0;d<t.length&&!c;){var f=t[d],p=t[d+1];for(n=i=0;n<f.length&&!c&&f[n];)if(c=f[n++].exec(e))for(l=0;l<p.length;l++)u=c[++i],typeof(s=p[l])===a&&s.length>0?2===s.length?typeof s[1]==o?this[s[0]]=s[1].call(this,u):this[s[0]]=s[1]:3===s.length?typeof s[1]!==o||s[1].exec&&s[1].test?this[s[0]]=u?u.replace(s[1],s[2]):r:this[s[0]]=u?s[1].call(this,u,s[2]):r:4===s.length&&(this[s[0]]=u?s[3].call(this,u.replace(s[1],s[2])):r):this[s]=u||r;d+=2}},Y=function(e,t){for(var n in t)if(typeof t[n]===a&&t[n].length>0){for(var o=0;o<t[n].length;o++)if(W(t[n][o],e))return"?"===n?r:n}else if(W(t[n],e))return"?"===n?r:n;return e},J={ME:"4.90","NT 3.11":"NT3.51","NT 4.0":"NT4.0",2e3:"NT 5.0",XP:["NT 5.1","NT 5.2"],Vista:"NT 6.0",7:"NT 6.1",8:"NT 6.2",8.1:"NT 6.3",10:["NT 6.4","NT 10.0"],RT:"ARM"},G={browser:[[/\b(?:crmo|crios)\/([\w\.]+)/i],[p,[u,"Chrome"]],[/edg(?:e|ios|a)?\/([\w\.]+)/i],[p,[u,"Edge"]],[/(opera mini)\/([-\w\.]+)/i,/(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,/(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],[u,p],[/opios[\/ ]+([\w\.]+)/i],[p,[u,T+" Mini"]],[/\bopr\/([\w\.]+)/i],[p,[u,T]],[/(kindle)\/([\w\.]+)/i,/(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,/(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i,/(ba?idubrowser)[\/ ]?([\w\.]+)/i,/(?:ms|\()(ie) ([\w\.]+)/i,/(flock|rockmelt|midori|epiphany|silk|skyfire|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i,/(heytap|ovi)browser\/([\d\.]+)/i,/(weibo)__([\d\.]+)/i],[u,p],[/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],[p,[u,"UC"+E]],[/microm.+\bqbcore\/([\w\.]+)/i,/\bqbcore\/([\w\.]+).+microm/i],[p,[u,"WeChat(Win) Desktop"]],[/micromessenger\/([\w\.]+)/i],[p,[u,"WeChat"]],[/konqueror\/([\w\.]+)/i],[p,[u,"Konqueror"]],[/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],[p,[u,"IE"]],[/ya(?:search)?browser\/([\w\.]+)/i],[p,[u,"Yandex"]],[/(avast|avg)\/([\w\.]+)/i],[[u,/(.+)/,"$1 Secure "+E],p],[/\bfocus\/([\w\.]+)/i],[p,[u,A+" Focus"]],[/\bopt\/([\w\.]+)/i],[p,[u,T+" Touch"]],[/coc_coc\w+\/([\w\.]+)/i],[p,[u,"Coc Coc"]],[/dolfin\/([\w\.]+)/i],[p,[u,"Dolphin"]],[/coast\/([\w\.]+)/i],[p,[u,T+" Coast"]],[/miuibrowser\/([\w\.]+)/i],[p,[u,"MIUI "+E]],[/fxios\/([-\w\.]+)/i],[p,[u,A]],[/\bqihu|(qi?ho?o?|360)browser/i],[[u,"360 "+E]],[/(oculus|samsung|sailfish|huawei)browser\/([\w\.]+)/i],[[u,/(.+)/,"$1 "+E],p],[/(comodo_dragon)\/([\w\.]+)/i],[[u,/_/g," "],p],[/(electron)\/([\w\.]+) safari/i,/(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,/m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i],[u,p],[/(metasr)[\/ ]?([\w\.]+)/i,/(lbbrowser)/i,/\[(linkedin)app\]/i],[u],[/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],[[u,D],p],[/(kakao(?:talk|story))[\/ ]([\w\.]+)/i,/(naver)\(.*?(\d+\.[\w\.]+).*\)/i,/safari (line)\/([\w\.]+)/i,/\b(line)\/([\w\.]+)\/iab/i,/(chromium|instagram)[\/ ]([-\w\.]+)/i],[u,p],[/\bgsa\/([\w\.]+) .*safari\//i],[p,[u,"GSA"]],[/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],[p,[u,"TikTok"]],[/headlesschrome(?:\/([\w\.]+)| )/i],[p,[u,C+" Headless"]],[/ wv\).+(chrome)\/([\w\.]+)/i],[[u,C+" WebView"],p],[/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],[p,[u,"Android "+E]],[/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],[u,p],[/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],[p,[u,"Mobile Safari"]],[/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],[p,u],[/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],[u,[p,Y,{"1.0":"/8",1.2:"/1",1.3:"/3","2.0":"/412","2.0.2":"/416","2.0.3":"/417","2.0.4":"/419","?":"/"}]],[/(webkit|khtml)\/([\w\.]+)/i],[u,p],[/(navigator|netscape\d?)\/([-\w\.]+)/i],[[u,"Netscape"],p],[/mobile vr; rv:([\w\.]+)\).+firefox/i],[p,[u,A+" Reality"]],[/ekiohf.+(flow)\/([\w\.]+)/i,/(swiftfox)/i,/(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,/(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,/(firefox)\/([\w\.]+)/i,/(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,/(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,/(links) \(([\w\.]+)/i,/panasonic;(viera)/i],[u,p],[/(cobalt)\/([\w\.]+)/i],[u,[p,/master.|lts./,""]]],cpu:[[/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],[[m,"amd64"]],[/(ia32(?=;))/i],[[m,V]],[/((?:i[346]|x)86)[;\)]/i],[[m,"ia32"]],[/\b(aarch64|arm(v?8e?l?|_?64))\b/i],[[m,"arm64"]],[/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],[[m,"armhf"]],[/windows (ce|mobile); ppc;/i],[[m,"arm"]],[/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],[[m,/ower/,"",V]],[/(sun4\w)[;\)]/i],[[m,"sparc"]],[/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],[[m,V]]],device:[[/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],[c,[f,L],[d,v]],[/\b((?:s[cgp]h|gt|sm)-\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,/samsung[- ]([-\w]+)/i,/sec-(sgh\w+)/i],[c,[f,L],[d,g]],[/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],[c,[f,k],[d,g]],[/\((ipad);[-\w\),; ]+apple/i,/applecoremedia\/[\w\.]+ \((ipad)/i,/\b(ipad)\d\d?,\d\d?[;\]].+ios/i],[c,[f,k],[d,v]],[/(macintosh);/i],[c,[f,k]],[/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],[c,[f,M],[d,g]],[/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i],[c,[f,N],[d,v]],[/(?:huawei|honor)([-\w ]+)[;\)]/i,/\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],[c,[f,N],[d,g]],[/\b(poco[\w ]+)(?: bui|\))/i,/\b; (\w+) build\/hm\1/i,/\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,/\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,/\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i],[[c,/_/g," "],[f,z],[d,g]],[/\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i],[[c,/_/g," "],[f,z],[d,v]],[/; (\w+) bui.+ oppo/i,/\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],[c,[f,"OPPO"],[d,g]],[/vivo (\w+)(?: bui|\))/i,/\b(v[12]\d{3}\w?[at])(?: bui|;)/i],[c,[f,"Vivo"],[d,g]],[/\b(rmx[12]\d{3})(?: bui|;|\))/i],[c,[f,"Realme"],[d,g]],[/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,/\bmot(?:orola)?[- ](\w*)/i,/((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],[c,[f,I],[d,g]],[/\b(mz60\d|xoom[2 ]{0,2}) build\//i],[c,[f,I],[d,v]],[/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],[c,[f,_],[d,v]],[/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,/\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,/\blg-?([\d\w]+) bui/i],[c,[f,_],[d,g]],[/(ideatab[-\w ]+)/i,/lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i],[c,[f,"Lenovo"],[d,v]],[/(?:maemo|nokia).*(n900|lumia \d+)/i,/nokia[-_ ]?([-\w\.]*)/i],[[c,/_/g," "],[f,"Nokia"],[d,g]],[/(pixel c)\b/i],[c,[f,O],[d,v]],[/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],[c,[f,O],[d,g]],[/droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],[c,[f,R],[d,g]],[/sony tablet [ps]/i,/\b(?:sony)?sgp\w+(?: bui|\))/i],[[c,"Xperia Tablet"],[f,R],[d,v]],[/ (kb2005|in20[12]5|be20[12][59])\b/i,/(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],[c,[f,"OnePlus"],[d,g]],[/(alexa)webm/i,/(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i,/(kf[a-z]+)( bui|\)).+silk\//i],[c,[f,x],[d,v]],[/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],[[c,/(.+)/g,"Fire Phone $1"],[f,x],[d,g]],[/(playbook);[-\w\),; ]+(rim)/i],[c,f,[d,v]],[/\b((?:bb[a-f]|st[hv])100-\d)/i,/\(bb10; (\w+)/i],[c,[f,j],[d,g]],[/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],[c,[f,S],[d,v]],[/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],[c,[f,S],[d,g]],[/(nexus 9)/i],[c,[f,"HTC"],[d,v]],[/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,/(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,/(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],[f,[c,/_/g," "],[d,g]],[/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],[c,[f,"Acer"],[d,v]],[/droid.+; (m[1-5] note) bui/i,/\bmz-([-\w]{2,})/i],[c,[f,"Meizu"],[d,g]],[/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i,/(hp) ([\w ]+\w)/i,/(asus)-?(\w+)/i,/(microsoft); (lumia[\w ]+)/i,/(lenovo)[-_ ]?([-\w]+)/i,/(jolla)/i,/(oppo) ?([\w ]+) bui/i],[f,c,[d,g]],[/(kobo)\s(ereader|touch)/i,/(archos) (gamepad2?)/i,/(hp).+(touchpad(?!.+tablet)|tablet)/i,/(kindle)\/([\w\.]+)/i,/(nook)[\w ]+build\/(\w+)/i,/(dell) (strea[kpr\d ]*[\dko])/i,/(le[- ]+pan)[- ]+(\w{1,9}) bui/i,/(trinity)[- ]*(t\d{3}) bui/i,/(gigaset)[- ]+(q\w{1,9}) bui/i,/(vodafone) ([\w ]+)(?:\)| bui)/i],[f,c,[d,v]],[/(surface duo)/i],[c,[f,P],[d,v]],[/droid [\d\.]+; (fp\du?)(?: b|\))/i],[c,[f,"Fairphone"],[d,g]],[/(u304aa)/i],[c,[f,"AT&T"],[d,g]],[/\bsie-(\w*)/i],[c,[f,"Siemens"],[d,g]],[/\b(rct\w+) b/i],[c,[f,"RCA"],[d,v]],[/\b(venue[\d ]{2,7}) b/i],[c,[f,"Dell"],[d,v]],[/\b(q(?:mv|ta)\w+) b/i],[c,[f,"Verizon"],[d,v]],[/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],[c,[f,"Barnes & Noble"],[d,v]],[/\b(tm\d{3}\w+) b/i],[c,[f,"NuVision"],[d,v]],[/\b(k88) b/i],[c,[f,"ZTE"],[d,v]],[/\b(nx\d{3}j) b/i],[c,[f,"ZTE"],[d,g]],[/\b(gen\d{3}) b.+49h/i],[c,[f,"Swiss"],[d,g]],[/\b(zur\d{3}) b/i],[c,[f,"Swiss"],[d,v]],[/\b((zeki)?tb.*\b) b/i],[c,[f,"Zeki"],[d,v]],[/\b([yr]\d{2}) b/i,/\b(dragon[- ]+touch |dt)(\w{5}) b/i],[[f,"Dragon Touch"],c,[d,v]],[/\b(ns-?\w{0,9}) b/i],[c,[f,"Insignia"],[d,v]],[/\b((nxa|next)-?\w{0,9}) b/i],[c,[f,"NextBook"],[d,v]],[/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],[[f,"Voice"],c,[d,g]],[/\b(lvtel\-)?(v1[12]) b/i],[[f,"LvTel"],c,[d,g]],[/\b(ph-1) /i],[c,[f,"Essential"],[d,g]],[/\b(v(100md|700na|7011|917g).*\b) b/i],[c,[f,"Envizen"],[d,v]],[/\b(trio[-\w\. ]+) b/i],[c,[f,"MachSpeed"],[d,v]],[/\btu_(1491) b/i],[c,[f,"Rotor"],[d,v]],[/(shield[\w ]+) b/i],[c,[f,"Nvidia"],[d,v]],[/(sprint) (\w+)/i],[f,c,[d,g]],[/(kin\.[onetw]{3})/i],[[c,/\./g," "],[f,P],[d,g]],[/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],[c,[f,$],[d,v]],[/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],[c,[f,$],[d,g]],[/smart-tv.+(samsung)/i],[f,[d,y]],[/hbbtv.+maple;(\d+)/i],[[c,/^/,"SmartTV"],[f,L],[d,y]],[/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],[[f,_],[d,y]],[/(apple) ?tv/i],[f,[c,k+" TV"],[d,y]],[/crkey/i],[[c,C+"cast"],[f,O],[d,y]],[/droid.+aft(\w)( bui|\))/i],[c,[f,x],[d,y]],[/\(dtv[\);].+(aquos)/i,/(aquos-tv[\w ]+)\)/i],[c,[f,M],[d,y]],[/(bravia[\w ]+)( bui|\))/i],[c,[f,R],[d,y]],[/(mitv-\w{5}) bui/i],[c,[f,z],[d,y]],[/Hbbtv.*(technisat) (.*);/i],[f,c,[d,y]],[/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,/hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],[[f,H],[c,H],[d,y]],[/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],[[d,y]],[/(ouya)/i,/(nintendo) ([wids3utch]+)/i],[f,c,[d,h]],[/droid.+; (shield) bui/i],[c,[f,"Nvidia"],[d,h]],[/(playstation [345portablevi]+)/i],[c,[f,R],[d,h]],[/\b(xbox(?: one)?(?!; xbox))[\); ]/i],[c,[f,P],[d,h]],[/((pebble))app/i],[f,c,[d,b]],[/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],[c,[f,k],[d,b]],[/droid.+; (glass) \d/i],[c,[f,O],[d,b]],[/droid.+; (wt63?0{2,3})\)/i],[c,[f,$],[d,b]],[/(quest( 2| pro)?)/i],[c,[f,D],[d,b]],[/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],[f,[d,w]],[/(aeobc)\b/i],[c,[f,x],[d,w]],[/droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i],[c,[d,g]],[/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],[c,[d,v]],[/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],[[d,v]],[/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],[[d,g]],[/(android[-\w\. ]{0,9});.+buil/i],[c,[f,"Generic"]]],engine:[[/windows.+ edge\/([\w\.]+)/i],[p,[u,"EdgeHTML"]],[/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],[p,[u,"Blink"]],[/(presto)\/([\w\.]+)/i,/(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,/ekioh(flow)\/([\w\.]+)/i,/(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,/(icab)[\/ ]([23]\.[\d\.]+)/i,/\b(libweb)/i],[u,p],[/rv\:([\w\.]{1,9})\b.+(gecko)/i],[p,u]],os:[[/microsoft (windows) (vista|xp)/i],[u,p],[/(windows) nt 6\.2; (arm)/i,/(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,/(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i],[u,[p,Y,J]],[/(win(?=3|9|n)|win 9x )([nt\d\.]+)/i],[[u,"Windows"],[p,Y,J]],[/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,/ios;fbsv\/([\d\.]+)/i,/cfnetwork\/.+darwin/i],[[p,/_/g,"."],[u,"iOS"]],[/(mac os x) ?([\w\. ]*)/i,/(macintosh|mac_powerpc\b)(?!.+haiku)/i],[[u,F],[p,/_/g,"."]],[/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],[p,u],[/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,/(blackberry)\w*\/([\w\.]*)/i,/(tizen|kaios)[\/ ]([\w\.]+)/i,/\((series40);/i],[u,p],[/\(bb(10);/i],[p,[u,j]],[/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],[p,[u,"Symbian"]],[/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],[p,[u,A+" OS"]],[/web0s;.+rt(tv)/i,/\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],[p,[u,"webOS"]],[/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],[p,[u,"watchOS"]],[/crkey\/([\d\.]+)/i],[p,[u,C+"cast"]],[/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],[[u,B],p],[/panasonic;(viera)/i,/(netrange)mmh/i,/(nettv)\/(\d+\.[\w\.]+)/i,/(nintendo|playstation) ([wids345portablevuch]+)/i,/(xbox); +xbox ([^\);]+)/i,/\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,/(mint)[\/\(\) ]?(\w*)/i,/(mageia|vectorlinux)[; ]/i,/([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,/(hurd|linux) ?([\w\.]*)/i,/(gnu) ?([\w\.]*)/i,/\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,/(haiku) (\w+)/i],[u,p],[/(sunos) ?([\w\.\d]*)/i],[[u,"Solaris"],p],[/((?:open)?solaris)[-\/ ]?([\w\.]*)/i,/(aix) ((\d)(?=\.|\)| )[\w\.])*/i,/\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i,/(unix) ?([\w\.]*)/i],[u,p]]},Q=function(e,n){if(typeof e===a&&(n=e,e=r),!(this instanceof Q))return new Q(e,n).getResult();var h=typeof t!==i&&t.navigator?t.navigator:r,y=e||(h&&h.userAgent?h.userAgent:""),b=h&&h.userAgentData?h.userAgentData:r,w=n?function(e,t){var n={};for(var r in e)t[r]&&t[r].length%2==0?n[r]=t[r].concat(e[r]):n[r]=e[r];return n}(G,n):G,x=h&&h.userAgent==y;return this.getBrowser=function(){var e,t={};return t[u]=r,t[p]=r,q.call(t,y,w.browser),t[s]=typeof(e=t[p])===l?e.replace(/[^\d\.]/g,"").split(".")[0]:r,x&&h&&h.brave&&typeof h.brave.isBrave==o&&(t[u]="Brave"),t},this.getCPU=function(){var e={};return e[m]=r,q.call(e,y,w.cpu),e},this.getDevice=function(){var e={};return e[f]=r,e[c]=r,e[d]=r,q.call(e,y,w.device),x&&!e[d]&&b&&b.mobile&&(e[d]=g),x&&"Macintosh"==e[c]&&h&&typeof h.standalone!==i&&h.maxTouchPoints&&h.maxTouchPoints>2&&(e[c]="iPad",e[d]=v),e},this.getEngine=function(){var e={};return e[u]=r,e[p]=r,q.call(e,y,w.engine),e},this.getOS=function(){var e={};return e[u]=r,e[p]=r,q.call(e,y,w.os),x&&!e[u]&&b&&"Unknown"!=b.platform&&(e[u]=b.platform.replace(/chrome os/i,B).replace(/macos/i,F)),e},this.getResult=function(){return{ua:this.getUA(),browser:this.getBrowser(),engine:this.getEngine(),os:this.getOS(),device:this.getDevice(),cpu:this.getCPU()}},this.getUA=function(){return y},this.setUA=function(e){return y=typeof e===l&&e.length>350?H(e,350):e,this},this.setUA(y),this};Q.VERSION="1.0.35",Q.BROWSER=U([u,p,s]),Q.CPU=U([m]),Q.DEVICE=U([c,f,d,h,g,y,v,b,w]),Q.ENGINE=Q.OS=U([u,p]),e.exports&&(n=e.exports=Q),n.UAParser=Q;var K=typeof t!==i&&(t.jQuery||t.Zepto);if(K&&!K.ua){var X=new Q;K.ua=X.getResult(),K.ua.get=function(){return X.getUA()},K.ua.set=function(e){X.setUA(e);var t=X.getResult();for(var n in t)K.ua[n]=t[n]}}}("object"==typeof window?window:t)}(ew,ew.exports);var tw=ew.exports;Object.defineProperty(Zb,"__esModule",{value:!0});var nw,rw=W,ow=(nw=rw)&&"object"==typeof nw&&"default"in nw?nw.default:nw,iw=tw,aw=new iw,lw=aw.getBrowser(),sw=aw.getCPU(),cw=aw.getDevice(),uw=aw.getEngine(),dw=aw.getOS(),fw=aw.getUA(),pw=function(e){return aw.setUA(e)},mw=function(e){if(e){var t=new iw(e);return{UA:t,browser:t.getBrowser(),cpu:t.getCPU(),device:t.getDevice(),engine:t.getEngine(),os:t.getOS(),ua:t.getUA(),setUserAgent:function(e){return t.setUA(e)}}}console.error("No userAgent string was provided")},hw=Object.freeze({ClientUAInstance:aw,browser:lw,cpu:sw,device:cw,engine:uw,os:dw,ua:fw,setUa:pw,parseUserAgent:mw});function gw(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function vw(e){return(vw="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}function yw(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function bw(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function ww(){return ww=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},ww.apply(this,arguments)}function xw(e){return(xw=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)})(e)}function kw(e,t){return(kw=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e})(e,t)}function Sw(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},i=Object.keys(e);for(r=0;r<i.length;r++)n=i[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);for(r=0;r<i.length;r++)n=i[r],t.indexOf(n)>=0||Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}function jw(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e}function Ew(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null==n)return;var r,o,i=[],a=!0,l=!1;try{for(n=n.call(e);!(a=(r=n.next()).done)&&(i.push(r.value),!t||i.length!==t);a=!0);}catch(s){l=!0,o=s}finally{try{a||null==n.return||n.return()}finally{if(l)throw o}}return i}(e,t)||function(e,t){if(!e)return;if("string"==typeof e)return Cw(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name);if("Map"===n||"Set"===n)return Array.from(e);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return Cw(e,t)}(e,t)||function(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function Cw(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=new Array(t);n<t;n++)r[n]=e[n];return r}var Aw="mobile",Ow="tablet",Nw="smarttv",_w="console",Pw="wearable",Iw="embedded",Tw=void 0,Lw={Chrome:"Chrome",Firefox:"Firefox",Opera:"Opera",Yandex:"Yandex",Safari:"Safari",InternetExplorer:"Internet Explorer",Edge:"Edge",Chromium:"Chromium",Ie:"IE",MobileSafari:"Mobile Safari",EdgeChromium:"Edge Chromium",MIUI:"MIUI Browser",SamsungBrowser:"Samsung Browser"},Mw={IOS:"iOS",Android:"Android",WindowsPhone:"Windows Phone",Windows:"Windows",MAC_OS:"Mac OS"},Rw={isMobile:!1,isTablet:!1,isBrowser:!1,isSmartTV:!1,isConsole:!1,isWearable:!1},zw=function(e){return e||(arguments.length>1&&void 0!==arguments[1]?arguments[1]:"none")},$w=function(){return!("undefined"==typeof window||!window.navigator&&!navigator)&&(window.navigator||navigator)},Dw=function(e){var t=$w();return t&&t.platform&&(-1!==t.platform.indexOf(e)||"MacIntel"===t.platform&&t.maxTouchPoints>1&&!window.MSStream)},Bw=function(e,t,n,r){return function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?gw(Object(n),!0).forEach((function(t){bw(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):gw(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}({},e,{vendor:zw(t.vendor),model:zw(t.model),os:zw(n.name),osVersion:zw(n.version),ua:zw(r)})};var Fw=function(e){return e.type===Aw},Uw=function(e){return e.type===Ow},Ww=function(e){var t=e.type;return t===Aw||t===Ow},Vw=function(e){return e.type===Nw},Hw=function(e){return e.type===Tw},qw=function(e){return e.type===Pw},Yw=function(e){return e.type===_w},Jw=function(e){return e.type===Iw},Gw=function(e){var t=e.vendor;return zw(t)},Qw=function(e){var t=e.model;return zw(t)},Kw=function(e){var t=e.type;return zw(t,"browser")},Xw=function(e){return e.name===Mw.Android},Zw=function(e){return e.name===Mw.Windows},ex=function(e){return e.name===Mw.MAC_OS},tx=function(e){return e.name===Mw.WindowsPhone},nx=function(e){return e.name===Mw.IOS},rx=function(e){var t=e.version;return zw(t)},ox=function(e){var t=e.name;return zw(t)},ix=function(e){return e.name===Lw.Chrome},ax=function(e){return e.name===Lw.Firefox},lx=function(e){return e.name===Lw.Chromium},sx=function(e){return e.name===Lw.Edge},cx=function(e){return e.name===Lw.Yandex},ux=function(e){var t=e.name;return t===Lw.Safari||t===Lw.MobileSafari},dx=function(e){return e.name===Lw.MobileSafari},fx=function(e){return e.name===Lw.Opera},px=function(e){var t=e.name;return t===Lw.InternetExplorer||t===Lw.Ie},mx=function(e){return e.name===Lw.MIUI},hx=function(e){return e.name===Lw.SamsungBrowser},gx=function(e){var t=e.version;return zw(t)},vx=function(e){var t=e.major;return zw(t)},yx=function(e){var t=e.name;return zw(t)},bx=function(e){var t=e.name;return zw(t)},wx=function(e){var t=e.version;return zw(t)},xx=function(){var e=$w(),t=e&&e.userAgent&&e.userAgent.toLowerCase();return"string"==typeof t&&/electron/.test(t)},kx=function(e){return"string"==typeof e&&-1!==e.indexOf("Edg/")},Sx=function(){var e=$w();return e&&(/iPad|iPhone|iPod/.test(e.platform)||"MacIntel"===e.platform&&e.maxTouchPoints>1)&&!window.MSStream},jx=function(){return Dw("iPad")},Ex=function(){return Dw("iPhone")},Cx=function(){return Dw("iPod")},Ax=function(e){return zw(e)};function Ox(e){var t=e||hw,n=t.device,r=t.browser,o=t.os,i=t.engine,a=t.ua;return{isSmartTV:Vw(n),isConsole:Yw(n),isWearable:qw(n),isEmbedded:Jw(n),isMobileSafari:dx(r)||jx(),isChromium:lx(r),isMobile:Ww(n)||jx(),isMobileOnly:Fw(n),isTablet:Uw(n)||jx(),isBrowser:Hw(n),isDesktop:Hw(n),isAndroid:Xw(o),isWinPhone:tx(o),isIOS:nx(o)||jx(),isChrome:ix(r),isFirefox:ax(r),isSafari:ux(r),isOpera:fx(r),isIE:px(r),osVersion:rx(o),osName:ox(o),fullBrowserVersion:gx(r),browserVersion:vx(r),browserName:yx(r),mobileVendor:Gw(n),mobileModel:Qw(n),engineName:bx(i),engineVersion:wx(i),getUA:Ax(a),isEdge:sx(r)||kx(a),isYandex:cx(r),deviceType:Kw(n),isIOS13:Sx(),isIPad13:jx(),isIPhone13:Ex(),isIPod13:Cx(),isElectron:xx(),isEdgeChromium:kx(a),isLegacyEdge:sx(r)&&!kx(a),isWindows:Zw(o),isMacOs:ex(o),isMIUI:mx(r),isSamsungBrowser:hx(r)}}var Nx=Vw(cw),_x=Yw(cw),Px=qw(cw),Ix=Jw(cw),Tx=dx(lw)||jx(),Lx=lx(lw),Mx=Ww(cw)||jx(),Rx=Fw(cw),zx=Uw(cw)||jx(),$x=Hw(cw),Dx=Hw(cw),Bx=Xw(dw),Fx=tx(dw),Ux=nx(dw)||jx(),Wx=ix(lw),Vx=ax(lw),Hx=ux(lw),qx=fx(lw),Yx=px(lw),Jx=rx(dw),Gx=ox(dw),Qx=gx(lw),Kx=vx(lw),Xx=yx(lw),Zx=Gw(cw),ek=Qw(cw),tk=bx(uw),nk=wx(uw),rk=Ax(fw),ok=sx(lw)||kx(fw),ik=cx(lw),ak=Kw(cw),lk=Sx(),sk=jx(),ck=Ex(),uk=Cx(),dk=xx(),fk=kx(fw),pk=sx(lw)&&!kx(fw),mk=Zw(dw),hk=ex(dw),gk=mx(lw),vk=hx(lw);function yk(e){var t=e||window.navigator.userAgent;return mw(t)}Zb.AndroidView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Bx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.BrowserTypes=Lw;var bk=Zb.BrowserView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return $x?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null};Zb.ConsoleView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return _x?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.CustomView=function(e){var t=e.renderWithFragment,n=e.children;e.viewClassName,e.style;var r=e.condition,o=Sw(e,["renderWithFragment","children","viewClassName","style","condition"]);return r?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",o,n):null},Zb.IEView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Yx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.IOSView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Ux?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.MobileOnlyView=function(e){var t=e.renderWithFragment,n=e.children;e.viewClassName,e.style;var r=Sw(e,["renderWithFragment","children","viewClassName","style"]);return Rx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null};var wk=Zb.MobileView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Mx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null};Zb.OsTypes=Mw,Zb.SmartTVView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Nx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.TabletView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return zx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.WearableView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Px?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.WinPhoneView=function(e){var t=e.renderWithFragment,n=e.children,r=Sw(e,["renderWithFragment","children"]);return Fx?t?ow.createElement(rw.Fragment,null,n):ow.createElement("div",r,n):null},Zb.browserName=Xx,Zb.browserVersion=Kx,Zb.deviceDetect=function(e){var t=e?mw(e):hw,n=t.device,r=t.browser,o=t.engine,i=t.os,a=t.ua,l=function(e){switch(e){case Aw:return{isMobile:!0};case Ow:return{isTablet:!0};case Nw:return{isSmartTV:!0};case _w:return{isConsole:!0};case Pw:return{isWearable:!0};case Tw:return{isBrowser:!0};case Iw:return{isEmbedded:!0};default:return Rw}}(n.type),s=l.isBrowser,c=l.isMobile,u=l.isTablet,d=l.isSmartTV,f=l.isConsole,p=l.isWearable,m=l.isEmbedded;return s?function(e,t,n,r,o){return{isBrowser:e,browserMajorVersion:zw(t.major),browserFullVersion:zw(t.version),browserName:zw(t.name),engineName:zw(n.name),engineVersion:zw(n.version),osName:zw(r.name),osVersion:zw(r.version),userAgent:zw(o)}}(s,r,o,i,a):d?function(e,t,n,r){return{isSmartTV:e,engineName:zw(t.name),engineVersion:zw(t.version),osName:zw(n.name),osVersion:zw(n.version),userAgent:zw(r)}}(d,o,i,a):f?function(e,t,n,r){return{isConsole:e,engineName:zw(t.name),engineVersion:zw(t.version),osName:zw(n.name),osVersion:zw(n.version),userAgent:zw(r)}}(f,o,i,a):c||u?Bw(l,n,i,a):p?function(e,t,n,r){return{isWearable:e,engineName:zw(t.name),engineVersion:zw(t.version),osName:zw(n.name),osVersion:zw(n.version),userAgent:zw(r)}}(p,o,i,a):m?function(e,t,n,r,o){return{isEmbedded:e,vendor:zw(t.vendor),model:zw(t.model),engineName:zw(n.name),engineVersion:zw(n.version),osName:zw(r.name),osVersion:zw(r.version),userAgent:zw(o)}}(m,n,o,i,a):void 0},Zb.deviceType=ak,Zb.engineName=tk,Zb.engineVersion=nk,Zb.fullBrowserVersion=Qx,Zb.getSelectorsByUserAgent=function(e){if(e&&"string"==typeof e){var t=mw(e);return Ox({device:t.device,browser:t.browser,os:t.os,engine:t.engine,ua:t.ua})}console.error("No valid user agent string was provided")},Zb.getUA=rk,Zb.isAndroid=Bx,Zb.isBrowser=$x,Zb.isChrome=Wx,Zb.isChromium=Lx,Zb.isConsole=_x,Zb.isDesktop=Dx,Zb.isEdge=ok,Zb.isEdgeChromium=fk,Zb.isElectron=dk,Zb.isEmbedded=Ix,Zb.isFirefox=Vx,Zb.isIE=Yx,Zb.isIOS=Ux,Zb.isIOS13=lk,Zb.isIPad13=sk,Zb.isIPhone13=ck,Zb.isIPod13=uk,Zb.isLegacyEdge=pk,Zb.isMIUI=gk,Zb.isMacOs=hk;var xk=Zb.isMobile=Mx;Zb.isMobileOnly=Rx,Zb.isMobileSafari=Tx,Zb.isOpera=qx,Zb.isSafari=Hx,Zb.isSamsungBrowser=vk,Zb.isSmartTV=Nx,Zb.isTablet=zx,Zb.isWearable=Px,Zb.isWinPhone=Fx,Zb.isWindows=mk,Zb.isYandex=ik,Zb.mobileModel=ek,Zb.mobileVendor=Zx,Zb.osName=Gx,Zb.osVersion=Jx,Zb.parseUserAgent=mw,Zb.setUserAgent=function(e){return pw(e)},Zb.useDeviceData=yk,Zb.useDeviceSelectors=function(e){var t=yk(e||window.navigator.userAgent);return[Ox(t),t]},Zb.useMobileOrientation=function(){var e=Ew(rw.useState((function(){var e=window.innerWidth>window.innerHeight?90:0;return{isPortrait:0===e,isLandscape:90===e,orientation:0===e?"portrait":"landscape"}})),2),t=e[0],n=e[1],r=rw.useCallback((function(){var e=window.innerWidth>window.innerHeight?90:0,r={isPortrait:0===e,isLandscape:90===e,orientation:0===e?"portrait":"landscape"};t.orientation!==r.orientation&&n(r)}),[t.orientation]);return rw.useEffect((function(){return void 0!==("undefined"==typeof window?"undefined":vw(window))&&Mx&&(r(),window.addEventListener("load",r,!1),window.addEventListener("resize",r,!1)),function(){window.removeEventListener("resize",r,!1),window.removeEventListener("load",r,!1)}}),[r]),t},Zb.withOrientationChange=function(e){return function(t){function n(e){var t;return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,n),(t=function(e,t){if(t&&("object"==typeof t||"function"==typeof t))return t;if(void 0!==t)throw new TypeError("Derived constructors may only return object or undefined");return jw(e)}(this,xw(n).call(this,e))).isEventListenerAdded=!1,t.handleOrientationChange=t.handleOrientationChange.bind(jw(t)),t.onOrientationChange=t.onOrientationChange.bind(jw(t)),t.onPageLoad=t.onPageLoad.bind(jw(t)),t.state={isLandscape:!1,isPortrait:!1},t}var r,o,i;return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function");e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&kw(e,t)}(n,ow.Component),r=n,(o=[{key:"handleOrientationChange",value:function(){this.isEventListenerAdded||(this.isEventListenerAdded=!0);var e=window.innerWidth>window.innerHeight?90:0;this.setState({isPortrait:0===e,isLandscape:90===e})}},{key:"onOrientationChange",value:function(){this.handleOrientationChange()}},{key:"onPageLoad",value:function(){this.handleOrientationChange()}},{key:"componentDidMount",value:function(){void 0!==("undefined"==typeof window?"undefined":vw(window))&&Mx&&(this.isEventListenerAdded?window.removeEventListener("load",this.onPageLoad,!1):(this.handleOrientationChange(),window.addEventListener("load",this.onPageLoad,!1)),window.addEventListener("resize",this.onOrientationChange,!1))}},{key:"componentWillUnmount",value:function(){window.removeEventListener("resize",this.onOrientationChange,!1)}},{key:"render",value:function(){return ow.createElement(e,ww({},this.props,{isLandscape:this.state.isLandscape,isPortrait:this.state.isPortrait}))}}])&&yw(r.prototype,o),i&&yw(r,i),n}()};var kk=["getUTCDate","getUTCMonth","0","padStart","floor","charCodeAt","","reduce","split"];function Sk(e){var t=new Date,n=17+(t[kk[0]]()-t[kk[1]]())/2;return e[kk[8]](kk[6])[kk[7]](((e,t)=>e+t[kk[5]](0).toString(Math[kk[4]](n))[kk[3]](2,kk[2])),kk[6])}var jk="animeflix.live"===window.location.hostname?"https://api.animeflix.dev":"https://api.animeflixtv.to";var Ek=new class{async watchEpisode(e,t,n){if(e){var r=await fetch(`${jk}/watch/${e}?server=${n}&c=${Sk(e)}`).then((e=>e.json()));return(null==r?void 0:r.source)?`${r.source}&position=${t}`:null}}async getTrending(e=0){return await fetch(`${jk}/trending?page=${e}`).then((e=>e.json()))}async getMovies(e=0){return await fetch(`${jk}/movies?page=${e}`).then((e=>e.json()))}async getSeries(e=0){return await fetch(`${jk}/series?page=${e}`).then((e=>e.json()))}async getPopular(e=0){return await fetch(`${jk}/popular?page=${e}`).then((e=>e.json()))}async getAiring(){return await fetch(`${jk}/airing`).then((e=>e.json()))}async idsToInfo(e=[]){return await fetch(`${jk}/idtoinfo?ids=${e}&y=${Sk("idinfo")}`).then((e=>e.json()))}async getBySlug(e){return await fetch(`${jk}/getslug/${e}`).then((e=>e.json()))}async getEpisodes(e,t){if(e)return await fetch(`${jk}/episodes?id=${e}&dub=${t}&c=${Sk(e)}`).then((e=>e.json()))||{}}async getGenres(){return await fetch(`${jk}/genrepage`).then((e=>e.json()))}async getSchedule(){return await fetch(`${jk}/schedule`).then((e=>e.json()))}async getCollection(){return await fetch(`${jk}/collections`).then((e=>e.json()))}async getGenre(e,t=0){if(e)return await fetch(`${jk}/genres/${e}?page=${t}`).then((e=>e.json()))}async authUser(e,t,n){if(e&&t)return await fetch(`${jk}/login?head=${e}&password=${t}&capt=${n}`).then((e=>e.json()))}async getAuth(e){if(e){var t=await fetch(`${jk}/login?token=${e}`).then((e=>e.json()));return!(null==t?void 0:t.error)&&(null==t?void 0:t.user)}}async set(e,t,n){if(e&&t)return await fetch(`${jk}/update?token=${e}&path=${encodeURIComponent(t)}`,{method:"POST",body:JSON.stringify(n),headers:{"Content-Type":"text/plain;charset=UTF-8"}}).then((e=>e.json()))}async sendPasswordReset(e){if(e)return await fetch(`${jk}/passemail?head=${e}`).then((e=>e.json()))}async accountDelete(e){if(e)return await fetch(`${jk}/accdelete?token=${e}`).then((e=>e.json()))}async registerUser(e,t,n,r){if(e&&t&&n)return await fetch(`${jk}/register?email=${e}&username=${t}&password=${n}&capt=${r}`).then((e=>e.json()))}async search(e,t=20,n){if(e)return await fetch(`${jk}/info/?query=${e}&limit=${t}${n?`&filters=${n}`:""}&k=${Sk(e.substring(0,3))}`).then((e=>e.json()))}async getMalUser(e){if(e)return await fetch(`${jk}/maluser?username=${e}`).then((e=>e.json()))}};class Ck{static filterPercentage(e){if(e)return e.match(/^\d{2}/i)}static toDaysMinutesSeconds(e=void 0){if(!e)return;function t(e,t){return e>0?e+(1===e?` ${t}`:` ${t}s`):""}const n=Math.floor(e%60),r=Math.floor(e%3600/60),o=Math.floor(e%86400/3600),i=Math.floor(e/86400),a=t(n,"second"),l=t(r,"minute"),s=t(o,"hour"),c=t(i,"day");var u="";return e>86400?u=`${c}`:e<86400?u=`${s?`${s}, `:""}${l}`:e<3600&&(u=`${l?`${l}, `:""}${a}`),u}static toAiringDate(e){var t=null==e?void 0:e.airingAt;if(!t)return;var n=new Date(0);n.setUTCSeconds(t);var r=(n.getTime()-(new Date).getTime())/1e3;if(r<0&&e.delayed)return`Episode ${null==e?void 0:e.episode} has been delayed!`;if(r<0)return`Episode ${(null==e?void 0:e.episode)||1} should be airing now!`;function o(e,t){return e>0?e+(1===e?` ${t}`:` ${t}s`):""}const i=Math.floor(r%60),a=Math.floor(r%3600/60),l=Math.floor(r%86400/3600),s=Math.floor(r/86400),c=o(i,"second"),u=o(a,"minute"),d=o(l,"hour"),f=o(s,"day");var p="";return r>86400?p=`${f}`:r<86400?p=`${d?`${d}, `:""}${u}`:r<3600&&(p=`${u?`${u}, `:""}${c}`),`Episode ${(null==e?void 0:e.episode)||1} airing in ${p}`}static toDMS(e){if(!e)return;var t=new Date(0);t.setUTCSeconds(e);var n=(t.getTime()-(new Date).getTime())/1e3;if(n<0)return"Airing now!";function r(e,t){return e>0?e+`${t}`:""}const o=Math.floor(n%60),i=Math.floor(n%3600/60),a=Math.floor(n%86400/3600),l=Math.floor(n/86400),s=r(o,"s"),c=r(i,"m"),u=r(a,"h"),d=r(l," days");var f="";return n>86400?f=`${d}`:n<86400?f=`${u?`${u} `:""}${c?`${c}`:""}`:n<3600&&(f=`${c?`${c} `:""}${s?`${s}`:""}`),f}static filterYear(e){if(e)return e.match(/^\d{4}/i)}static trimParagraph(e,t=165,n="...  "){return e&&e.length>t&&(e=(e=e.substring(0,t)).substring(0,Math.min(e.length,e.lastIndexOf(" "))),e+=n),e}}const Ak=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;
  
  ::-webkit-scrollbar { 
    display: none;  /* Safari and Chrome */
  }

  font-size: clamp(1.2rem, 1.4vw, 2rem);

  ${e=>e.opening&&Xm`
    animation: ${Sb} 400ms;
  `}

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}
`,Ok=dh.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 10;
  ul {
    position: absolute;
    ${({top:e,left:t})=>Xm`
      top: ${e}px;
      left: ${t}px;
    `}
    animation: ${kb} 200ms;
    min-width: 7em;
    padding: .5rem 0;
    color: #777;
    text-align: left;
    list-style: none;
    background-color: #242424;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: 5px;
    @media (pointer:none), (pointer:coarse) {
      width: fit-content;
    }
  }
  ul li {
    display: block;
    width: 100%;
    padding: .25rem 1.5rem;
    padding-right: 5rem;
    clear: both;
    line-height: 2;
    font-weight: 400;
    color: #848484;
    text-align: inherit;
    white-space: nowrap;
    background-color: transparent;
    border: 0;
  }
  /* hover */
  ul li:hover {
    cursor:pointer;
    color: #adadad; 
    text-decoration: none; 
    background-color: #2e2e2e;
  }
`,Nk=dh.ul`
  position: absolute;
  top: 1%;
  left: .5rem;
  color: white;
  cursor: pointer;
  transition: opacity 200ms ease;
  border-radius: .375rem;
  padding: .1rem .6rem .1rem .6rem; 
  --tw-bg-opacity: 1; 
  background-color: rgb(38 38 38/var(--tw-bg-opacity));
  width: -webkit-max-content; 
  width: -moz-max-content; 
  width: max-content;
`,_k=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);

  @media (max-width: 700px) {
    padding: 0;
  }
`,Pk=dh.div`
  width: clamp(26rem, 70vw, 100rem);
  line-height: 1.5;
  border-radius: .5rem;
  background: #181818;
  ${e=>e.opening&&Xm`
    animation: ${kb} 400ms;
  `}

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}

  @media (max-width: 700px) {
    width: 100vw;
  }
`,Ik=dh.header`
  height: clamp(20rem, 34vw, 50rem);
  display: flex;
  position: relative;
  align-items: flex-end;
  padding: 1.5vw 2vw;
  border-radius: .5rem .5rem 0 0;
  background: linear-gradient(0deg, #181818 1%, transparent 99%), 
              url(${e=>e.background}) no-repeat;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

  h3 {
    font-weight: normal;
    margin-bottom: max(1vw, 1rem);
  }
`,Tk=dh.div`
  display: flex;
  align-items: center;
`,Lk=dh.main`
  padding: 1.5vw 2vw;
  padding-top: 0;

  & .separator {
    line-height: 2;
    margin-top: 1.5vw;
  }
`,Mk=dh.div`
  display: flex;
  margin-bottom: .5vw;
  
  section {
    width: 45vw;
    margin-left: 1.5vw;

    @media (max-width: 700px) {
      display: none;
    }
  }
`,Rk=dh.button`
background: none;
color: #5a5a5a;
cursor: pointer;

:hover {
  color: #494949;
}
`,zk=dh.div`
  font-size: 80%;
  margin-bottom: .3vw;

  strong {
    color: #46D369;
  }

  label:not(:first-child) {
    margin-left: 1rem;
  }
`;function $k(){return Z.jsxs("div",{className:"bouncing-loader",style:{display:"flex",justifyContent:"center"},children:[Z.jsx("div",{}),Z.jsx("div",{}),Z.jsx("div",{})]})}const Dk=dh.div`
  animation: ${Sb} 300ms forwards;
`,Bk=dh.header`
  display: flex;
  align-items: center;
  position: relative;

  h3 {
    margin-top: .5vw;
    margin-bottom: 0;
    line-height: 2;
  }
`,Fk=dh.button`
background: none;
color: #5a5a5a;
cursor: pointer;
float: right;
margin: 0;
position: absolute;
white-space: nowrap;
right: .01rem;
top: -1rem;

:hover {
  color: #494949;
}
`,Uk=dh.button`
background: none;
color: #5a5a5a;
cursor: pointer;
float: right;
margin: 0;
position: absolute;
white-space: nowrap;
top: -1rem;

:hover {
  color: #494949;
}
`,Wk=dh.div`
  padding: 1rem 0;
  width: 100%;

  & + & {
    border-top: 1px solid #3f3f3f;
  }

  @media (min-width: 700px) {
    display: flex;
    padding: 1.5rem 2.5rem;
  }

  @media (max-width: 700px) {
    float: left;
    display: flex;
    padding-bottom: .5rem;
  }

  &:hover {
    img {
      filter: brightness(50%);
    }
  }
`,Vk=dh.div`
  display: flex;
  background: #141414;
  position:relative;

  img {
    width: 14.5rem;
    height: 8.1rem;
    object-fit: cover;
    border-radius: .5rem;

    transition: filter 200ms ease;
    @media (max-width: 700px) {
      float:left;
    }
  }
`,Hk=dh.div`
  p {
    color: #B2B2B2;
    max-height: 5.2rem;
    position: relative;

    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  h4 {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
  }

  @media (max-width: 700px) {
    display: none;
  }

  @media (min-width: 700px) {
    margin-left: 2rem;
  }

  @media (min-width: 1200px) {
    font-size: 80%;
  }
`,qk=dh.div`
  p {
    color: #B2B2B2;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
  position: relative;
  display:none;
  height: 6em;
  overflow: hidden;

  h4 {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
  }

  @media (max-width: 700px) {
    display:block;
    margin: auto;
    margin-left: 1rem;
  }

  @media (min-width: 700px) {
    margin-left: 2rem;
  }

  @media (min-width: 1200px) {
    font-size: 80%;
  }
`;var Yk={},Jk=bh;Object.defineProperty(Yk,"__esModule",{value:!0});var Gk=Yk.default=void 0,Qk=Jk(hb()),Kk=Z,Xk=(0,Qk.default)((0,Kk.jsx)("path",{d:"M16 17.01V10h-2v7.01h-3L15 21l4-3.99h-3zM9 3 5 6.99h3V14h2V6.99h3L9 3z"}),"SwapVert");Gk=Yk.default=Xk;const Zk=dh.div`
  width: fit-content;
  position: relative;
  margin-left: 1rem;
`,eS=dh.div`
  width: 99%;
  position: absolute;
  flex-direction: column;
  border: 1px solid #4d4d4d;
  border-radius: .3rem;
  background: #242424;
  z-index: 2;
  display: ${e=>e.fold?"none":"flex"};

  button {
    color: white;
    background: none;
    padding: min(1vw, 1.5rem) 0;
    cursor: pointer;

    &:hover {
      background: #424242;
    }
  }
`,tS=dh.button`
  color: white;
  cursor: pointer;
  padding: min(1vw, 1rem) min(4vw, 4rem);
  border: 1px solid #4d4d4d;
  border-radius: .3rem;
  background: #242424;
`;function nS({elements:e,onChange:t=(()=>{}),chosen:n=0}){const r=W.useRef(),o=W.useRef(),[i,a]=W.useState(n),[l,s]=W.useState(!0);return W.useEffect((()=>{function e(e){l||r.current.contains(e.target)||o.current.contains(e.target)||s(!0)}return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]),Z.jsxs(Zk,{children:[Z.jsx(tS,{ref:r,type:"button",onClick:function(){s(!l)},children:e[i]}),Z.jsx(eS,{ref:o,fold:l,style:{maxHeight:"1500%",overflow:"auto"},children:e.map(((e,n)=>Z.jsx("button",{type:"button",onClick:()=>{return e=n,s(!0),a(e),void t(e);var e},children:e},n)))})]})}const rS=dh.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  margin-top: -1vw;
`,oS=dh.div`
  width: 100%;
  display: flex;
  position: absolute;
  margin-top: -3vw;
  height: 100%;
  background-image: linear-gradient(to bottom, transparent 1%, #181818 100%);
  background-color: transparent;
  border: none;
`,iS=dh.button`
  width: max(2.5rem, 2.5vw);
  height: max(2.5rem, 2.5vw);
  color: #fff;
  border: 2px solid gray;
  border-radius: 50%;
  background: #2a2a2a;
  cursor: pointer;
  position: relative;
  transition: background ease 200ms;

  :hover {
    background: #545454;
  }
`,aS=dh.div`
  height: 8%;
  width: inherit;
  background: #404040;
  position: absolute;
`,lS=dh.div`
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform ease 200ms;

  ${e=>e.toggled&&Xm`
    transform: rotate(180deg);
  `};
`;var sS={},cS=bh;Object.defineProperty(sS,"__esModule",{value:!0});var uS=sS.default=void 0,dS=cS(hb()),fS=Z,pS=(0,dS.default)((0,fS.jsx)("path",{d:"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"}),"KeyboardArrowDown");function mS({initialValue:e=!1,onClick:t=(()=>{})}){const[n,r]=W.useState(e);return Z.jsxs(rS,{children:[Z.jsx(oS,{id:"test"}),Z.jsx(aS,{}),Z.jsx(iS,{type:"button",onClick:function(e){t(e),r(!n)},children:Z.jsx(lS,{toggled:n,children:Z.jsx(uS,{style:{fontSize:"max(2rem, 1.8vw)"}})})})]})}uS=sS.default=pS;const hS=5;function gS({anime:e,thumbnail:t}){var n,r;const[o,i]=W.useState(!0);var[a,l]=W.useState(null),s=JSON.parse(localStorage.getItem("settings"));const[c,u]=W.useState("dub"===(null==s?void 0:s.prefered_source_type)),[d,f]=W.useState(0),[p,m]=W.useState(!0),[h,g]=W.useState(!1),v=Number((null==(n=JSON.parse(localStorage.getItem("settings")))?void 0:n.watchlist_perpage)||20);W.useEffect((()=>{let t=!0,n=!1;return setTimeout((()=>{n?i(!1):n=0}),200),Ek.getEpisodes(e.slug,c).then((e=>{var r,o;if(t){if(h&&e.episodes.reverse(),l({episodes:null==(r=null==e?void 0:e.episodes)?void 0:r.slice(d,d+v),amount:null==(o=e.episodes)?void 0:o.length,status:null==e?void 0:e.status}),0===n)return i(!1);n=!0}})).catch((e=>{if(hd.dismiss(),"Failed to fetch"===e.message)return hd.error("Could not reach Animeflix servers! Try again in a few minutes.",{style:{background:"#333",color:"#fff"}});hd.error("You are being rate limited! Please slow down.",{style:{background:"#333",color:"#fff"}})})),()=>{t=!1}}),[e,d,c,v,h]);var y=JSON.parse(localStorage.getItem(`${e.anilistID}`));function b(e){e!==c&&(u(e),i(!0))}return Z.jsxs(W.Fragment,{children:[!o&&Z.jsxs(Dk,{children:[Z.jsxs(Bk,{children:[Z.jsx("h3",{style:{margin:"auto .6% auto 0"},children:"Episodes"}),Z.jsx(Gk,{style:{cursor:"pointer",fontSize:"1.5em"},onClick:()=>g(!h)}),Z.jsxs("div",{style:{float:"right",display:"flex",marginLeft:"auto"},children:[a&&Z.jsx(nS,{chosen:c?1:0,elements:["Subtitles","Dubbed"],onChange:e=>b(1===e)}),function(){const e=[],t=Math.ceil((null==a?void 0:a.amount)/v);if(t>1){for(let n=0;n<t;n++)e.push(`Page ${n+1}`);return Z.jsx(nS,{elements:e,onChange:e=>{f(e*v)}})}}()]})]}),(()=>{var n,r;const o=[];if(!(null==(n=null==a?void 0:a.episodes)?void 0:n.length))return Z.jsx("p",{style:{textAlign:"center"},children:c?"No dubbed episodes found.":"No episodes found."});const i=p?Math.min(hS,a.episodes.length):a.episodes.length;for(let l=0;l<i;l++){const n=a.episodes[l],i=null==(r=null==y?void 0:y.episodes)?void 0:r.find((e=>n.number===Number(e.episodeId.split("-episode-")[1])));o.push(Z.jsx("a",{onClick:()=>{sessionStorage.setItem("animeinfo",JSON.stringify({...e,lastpage:window.location.pathname,episode:{number:n.number,title:n.title?n.title:`Episode ${n.number}`}})),window.history.replaceState({},"",window.location.pathname),window.history.pushState({},"",`${window.location.pathname}?anime=${e.slug}`)},href:`/watch/${e.slug}${n.dub?"-dub":""}-episode-${n.number}/${i&&i.outof-i.position>30?i.position:""}`,title:n.description?n.description:"",style:{textDecoration:"none"},children:Z.jsxs(Wk,{children:["noimage"!==(null==s?void 0:s.episode_list_style)&&Z.jsxs(Vk,{children:[Z.jsx("img",{alt:"thumbnail",src:n.image||t}),Z.jsx("div",{style:{position:"absolute",height:".35rem",width:i?`${Math.round(i.position/i.outof*100)}%`:0,backgroundColor:"red",borderRadius:"0 0 .5rem .5rem",bottom:"0",float:"left"}})]}),Z.jsxs(Hk,{children:[Z.jsx("h4",{children:n.title?`${n.number}. ${n.title}`:`Episode ${n.number} - ${e.title.english||e.title.userPreferred||e.title.romaji}`}),"onlytitle"!==(null==s?void 0:s.episode_list_style)&&Z.jsx("p",{children:n.description?n.description:`Episode ${n.number} of ${e.title.english||e.title.userPreferred||e.title.romaji}.\n${e.description?e.description.replace(/<\/?[^>]+(>|$)/g,""):""}`})]}),Z.jsxs(qk,{children:[Z.jsx("h4",{children:n.title?`${n.number}. ${n.title}`:`Episode ${n.number} - ${e.title.english||e.title.userPreferred||e.title.romaji}`}),Z.jsx("p",{children:n.description?n.description:"No description available."})]})]})},l))}return o})(),(null==(r=null==a?void 0:a.episodes)?void 0:r.length)>hS&&Z.jsx(mS,{initialValue:!p,onClick:function(){m(!p)}}),v+1<(d/v+1)*v&&!p&&Z.jsx("div",{style:{position:"relative",width:0,height:0},children:Z.jsx(Uk,{onClick:()=>f((d/v-1)*v),children:"Previous Page"})}),(null==a?void 0:a.amount)>(d/v+1)*v&&!p&&Z.jsx("div",{style:{position:"relative",width:0,height:0,float:"right"},children:Z.jsx(Fk,{onClick:()=>f((d/v+1)*v),children:"Next Page"})})]}),o&&Z.jsxs(Z.Fragment,{children:[Z.jsx("br",{}),Z.jsx($k,{}),Z.jsx("div",{style:{height:9.5*Math.min(7,e.episodeNum)+2+"rem"}})]})]})}const vS=dh.div`
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	grid-auto-rows: minmax(auto, auto);
	gap: 1rem;

	@media (max-width: 600px) {
		grid-template-columns: repeat(2, 1fr);
	}
`,yS=dh.div`
	font-size: 1.6rem;
	line-height: 1.5;
	color: #d2d2d2;
	background-color: #242424;
	border-radius: 0.35rem;
  	cursor: pointer;
	@media (max-width: 600px) {
		font-size: 1.2rem;
		line-height: 1.25;
	}

  transition: filter 300ms ease;
  transition-delay: 20ms;

  &:hover {
    filter: brightness(80%);
	}
`,bS=dh.img`
  aspect-ratio: 16 / 9;
  object-fit: cover;
  width: 100%;
	border-radius: 0.35rem 0.35rem 0 0;
  pointer-events: none;
`,wS=dh.div`
	padding: 0 1rem 1rem;
  pointer-events: none;
	@media (max-width: 600px) {
		padding: 0 0.5rem 0.5rem;
	}
`;dh.p`
	font-weight: 800;
	font-size: 1.5rem;
	margin-bottom: 1.5rem;
`;const xS=dh.p`
  color: #959595;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
  @media (max-width: 900px) {
		font-size: 1.1rem;
	}
`,kS=dh.p`
	font-size: 1.8rem;
	font-weight: 800;
	margin-top: 1rem;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
	@media (max-width: 600px) {
		font-size: 1.3rem;
		margin-top: 0.5rem;
	}
`,SS=dh.p`
	font-size: 1.4rem;
  margin-left: 1.4rem;
  @media (max-width: 600px) {
		margin-left: 1rem;
	}
`,jS=dh.p`
	font-size: 1.4rem;
  color: #46D369;
  display: flex;
`,ES=dh.div`
	display: flex;
  margin-bottom: 1rem;
  @media (max-width: 600px) {
		font-size: 1.2rem;
		margin-bottom: 0.5rem;
	}
`;dh.div`margin-top: 2rem;`;const CS=window.innerWidth>600?6:4;function AS({anime:e,clickAnime:t}){var n;const[r,o]=W.useState(!0);async function i(e){var n=e.target.getAttribute("name");let r=!1;setTimeout((()=>{if(r)return t(r);r=0}),200),Ek.getBySlug(n).then((e=>t(e)))}return Z.jsxs("div",{style:{position:"relative"},children:[Z.jsx("h3",{className:"separator",style:{whiteSpace:"nowrap",marginBottom:".5vw"},children:"Related Anime"}),Z.jsx(vS,{children:(()=>{var t,n,o,a;const l=r?Math.min(CS,null==(t=e.relatedAnime)?void 0:t.length):null==(n=e.relatedAnime)?void 0:n.length;var s=[];for(let r=0;r<l;r++){const t=e.relatedAnime[r];s.push(Z.jsxs(yS,{name:t.slug,onClick:i,children:[Z.jsx(bS,{src:(null==(o=t.images)?void 0:o.large)||"2000"}),Z.jsxs(wS,{children:[Z.jsx(kS,{children:t.animeName.userPreferred}),Z.jsxs(ES,{children:[Z.jsxs(jS,{children:[t.meanScore||50,"% ",window.innerWidth>900?"Match":""]}),Z.jsx(SS,{children:(null==(a=t.startDate)?void 0:a.year)||"2000"}),Z.jsx(SS,{children:t.relationName})]}),Z.jsx(xS,{children:t.description})]})]},r))}return s})()}),(null==(n=e.relatedAnime)?void 0:n.length)>CS&&Z.jsx(mS,{initialValue:!r,onClick:function(){o(!r)}})]})}const OS=dh.div`
  font-size: 75%;
  line-height: 2;
  clear: both;

  li {
    color: #777777;
    list-style-type: none;
  }

  label {
    color: #fff;
  }
`;function NS({limitElements:e,anime:t,fixed:n}){return Z.jsxs(OS,{style:n?{float:"right"}:{},children:[function(){if(t.genres&&t.genres.length>0)return Z.jsxs("li",{children:["Genres: ",(()=>{const n=[],r=e?Math.min(e,t.genres.length):t.genres.length;for(let e=0;e<r;e++){const o=t.genres[e];n.push(Z.jsxs(Cp,{to:`/genre/${o}`,children:[o,e<r-1?", ":""]},e))}return n})()]})}(),Z.jsxs("li",{children:[t.duration&&"Average Episode: ",t.duration&&Z.jsxs("label",{children:[t.duration," minutes"]})]})]})}const _S=dh.button`
  width: min(5vw, 7rem);
  height: min(5vw, 7rem);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 1vw;
  cursor: pointer;
  border-radius: 50%;
  color: #fff;
  background: rgba(42, 42, 42, .6);
  border: 2px solid rgba(255, 255, 255, .5);

  &:hover {
    background: rgba(42, 42, 42, 1);
    border-color: rgba(255, 255, 255, 1)
  }

  @media (max-width: 600px) {
    width: min(7vw, 7rem);
    height: min(7vw, 7rem);
  }
`;dh.button`
  width: min(5vw, 7rem);
  height: min(5vw, 7rem);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 1vw;
  cursor: pointer;
  border-radius: 50%;
  color: #fff;
  background: #EFEFEF;
  border: 2px solid rgba(200, 200, 200, 1);

  &:hover {
    background: #dbd7d7;
    border-color: rgba(200, 200, 200, 1)
  }

  @media (max-width: 600px) {
    width: min(7vw, 7rem);
    height: min(7vw, 7rem);
  }
`;var PS={},IS=bh;Object.defineProperty(PS,"__esModule",{value:!0});var TS=PS.default=void 0,LS=IS(hb()),MS=Z,RS=(0,LS.default)((0,MS.jsx)("path",{d:"M8.12 9.29 12 13.17l3.88-3.88c.39-.39 1.02-.39 1.41 0 .39.39.39 1.02 0 1.41l-4.59 4.59c-.39.39-1.02.39-1.41 0L6.7 10.7a.9959.9959 0 0 1 0-1.41c.39-.38 1.03-.39 1.42 0z"}),"KeyboardArrowDownRounded");TS=PS.default=RS;var zS={},$S=bh;Object.defineProperty(zS,"__esModule",{value:!0});var DS=zS.default=void 0,BS=$S(hb()),FS=Z,US=(0,BS.default)((0,FS.jsx)("path",{d:"M16.59 9H15V4c0-.55-.45-1-1-1h-4c-.55 0-1 .45-1 1v5H7.41c-.89 0-1.34 1.08-.71 1.71l4.59 4.59c.39.39 1.02.39 1.41 0l4.59-4.59c.63-.63.19-1.71-.7-1.71zM5 19c0 .55.45 1 1 1h12c.55 0 1-.45 1-1s-.45-1-1-1H6c-.55 0-1 .45-1 1z"}),"DownloadRounded");function WS({type:e,anime:t,title:n,callback:r,onDownload:o}){return Z.jsx(_S,{type:"button",title:n,onClick:n=>{switch(e){case"add":return r(n);case"mal":return setTimeout((()=>{window.open(`https://anilist.co/anime/${t.anilistID}`,"_blank")}));case"download":return o(n)}},children:function(){switch(e){case"add":return Z.jsx(TS,{style:{fontSize:"clamp(2rem, 2.5vw, 3.7rem)"}});case"mal":return Z.jsx("svg",{style:{width:"clamp(1.5rem, 2vw, 3rem)",height:"clamp(1.5rem, 2vw, 3rem)"},className:"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiBox-root css-uqopch",fill:"#ffffff",viewBox:"0 0 24 24",role:"img",xmlns:"http://www.w3.org/2000/svg",children:Z.jsx("path",{d:"M6.361 2.943 0 21.056h4.942l1.077-3.133H11.4l1.052 3.133H22.9c.71 0 1.1-.392 1.1-1.101V17.53c0-.71-.39-1.101-1.1-1.101h-6.483V4.045c0-.71-.392-1.102-1.101-1.102h-2.422c-.71 0-1.101.392-1.101 1.102v1.064l-.758-2.166zm2.324 5.948 1.688 5.018H7.144z"})});case"download":return Z.jsx(DS,{style:{fontSize:"clamp(2rem, 2.5vw, 3.7rem)"}})}}()})}DS=zS.default=US;const VS=dh.button`
  height: fit-content;
  display: inline-block;
  background: #efefef;
  color: #000;
  text-shadow: none;
  padding: min(1vw, 1.5rem) min(3vw, 4rem)${e=>e.fatBTN&&" !important"};

  @media (max-width: 2000px) {
    padding: min(1vw, 1.1rem) min(2.7vw, 4rem);
  }
  
  border-radius: .3rem;
  transition: opacity ease 200ms;

  &:hover {
    opacity: 0.7;
    text-decoration: none;
  }

  div {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  @media (max-width: 600px) {
    padding: min(1.5vw, 1.5rem) min(3vw, 4rem);
  }
`;var HS={},qS=bh;Object.defineProperty(HS,"__esModule",{value:!0});var YS=HS.default=void 0,JS=qS(hb()),GS=Z,QS=(0,JS.default)((0,GS.jsx)("path",{d:"M8 5v14l11-7z"}),"PlayArrow");function KS({anime:e,inmenu:t=!1}){var n;const[r,o]=W.useState(null);if(e.episodeNum>0){var i=JSON.parse(localStorage.getItem(`${e.anilistID}`));if(i){var a="Watch Episode 1";const c=(null==(n=null==i?void 0:i.episodes)?void 0:n.find((e=>i.episodeId===e.episodeId)))||null;var l=e.episodeNum>i.epNum&&(null==i?void 0:i.position)/(null==c?void 0:c.outof)>.8,s=i.episodeId.includes("-dub-");return a=!1===l?`${0!==i.position?"Continue":"Watch"} Episode ${i.epNum}`:`Watch Episode ${i.epNum+1}`,Z.jsxs(Z.Fragment,{children:[Z.jsx(VS,{fatBTN:t,title:a,onClick:()=>(sessionStorage.setItem("animeinfo",JSON.stringify({...e,lastpage:window.location.pathname,episode:{number:i.epNum,title:i.episodeName?i.episodeName:`Episode ${i.epNum}`}})),window.location.href=l?`/watch/${e.slug}${s?"-dub":""}-episode-${i.epNum+1}`:`/watch/${e.slug}${s?"-dub":""}-episode-${i.epNum}/${i.position}`),children:Z.jsxs("div",{style:{marginLeft:"-5%"},children:[Z.jsx(YS,{style:{fontSize:"clamp(1.5rem, 3vw, 3rem)",marginRight:".5vw"}}),Z.jsx("p",{style:{fontFamily:"NetflixSans-Md"},children:a})]})}),r&&Z.jsx(pj,{anime:r,onClose:e=>o(e??null)})]})}return Z.jsxs(Z.Fragment,{children:[Z.jsx(VS,{fatBTN:t,title:"Watch Episode 1",onClick:()=>{if(!t)return o(e);e.episodeNum>0&&(sessionStorage.setItem("animeinfo",JSON.stringify({...e,lastpage:window.location.pathname,episode:{number:1,title:"Episode 1"}})),window.history.replaceState({},"",window.location.pathname),window.history.pushState({},"",`${window.location.pathname}?anime=${e.slug}`),window.location.href=`/watch/${e.slug}-episode-1`)},children:Z.jsxs("div",{style:{marginLeft:"-5%"},children:[Z.jsx(YS,{style:{fontSize:"clamp(1.5rem, 3vw, 3rem)",marginRight:".5vw"}}),Z.jsx("p",{style:{fontFamily:"NetflixSans-Md"},children:"Watch Episode 1"})]})}),r&&Z.jsx(pj,{anime:r,onClose:e=>o(e??null)})]})}return Z.jsx(VS,{fatBTN:t,disabled:!0,to:"#",title:"Not Yet Available",children:Z.jsx("div",{children:Z.jsx("p",{style:{fontFamily:"NetflixSans-Md"},children:"Not Yet Available"})})})}YS=HS.default=QS;const XS=dh.button`
  position: absolute;
  top: 1vw;
  right: 1vw;
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  padding: .5rem;
  color: #fff;
  background: #181818;
`;var ZS={},ej=bh;Object.defineProperty(ZS,"__esModule",{value:!0});var tj=ZS.default=void 0,nj=ej(hb()),rj=Z,oj=(0,nj.default)((0,rj.jsx)("path",{d:"M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"}),"Close");function ij({onClick:e=(()=>{})}){return Z.jsx(XS,{type:"button",onClick:e,children:Z.jsx(tj,{style:{fontSize:"clamp(1.5rem, 2vw, 2.5rem)"}})})}tj=ZS.default=oj;const aj=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;

  ::-webkit-scrollbar { 
    display: none;  /* Safari and Chrome */
  }

  animation: ${Sb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}
`,lj=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);
`,sj=dh.div`
  width: clamp(35rem, 35vw, 55rem);
  line-height: 1.5;
  margin-top: 12vh;
  position: relative;
  border-radius: .5rem;
  background: #181818;
  animation: ${kb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}
`;dh.form`
  display: flex;
  flex-direction: column;
`,dh.p`
  color: #737373;
  text-align: center;
  font-size: 80%;
  font-weight: 500;
`,dh(Cp)`
  color: #fff;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`,dh.input`
  background: #333;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 3.5vh;
  line-height: 50px;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .1vh;
  &:last-of-type {
    margin-bottom: .2vh;
  }
`,dh.button`
  background: #e50914;
  border-radius: 4px;
  font-size: 85%;
  font-weight: bold;
  margin: 1vh;
  padding: 1vh;
  border: 0;
  color: white;
  cursor: pointer;
  &:disabled {
    opacity: 0.5;
  }
`;const cj=dh.div`
  display: flex;
  width: 100%;
  background-color: #202020;
  height: 2em;
  align-items: center;
  pointer-events: none;

  &:last-child {
    border-radius: .5rem;
  }

  ${e=>e.dark&&Xm`
    background-color: #181818;
  `}
`,uj=dh.div`
  margin-left: 5%;
  font-size: 80%;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  width: 70%;
`,dj=dh.button`
  margin-right: 3%;
  margin-left: 3%;
  pointer-events: auto;
  background-color: transparent;
  color: gray;
`;function fj({onClose:e,anime:t,openAnimation:n=!0}){const r=W.useRef(),[o,i]=W.useState(!1),[a,l]=W.useState(!1);var[s,c]=W.useState(null);async function u(e){var n=e.target.getAttribute("value"),r=await fetch(`https://api.animeflix.dev/getsource/${t.slug}-episode-${n}?dub=${a}`).then((e=>e.json()));if(hd.dismiss(),!(null==r?void 0:r.source))return hd.error("Couldn't find a download for that episode! Try again later.",{style:{background:"#333",color:"#fff"}});setTimeout((()=>{window.open(r.source,"_blank")}))}return W.useEffect((()=>{Ek.getEpisodes(t.slug,a).then((e=>{var t;c({episodes:e.episodes,amount:null==(t=e.episodes)?void 0:t.length})}))}),[a]),W.useEffect((()=>{const t=t=>{r.current.contains(t.target)||(i(!0),setTimeout((()=>{e(),i(!1)}),380))};return document.addEventListener("mousedown",t),()=>{document.removeEventListener("mousedown",t)}}),[]),W.useEffect((()=>(document.body.style.overflow="hidden",()=>document.body.style.overflow="auto")),[]),mu.createPortal(Z.jsx(aj,{id:"downloadzone",closing:o,children:Z.jsx(lj,{id:"downloadzone",children:Z.jsxs(sj,{ref:r,closing:o,id:"downloadzone",children:[Z.jsx("h3",{style:{marginTop:"1%",marginLeft:"5%",pointerEvents:"none",width:"fit-content",marginBottom:"2%"},children:"Download Menu"}),Z.jsxs("div",{id:"downloadzone",style:{display:"flex",position:"absolute",left:"77.9%",marginTop:"1.9%",top:0},children:[Z.jsx("p",{id:"downloadzone",style:{marginRight:"10%",color:a?"white":"#5A5A5A",cursor:"pointer"},onClick:()=>l(!0),children:"DUB"}),Z.jsx("p",{id:"downloadzone",style:{color:a?"#5A5A5A":"white",cursor:"pointer"},onClick:()=>l(!1),children:"SUB"})]}),(()=>{var e=!1;const t=[];for(var n in null==s?void 0:s.episodes){var r=s.episodes[n];t.push(Z.jsxs(cj,{dark:e,children:[Z.jsxs(uj,{children:[r.number,". ",r.title||"Episode"]}),Z.jsx(dj,{id:"downloadzone",value:r.number,onClick:e=>u(e),children:"Download"})]},n)),e=!e}return t})()]})})}),document.getElementById("modal-root"))}function pj({anime:e,onClose:t,openAnimation:n=!0}){var r,o,i,a;const l=W.useRef(),[s,c]=W.useState(!1),[u,d]=W.useState(!0),[f,p]=W.useState(),[m,h]=W.useState(),[g,v]=W.useState();var y=localStorage.getItem("token"),b=JSON.parse(localStorage.getItem("folders"))||["My List"];function w(){document.title="Animeflix - Watch HD anime for free!",c(!0),setTimeout((()=>{t(),document.body.style.overflowY="visible"}),380)}function x(t){var n=JSON.parse(localStorage.getItem(t)||"[]");return null==n?void 0:n.find((t=>Number(t)===Number(e.anilistID)))}return W.useEffect((()=>{const e=e=>{l.current.contains(e.target)||"downloadzone"===e.target.id||w()};return window.addEventListener("popstate",w),document.addEventListener("mousedown",e),()=>{document.body.style.overflowY="visible",window.removeEventListener("popstate",w),document.removeEventListener("mousedown",e)}}),[]),W.useEffect((()=>{var t;if(!window.location.search.includes("?anime="))return window.history.pushState({},"",`${window.location.pathname}?anime=${e.slug}`),document.title=null==(t=e.title)?void 0:t.userPreferred,()=>{window.history.replaceState({},"Main Page",window.location.pathname)}}),[]),("string"==typeof b||(null==b?void 0:b.length)<1)&&(b=["My List"]),document.body.style.overflowY="hidden",mu.createPortal(Z.jsxs(Ak,{id:"modalbackground",closing:s,opening:n,children:[Z.jsxs(_k,{id:"modalbackground",children:[Z.jsxs(Pk,{ref:l,closing:s,opening:n,children:[Z.jsxs(Ik,{background:e.bannerImage||(null==(r=e.images)?void 0:r.large),children:[Z.jsxs("div",{children:[Z.jsx("h2",{children:e.title.english||e.title.userPreferred||e.title.romaji}),e.title.native&&Z.jsxs("h3",{children:["(",e.title.native,")"]}),Z.jsxs(Tk,{children:[Z.jsx(KS,{anime:e,inmenu:!0}),Z.jsx(WS,{type:"add",anime:e,title:"Add to My List",callback:e=>{const t=document.getElementById("modalbackground");p(!f),h({x:e.clientX,y:e.clientY+t.scrollTop,target:e.target})}}),Z.jsx(WS,{type:"mal",anime:e,title:"View on Anilist"}),Z.jsx(WS,{type:"download",anime:e,title:"Download Episodes",onDownload:e=>{v(!0)}})]}),e.nextAiringEpisode&&(null==(o=e.nextAiringEpisode)?void 0:o.airingAt)&&Z.jsx(Nk,{title:e.nextAiringEpisode.delayed?e.nextAiringEpisode.delayedText:"",onClick:()=>window.location.href="/schedule",children:Ck.toAiringDate(e.nextAiringEpisode)})]}),Z.jsx(ij,{onClick:w})]}),f&&Z.jsx(Ok,{top:m.y,left:m.x,id:"foldbackground",onClick:e=>{"foldbackground"===e.target.id&&p(!f)},children:Z.jsx("ul",{children:b.map(((t,n)=>Z.jsxs("li",{style:{position:"relative"},onClick:()=>function(t){var n=JSON.parse(localStorage.getItem(t))||[];n.find((t=>Number(t)===Number(e.anilistID)))?(n=n.filter((t=>Number(t)!==Number(e.anilistID))),y&&Ek.set(y,`folders.${t}`,n)):(n.push(e.anilistID),y&&Ek.set(y,`folders.${t}`,n)),localStorage.setItem(t,JSON.stringify(n)),p(!1)}(t),children:[t," ",x(t)&&Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"1.1em",height:"auto",position:"absolute",right:"1rem",top:"20%"},children:Z.jsx("path",{d:"M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"})})]},n)))})}),Z.jsxs(Lk,{children:[Z.jsxs("div",{children:[Z.jsx("div",{id:"mal-sync"}),Z.jsxs(zk,{children:[e.averageScore&&Z.jsxs("strong",{children:[e.averageScore,"% Match"]}),(null==(i=null==e?void 0:e.startDate)?void 0:i.year)&&Z.jsxs("label",{children:[e.episodeNum>0?"":"Expected to air in ",e.startDate.year]}),e.episodeNum>0&&Z.jsxs("label",{children:[e.episodeNum,e.animeLength&&e.animeLength!==e.episodeNum?`/${e.animeLength}`:""," episodes"]}),e.duration&&Z.jsxs("label",{children:[e.duration," minutes"]})]}),Z.jsx(Mk,{children:Z.jsxs("p",{children:[e.description&&(u?Ck.trimParagraph(e.description.replace(/<\/?[^>]+(>|$)/g,""),295):e.description.replace(/<\/?[^>]+(>|$)/g,"")),e.description&&e.description.length>294&&Z.jsxs(Rk,{onClick:()=>d(!u),children:[" ",u?"Show More":"Show Less"]})]})})]}),(()=>{var t;if(e.episodeNum>0)return Z.jsx(gS,{anime:e,thumbnail:null==(t=e.images)?void 0:t.medium})})(),Z.jsxs("div",{style:{clear:"both"},children:[(null==(a=e.relatedAnime)?void 0:a.length)>0&&Z.jsx(AS,{anime:e,clickAnime:e=>{c(!0),setTimeout((()=>{var n;t(e),null==(n=document.getElementById("modalbackground"))||n.scroll({top:0,behavior:"instant"}),c(!1)}),300)}}),Z.jsxs("h3",{className:"separator",style:{whiteSpace:"nowrap",textOverflow:"ellipsis",overflow:"hidden"},children:["About ",e.title.english||e.title.userPreferred||e.title.romaji]}),Z.jsx(NS,{anime:e})]})]})]}),g&&Z.jsx(fj,{id:"downloadzone",anime:e,openAnimation:!1,onClose:()=>v(!1)})]}),Z.jsx("script",{id:"syncData",type:"application/json",children:JSON.stringify({page:"anime",slug:e.slug,anilistID:e.anilistID,malID:e.malID,name:e.title.romaji||e.title.userPreferred||e.title.english})})," "]}),document.getElementById("modal-root"))}function mj(){const e=W.useRef(),t=W.useRef(),n=yp(),[r,o]=W.useState(0),[i,a]=W.useState(),[l,s]=W.useState(),[c,u]=W.useState();return W.useEffect((()=>{function n(n){if(e.current.contains(n.target)&&!xk){var i=null;if("animeresult"===n.target.className?i=n.target.parentNode:"infocont"===n.target.className&&(i=n.target),!i)return;a(JSON.parse(decodeURIComponent(i.getAttribute("data"))))}else if(r&&"ignore"!==n.target.id){o(!1),t.current.value="",u(void 0),document.getElementById("placeholderdiv").outerHTML='<div id="placeholderdiv"/>'}}return document.addEventListener("mousedown",n),()=>document.removeEventListener("mousedown",n)})),W.useEffect((()=>{r&&t.current.focus()}),[r]),n.listen(((e,n)=>{const{pathname:i}=e;t.current===document.activeElement||i.match(/\/search\/.*/g)||r&&(o(!1),t.current.value="")})),W.useEffect((()=>{if(c){var e=document.getElementById("placeholderdiv"),t=c.map((e=>{var t,n,r,o,i;return`<a class="infocont" href="#" style="text-decoration: none;" data="${encodeURIComponent(JSON.stringify(e))}">\n      <div style="background-image: url(${(null==(t=e.images)?void 0:t.small)||(null==(n=e.images)?void 0:n.medium)});" class="smolimg">\n      </div>\n      <div class="animeresult" id="${e.anilistID}">\n        <h3 class="title">\n          ${(null==(r=e.title)?void 0:r.english)||(null==(o=e.title)?void 0:o.userPreferred)||e.title.romaji}\n        </h3>\n        <div class="genrecont">\n          ${e.genres.map((e=>`\n            <span class="genre">\n             ${e}\n            </span>`)).join("")}\n        </div>\n      </div>\n      <div class="datecont">\n        <span class="date">\n          ${(null==(i=e.startDate)?void 0:i.year)||""}\n        </span>\n      </div>\n    </a>`}));0===c.length?e.outerHTML='<div id="placeholderdiv"/>':e.outerHTML=`<div class="maincontainer" id="placeholderdiv">${null==t?void 0:t.join("")}</div>`}}),[c]),W.useEffect((()=>{if(window.location.pathname.startsWith("/search"))return;if(!l||xk)return;const e=setTimeout((async()=>{var e=await Ek.search(l,5);u(e)}),250);return()=>clearTimeout(e)}),[l]),Z.jsxs(Vb,{id:"searchcontainer",ref:e,show:r,children:[Z.jsx(Hb,{"aria-label":"Search",type:"button",disabled:r,onClick:function(){r||o(!0)},children:Z.jsx(Gb,{style:{fontSize:"clamp(2rem, 1.5vw, 3rem)"},id:"ignore"})}),Z.jsx("form",{onSubmit:function(e){e.preventDefault();const t=e.target[0].value;var r=new URLSearchParams(window.location.search);n.replace(t?`/search/${t}?${r.toString()}`:"/")},autocomplete:"off",style:{display:"flex",height:"90%"},children:Z.jsx(qb,{ref:t,show:r,disabled:!r,placeholder:"Search for media",onChange:e=>s(e.target.value),id:"ignore"})}),Z.jsx("div",{id:"placeholderdiv"}),i&&Z.jsx(pj,{anime:i,onClose:e=>{a(e??null),sessionStorage.removeItem("animeinfo")}})]})}const hj=dh.div`
  display: flex;
  cursor: pointer;
  margin-left: .7vw;

  @media (max-width: 600px) {
    float: right;
    margin-right: .5rem;
  }
`,gj=dh.div`
  width: 15rem;
  height: fit-content;
  position: absolute;
  right: 1vw;
  margin-top: .3vh;
  border-top: 5px solid #e50404;
  background: #1a1a1a;
  border-radius: 2px;
  ${e=>e.hide?"display: none;":""}

  @media (min-width: 600px) {
    transform: translateX(${e=>e.hide?"115%":"0"});
    transition: transform ease 200ms;
  }

  section {
    display: flex;
    flex-direction: column;
    padding: .5rem 1rem 1rem;
  }

  section + section {
    border-top: 1px solid #333;
  }

  a + a {
    margin-top: 1rem;
  }
`,vj=dh.div`
  color: #fff;
  width: max(2rem, 1.25vw);
  cursor: pointer;
  background: none;
  
  img {
    max-width: 100%;
    object-fit: cover;
    border-radius: .3rem;
  }

  .usericon1 {
    @media (max-width: 600px) {
      display: none;
    }
  }

  .usericon2 {
    @media (min-width: 600px) {
      display: none;
    }
  }
`,yj=dh.button`
  background: transparent;
  color: white;
  margin-top: .4rem;
  &:hover {
    color: rgba(205, 205, 205, 1);
  }

  @media (max-width: 600px) {
    &:not(:last-of-type) {
      margin-bottom: .5rem;
    }
  }
`,bj=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;
`,wj=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);
`,xj=dh.div`
  width: clamp(30rem, 25vw, 50rem);
  line-height: 1.5;
  margin-top: 5vh;
  position: relative;
  border-radius: .5rem;
  background: #181818;
  animation: ${kb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}
`,kj=dh.form`
  display: flex;
  flex-direction: column;
`,Sj=dh.p`
  color: #737373;
  text-align: center;
  font-size: 80%;
  font-weight: 500;
`;dh(Cp)`
  color: #fff;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`;const jj=dh.input`
  background: #333;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 3.5vh;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .1vh;
  &:last-of-type {
    margin-bottom: .2vh;
  }

  &:-webkit-autofill,
  &:-webkit-autofill:focus {
      transition: background-color 600000s 0s, color 600000s 0s;
  }
  &[data-autocompleted] {
      background-color: transparent !important;
  }
`,Ej=dh.button`
  background: #e50914;
  border-radius: 4px;
  font-size: 85%;
  font-weight: bold;
  margin: 1vh;
  padding: 1vh;
  border: 0;
  color: white;
  cursor: pointer;
  &:disabled {
    opacity: 0.5;
  }
`;function Cj({onClose:e,openRegister:t}){const n=W.useRef(),[r,o]=W.useState(""),[i,a]=W.useState(""),[l,s]=W.useState(),[c,u]=W.useState(!1),[d,f]=W.useState();W.useEffect((()=>{const e=e=>{n.current.contains(e.target)||p()};return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]),W.useEffect((()=>{const e=document.createElement("script");return e.src="https://www.google.com/recaptcha/api.js?render=6Lef1SkpAAAAAAlqdH1vB-worvNKh2kh-eFohWM8",e.addEventListener("load",(e=>{window.grecaptcha.ready((e=>{window.grecaptcha.execute("6Lef1SkpAAAAAAlqdH1vB-worvNKh2kh-eFohWM8",{action:"login"}).then((e=>{f(e)}))}))})),document.body.appendChild(e),document.body.style.overflow="hidden",()=>{document.body.removeChild(e),document.body.style.overflow="auto"}}),[]);function p(){u(!0),setTimeout((()=>{e(),u(!1)}),380)}return l&&(s(void 0),hd(l,{duration:2e3,style:{minWidth:"26vw",color:"white",background:"#E87C03"}})),mu.createPortal(Z.jsx(bj,{children:Z.jsx(wj,{children:Z.jsxs(xj,{ref:n,closing:c,children:[Z.jsxs(kj,{onSubmit:async e=>{var t;e.preventDefault(),document.getElementById("submitbutton").disabled=!0;var n=await Ek.authUser(r,i,d);n.error?(document.getElementById("submitbutton").disabled=!1,o(""),a(""),s(n.message)):(localStorage.setItem("token",null==(t=null==n?void 0:n.user)?void 0:t.token),p(),hd.success("You have successfully signed in to Animeflix",{style:{background:"#333",color:"#fff"}}),window.dispatchEvent(new CustomEvent("updateData",{detail:null==n?void 0:n.user})))},method:"POST",children:[Z.jsx(jj,{placeholder:"Email/Username",value:r,onChange:({target:e})=>o(e.value)}),Z.jsx(jj,{type:"password",value:i,autoComplete:"off",placeholder:"Password",onChange:({target:e})=>a(e.value)}),Z.jsx(Ej,{disabled:""===i||""===r,type:"submit","data-testid":"sign-in",id:"submitbutton",children:"Sign In"})]}),Z.jsxs(Sj,{children:["Trying to log in? ",Z.jsx("a",{style:{cursor:"pointer"},onClick:()=>{e(),t()},children:"Sign up"})," or ",Z.jsx("a",{style:{cursor:"pointer"},onClick:()=>""===r?hd("Please input your email to the field!",{duration:2500,style:{minWidth:"26vw",color:"white",background:"#E87C03"}}):Ek.sendPasswordReset(r).then((e=>{if(e.error)return hd("No account with that email address!",{duration:2500,style:{color:"white",background:"#E87C03"}});hd.success("Password reset email sent!",{style:{background:"#333",color:"#fff"}})})),children:"Reset your password"})]})]})})}),document.getElementById("modal-root"))}const Aj=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;
`,Oj=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);
`,Nj=dh.div`
  width: clamp(30rem, 25vw, 50rem);
  line-height: 1.5;
  margin-top: 5vh;
  position: relative;
  border-radius: .5rem;
  background: #181818;
  animation: ${kb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}
`;dh.div`
  background: #e87c03;
  border-radius: 4px;
  font-size: 14px;
  margin: 0 0 16px;
  color: white;
  padding: 15px 20px;
`;const _j=dh.form`
  display: flex;
  flex-direction: column;
`;dh.h1`
  color: #fff;
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 28px;
`,dh.p`
  color: #737373;
  text-align: center;
  font-size: 16px;
  font-weight: 500;
`,dh.p`
  margin-top: 10px;
  font-size: 13px;
  line-height: normal;
  color: #8c8c8c;
`,dh(Cp)`
  color: #fff;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`;const Pj=dh.input`
  background: #333;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 3.5vh;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .1vh;
  &:last-of-type {
    margin-bottom: .2vh;
  }
`,Ij=dh.button`
  background: #e50914;
  border-radius: 4px;
  font-size: 16px;
  font-weight: bold;
  margin: 1vh;
  padding: 1vh;
  border: 0;
  color: white;
  cursor: pointer;
  &:disabled {
    opacity: 0.5;
  }
`;function Tj({onClose:e}){const t=W.useRef(),[n,r]=W.useState(""),[o,i]=W.useState(""),[a,l]=W.useState(""),[s,c]=W.useState(),[u,d]=W.useState(!1),[f,p]=W.useState();function m(){d(!0),setTimeout((()=>{e(),d(!1)}),380)}W.useEffect((()=>{const e=e=>{t.current.contains(e.target)||m()};return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]),W.useEffect((()=>{const e=document.createElement("script");return e.src="https://www.google.com/recaptcha/api.js?render=6Lef1SkpAAAAAAlqdH1vB-worvNKh2kh-eFohWM8",e.addEventListener("load",(e=>{window.grecaptcha.ready((e=>{window.grecaptcha.execute("6Lef1SkpAAAAAAlqdH1vB-worvNKh2kh-eFohWM8",{action:"register"}).then((e=>{p(e)}))}))})),document.body.appendChild(e),document.body.style.overflow="hidden",()=>{document.body.removeChild(e),document.body.style.overflow="auto"}}),[]);return s&&(c(void 0),hd(s,{duration:2500,style:{minWidth:"26vw",color:"white",background:"#E87C03"}})),mu.createPortal(Z.jsx(Aj,{children:Z.jsx(Oj,{children:Z.jsx(Nj,{ref:t,closing:u,children:Z.jsxs(_j,{onSubmit:async e=>{var t,l;e.preventDefault();var s=await Ek.registerUser(n,a,o,f);if(s.error)r(""),i(""),c(s.message);else{m(),hd.success("You have successfully signed up to Animeflix",{style:{background:"#333",color:"#fff"}}),localStorage.setItem("token",null==(t=null==s?void 0:s.user)?void 0:t.token);var u=localStorage.getItem("folders"),d=(null==u?void 0:u.length)>1?JSON.parse(u):["My List"],p={username:a,profile_picture:"https://i.imgur.com/vpVqdqe.png",recentlywatched:JSON.parse(localStorage.getItem("recentlywatched"))||[],folder_names:d,folders:{}};for(var h of d){var g=JSON.parse(localStorage.getItem(h));g&&(p.folders[h]=g)}Ek.set(null==(l=null==s?void 0:s.user)?void 0:l.token,"*",p)}},method:"POST",children:[Z.jsx(Pj,{placeholder:"Username",value:a,onChange:({target:e})=>l(e.value)}),Z.jsx(Pj,{type:"email",placeholder:"Email address",value:n,onChange:({target:e})=>r(e.value)}),Z.jsx(Pj,{type:"password",value:o,autoComplete:"off",placeholder:"Password",onChange:({target:e})=>i(e.value)}),Z.jsx(Ij,{disabled:""===o||""===n||""===a,type:"submit","data-testid":"sign-in",children:"Sign Up"})]})})})}),document.getElementById("modal-root"))}var Lj={},Mj=bh;Object.defineProperty(Lj,"__esModule",{value:!0});var Rj=Lj.default=void 0,zj=Mj(hb()),$j=Z,Dj=(0,zj.default)((0,$j.jsx)("path",{d:"m7 10 5 5 5-5z"}),"ArrowDropDown");Rj=Lj.default=Dj;var Bj={},Fj=bh;Object.defineProperty(Bj,"__esModule",{value:!0});var Uj=Bj.default=void 0,Wj=Fj(hb()),Vj=Z,Hj=(0,Wj.default)((0,Vj.jsx)("path",{d:"m7 14 5-5 5 5z"}),"ArrowDropUp");Uj=Bj.default=Hj;var qj={},Yj=bh;Object.defineProperty(qj,"__esModule",{value:!0});var Jj=qj.default=void 0,Gj=Yj(hb()),Qj=Z,Kj=(0,Gj.default)((0,Qj.jsx)("path",{d:"M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"}),"Settings");Jj=qj.default=Kj;const Xj=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;

  animation: ${Sb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}
`,Zj=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);
`,eE=dh.div`
  width: clamp(50rem, 55vw, 70rem);
  line-height: 1.5;
  margin-top: 5vh;
  position: relative;
  border-radius: .5rem;
  background: #181818;
  animation: ${kb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}
`,tE=dh.form`
  display: flex;
  flex-direction: column;
`;dh.p`
  color: #737373;
  text-align: center;
  font-size: 80%;
  font-weight: 500;
`,dh(Cp)`
  color: #fff;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`;const nE=dh.input`
  background: #333;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 4.5vh;
  line-height: 50px;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .1vh;
  &:last-of-type {
    margin-bottom: .2vh;
  }
`,rE=dh.textarea`
  background: #333;
  border-radius: 4px;
  resize: vertical;
  border: 0;
  color: #fff;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .1vh;
  &:last-of-type {
    margin-bottom: .2vh;
  }
`,oE=dh.button`
  background: #e50914;
  border-radius: 4px;
  font-size: 85%;
  font-weight: bold;
  margin: 1vh;
  padding: 1vh;
  border: 0;
  color: white;
  cursor: pointer;
  &:disabled {
    opacity: 0.5;
  }
`;function iE({onClose:e}){const t=W.useRef(),[n,r]=W.useState(!1),[o,i]=W.useState();W.useEffect((()=>{const e=e=>{t.current.contains(e.target)||a()};return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]);function a(){r(!0),setTimeout((()=>{e(),r(!1)}),380)}return W.useEffect((()=>{const e=document.createElement("script");return e.src="https://www.google.com/recaptcha/api.js?render=6Lef1SkpAAAAAAlqdH1vB-worvNKh2kh-eFohWM8",e.addEventListener("load",(e=>{window.grecaptcha.ready((e=>{window.grecaptcha.execute("6Lef1SkpAAAAAAlqdH1vB-worvNKh2kh-eFohWM8",{action:"contact"}).then((e=>{i(e)}))}))})),document.body.appendChild(e),()=>{document.body.removeChild(e)}}),[]),mu.createPortal(Z.jsx(Xj,{closing:n,children:Z.jsx(Zj,{children:Z.jsxs(eE,{ref:t,closing:n,children:[window.innerWidth<=600&&Z.jsx(ij,{onClick:a}),Z.jsxs(tE,{onSubmit:e=>{e.preventDefault(),a();var t=document.getElementById("issuemail").value,n=document.getElementById("issuearea").value;n.length<10||fetch(`https://api.animeflix.dev/report?email=${encodeURIComponent(t)}&text=${encodeURIComponent(n)}&token=${o}`).then((()=>{hd.success("Thank you for contacting us!",{style:{background:"#333",color:"#fff"}})}))},children:[Z.jsx("h3",{style:{marginTop:"1%",textAlign:"center",pointerEvents:"none"},children:"Contact Us"}),Z.jsx(nE,{type:"email",placeholder:"Email address",id:"issuemail"}),Z.jsx(rE,{rows:8,autoComplete:"off",placeholder:"Please describe your issue in detail",id:"issuearea"}),Z.jsx(oE,{type:"submit","data-testid":"sign-in",children:"Send Message"})]})]})})}),document.getElementById("modal-root"))}const aE=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow-y: auto;
  animation: ${Sb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}

  @media (min-width: 950px) and (min-height: 820px){ 
    transform: scale(1.4);
  }
`,lE=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);

  @media (min-width: 600px) {
    margin-top: 15vh;
  }
`,sE=dh.div`
  line-height: 1.5;
  min-width: 30vw;
  position: relative;
  border-radius: .5rem;
`;dh.div`
  background: #e87c03;
  border-radius: 4px;
  font-size: 14px;
  margin: 0 0 16px;
  color: white;
  padding: 15px 20px;
`,dh.h1`
  color: #fff;
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 28px;
`,dh.p`
  color: #737373;
  text-align: center;
  font-size: 16px;
  font-weight: 500;
`,dh.p`
  margin-top: 10px;
  font-size: 13px;
  line-height: normal;
  color: #8c8c8c;
`,dh(Cp)`
  color: #fff;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`;var cE={exports:{}},uE=function(e,t){return function(){for(var n=new Array(arguments.length),r=0;r<n.length;r++)n[r]=arguments[r];return e.apply(t,n)}},dE=uE,fE=Object.prototype.toString;function pE(e){return"[object Array]"===fE.call(e)}function mE(e){return void 0===e}function hE(e){return null!==e&&"object"==typeof e}function gE(e){if("[object Object]"!==fE.call(e))return!1;var t=Object.getPrototypeOf(e);return null===t||t===Object.prototype}function vE(e){return"[object Function]"===fE.call(e)}function yE(e,t){if(null!=e)if("object"!=typeof e&&(e=[e]),pE(e))for(var n=0,r=e.length;n<r;n++)t.call(null,e[n],n,e);else for(var o in e)Object.prototype.hasOwnProperty.call(e,o)&&t.call(null,e[o],o,e)}var bE={isArray:pE,isArrayBuffer:function(e){return"[object ArrayBuffer]"===fE.call(e)},isBuffer:function(e){return null!==e&&!mE(e)&&null!==e.constructor&&!mE(e.constructor)&&"function"==typeof e.constructor.isBuffer&&e.constructor.isBuffer(e)},isFormData:function(e){return"undefined"!=typeof FormData&&e instanceof FormData},isArrayBufferView:function(e){return"undefined"!=typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(e):e&&e.buffer&&e.buffer instanceof ArrayBuffer},isString:function(e){return"string"==typeof e},isNumber:function(e){return"number"==typeof e},isObject:hE,isPlainObject:gE,isUndefined:mE,isDate:function(e){return"[object Date]"===fE.call(e)},isFile:function(e){return"[object File]"===fE.call(e)},isBlob:function(e){return"[object Blob]"===fE.call(e)},isFunction:vE,isStream:function(e){return hE(e)&&vE(e.pipe)},isURLSearchParams:function(e){return"undefined"!=typeof URLSearchParams&&e instanceof URLSearchParams},isStandardBrowserEnv:function(){return("undefined"==typeof navigator||"ReactNative"!==navigator.product&&"NativeScript"!==navigator.product&&"NS"!==navigator.product)&&("undefined"!=typeof window&&"undefined"!=typeof document)},forEach:yE,merge:function e(){var t={};function n(n,r){gE(t[r])&&gE(n)?t[r]=e(t[r],n):gE(n)?t[r]=e({},n):pE(n)?t[r]=n.slice():t[r]=n}for(var r=0,o=arguments.length;r<o;r++)yE(arguments[r],n);return t},extend:function(e,t,n){return yE(t,(function(t,r){e[r]=n&&"function"==typeof t?dE(t,n):t})),e},trim:function(e){return e.trim?e.trim():e.replace(/^\s+|\s+$/g,"")},stripBOM:function(e){return 65279===e.charCodeAt(0)&&(e=e.slice(1)),e}},wE=bE;function xE(e){return encodeURIComponent(e).replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}var kE=function(e,t,n){if(!t)return e;var r;if(n)r=n(t);else if(wE.isURLSearchParams(t))r=t.toString();else{var o=[];wE.forEach(t,(function(e,t){null!=e&&(wE.isArray(e)?t+="[]":e=[e],wE.forEach(e,(function(e){wE.isDate(e)?e=e.toISOString():wE.isObject(e)&&(e=JSON.stringify(e)),o.push(xE(t)+"="+xE(e))})))})),r=o.join("&")}if(r){var i=e.indexOf("#");-1!==i&&(e=e.slice(0,i)),e+=(-1===e.indexOf("?")?"?":"&")+r}return e},SE=bE;function jE(){this.handlers=[]}jE.prototype.use=function(e,t,n){return this.handlers.push({fulfilled:e,rejected:t,synchronous:!!n&&n.synchronous,runWhen:n?n.runWhen:null}),this.handlers.length-1},jE.prototype.eject=function(e){this.handlers[e]&&(this.handlers[e]=null)},jE.prototype.forEach=function(e){SE.forEach(this.handlers,(function(t){null!==t&&e(t)}))};var EE,CE,AE,OE,NE,_E,PE,IE,TE,LE,ME,RE,zE,$E,DE,BE,FE,UE,WE=jE,VE=bE,HE=function(e,t,n,r,o){return e.config=t,n&&(e.code=n),e.request=r,e.response=o,e.isAxiosError=!0,e.toJSON=function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:this.config,code:this.code}},e};function qE(){if(CE)return EE;CE=1;var e=HE;return EE=function(t,n,r,o,i){var a=new Error(t);return e(a,n,r,o,i)}}function YE(){if(RE)return ME;RE=1;var e=IE?PE:(IE=1,PE=function(e){return/^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e)}),t=LE?TE:(LE=1,TE=function(e,t){return t?e.replace(/\/+$/,"")+"/"+t.replace(/^\/+/,""):e});return ME=function(n,r){return n&&!e(r)?t(n,r):r}}function JE(){if(UE)return FE;UE=1;var e=bE,t=function(){if(OE)return AE;OE=1;var e=qE();return AE=function(t,n,r){var o=r.config.validateStatus;r.status&&o&&!o(r.status)?n(e("Request failed with status code "+r.status,r.config,null,r.request,r)):t(r)}}(),n=function(){if(_E)return NE;_E=1;var e=bE;return NE=e.isStandardBrowserEnv()?function(){return{write:function(t,n,r,o,i,a){var l=[];l.push(t+"="+encodeURIComponent(n)),e.isNumber(r)&&l.push("expires="+new Date(r).toGMTString()),e.isString(o)&&l.push("path="+o),e.isString(i)&&l.push("domain="+i),!0===a&&l.push("secure"),document.cookie=l.join("; ")},read:function(e){var t=document.cookie.match(new RegExp("(^|;\\s*)("+e+")=([^;]*)"));return t?decodeURIComponent(t[3]):null},remove:function(e){this.write(e,"",Date.now()-864e5)}}}():function(){return{write:function(){},read:function(){return null},remove:function(){}}}()}(),r=kE,o=YE(),i=function(){if($E)return zE;$E=1;var e=bE,t=["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"];return zE=function(n){var r,o,i,a={};return n?(e.forEach(n.split("\n"),(function(n){if(i=n.indexOf(":"),r=e.trim(n.substr(0,i)).toLowerCase(),o=e.trim(n.substr(i+1)),r){if(a[r]&&t.indexOf(r)>=0)return;a[r]="set-cookie"===r?(a[r]?a[r]:[]).concat([o]):a[r]?a[r]+", "+o:o}})),a):a}}(),a=function(){if(BE)return DE;BE=1;var e=bE;return DE=e.isStandardBrowserEnv()?function(){var t,n=/(msie|trident)/i.test(navigator.userAgent),r=document.createElement("a");function o(e){var t=e;return n&&(r.setAttribute("href",t),t=r.href),r.setAttribute("href",t),{href:r.href,protocol:r.protocol?r.protocol.replace(/:$/,""):"",host:r.host,search:r.search?r.search.replace(/^\?/,""):"",hash:r.hash?r.hash.replace(/^#/,""):"",hostname:r.hostname,port:r.port,pathname:"/"===r.pathname.charAt(0)?r.pathname:"/"+r.pathname}}return t=o(window.location.href),function(n){var r=e.isString(n)?o(n):n;return r.protocol===t.protocol&&r.host===t.host}}():function(){return function(){return!0}}()}(),l=qE();return FE=function(s){return new Promise((function(c,u){var d=s.data,f=s.headers,p=s.responseType;e.isFormData(d)&&delete f["Content-Type"];var m=new XMLHttpRequest;if(s.auth){var h=s.auth.username||"",g=s.auth.password?unescape(encodeURIComponent(s.auth.password)):"";f.Authorization="Basic "+btoa(h+":"+g)}var v=o(s.baseURL,s.url);function y(){if(m){var e="getAllResponseHeaders"in m?i(m.getAllResponseHeaders()):null,n={data:p&&"text"!==p&&"json"!==p?m.response:m.responseText,status:m.status,statusText:m.statusText,headers:e,config:s,request:m};t(c,u,n),m=null}}if(m.open(s.method.toUpperCase(),r(v,s.params,s.paramsSerializer),!0),m.timeout=s.timeout,"onloadend"in m?m.onloadend=y:m.onreadystatechange=function(){m&&4===m.readyState&&(0!==m.status||m.responseURL&&0===m.responseURL.indexOf("file:"))&&setTimeout(y)},m.onabort=function(){m&&(u(l("Request aborted",s,"ECONNABORTED",m)),m=null)},m.onerror=function(){u(l("Network Error",s,null,m)),m=null},m.ontimeout=function(){var e="timeout of "+s.timeout+"ms exceeded";s.timeoutErrorMessage&&(e=s.timeoutErrorMessage),u(l(e,s,s.transitional&&s.transitional.clarifyTimeoutError?"ETIMEDOUT":"ECONNABORTED",m)),m=null},e.isStandardBrowserEnv()){var b=(s.withCredentials||a(v))&&s.xsrfCookieName?n.read(s.xsrfCookieName):void 0;b&&(f[s.xsrfHeaderName]=b)}"setRequestHeader"in m&&e.forEach(f,(function(e,t){void 0===d&&"content-type"===t.toLowerCase()?delete f[t]:m.setRequestHeader(t,e)})),e.isUndefined(s.withCredentials)||(m.withCredentials=!!s.withCredentials),p&&"json"!==p&&(m.responseType=s.responseType),"function"==typeof s.onDownloadProgress&&m.addEventListener("progress",s.onDownloadProgress),"function"==typeof s.onUploadProgress&&m.upload&&m.upload.addEventListener("progress",s.onUploadProgress),s.cancelToken&&s.cancelToken.promise.then((function(e){m&&(m.abort(),u(e),m=null)})),d||(d=null),m.send(d)}))}}var GE=bE,QE=function(e,t){VE.forEach(e,(function(n,r){r!==t&&r.toUpperCase()===t.toUpperCase()&&(e[t]=n,delete e[r])}))},KE=HE,XE={"Content-Type":"application/x-www-form-urlencoded"};function ZE(e,t){!GE.isUndefined(e)&&GE.isUndefined(e["Content-Type"])&&(e["Content-Type"]=t)}var eC,tC={transitional:{silentJSONParsing:!0,forcedJSONParsing:!0,clarifyTimeoutError:!1},adapter:(("undefined"!=typeof XMLHttpRequest||"undefined"!=typeof process&&"[object process]"===Object.prototype.toString.call(process))&&(eC=JE()),eC),transformRequest:[function(e,t){return QE(t,"Accept"),QE(t,"Content-Type"),GE.isFormData(e)||GE.isArrayBuffer(e)||GE.isBuffer(e)||GE.isStream(e)||GE.isFile(e)||GE.isBlob(e)?e:GE.isArrayBufferView(e)?e.buffer:GE.isURLSearchParams(e)?(ZE(t,"application/x-www-form-urlencoded;charset=utf-8"),e.toString()):GE.isObject(e)||t&&"application/json"===t["Content-Type"]?(ZE(t,"application/json"),function(e,t,n){if(GE.isString(e))try{return(t||JSON.parse)(e),GE.trim(e)}catch(Wu){if("SyntaxError"!==Wu.name)throw Wu}return(n||JSON.stringify)(e)}(e)):e}],transformResponse:[function(e){var t=this.transitional,n=t&&t.silentJSONParsing,r=t&&t.forcedJSONParsing,o=!n&&"json"===this.responseType;if(o||r&&GE.isString(e)&&e.length)try{return JSON.parse(e)}catch(Wu){if(o){if("SyntaxError"===Wu.name)throw KE(Wu,this,"E_JSON_PARSE");throw Wu}}return e}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,maxBodyLength:-1,validateStatus:function(e){return e>=200&&e<300}};tC.headers={common:{Accept:"application/json, text/plain, */*"}},GE.forEach(["delete","get","head"],(function(e){tC.headers[e]={}})),GE.forEach(["post","put","patch"],(function(e){tC.headers[e]=GE.merge(XE)}));var nC,rC,oC=tC,iC=bE,aC=oC;function lC(){return rC?nC:(rC=1,nC=function(e){return!(!e||!e.__CANCEL__)})}var sC=bE,cC=function(e,t,n){var r=this||aC;return iC.forEach(n,(function(n){e=n.call(r,e,t)})),e},uC=lC(),dC=oC;function fC(e){e.cancelToken&&e.cancelToken.throwIfRequested()}var pC=bE,mC=function(e,t){t=t||{};var n={},r=["url","method","data"],o=["headers","auth","proxy","params"],i=["baseURL","transformRequest","transformResponse","paramsSerializer","timeout","timeoutMessage","withCredentials","adapter","responseType","xsrfCookieName","xsrfHeaderName","onUploadProgress","onDownloadProgress","decompress","maxContentLength","maxBodyLength","maxRedirects","transport","httpAgent","httpsAgent","cancelToken","socketPath","responseEncoding"],a=["validateStatus"];function l(e,t){return pC.isPlainObject(e)&&pC.isPlainObject(t)?pC.merge(e,t):pC.isPlainObject(t)?pC.merge({},t):pC.isArray(t)?t.slice():t}function s(r){pC.isUndefined(t[r])?pC.isUndefined(e[r])||(n[r]=l(void 0,e[r])):n[r]=l(e[r],t[r])}pC.forEach(r,(function(e){pC.isUndefined(t[e])||(n[e]=l(void 0,t[e]))})),pC.forEach(o,s),pC.forEach(i,(function(r){pC.isUndefined(t[r])?pC.isUndefined(e[r])||(n[r]=l(void 0,e[r])):n[r]=l(void 0,t[r])})),pC.forEach(a,(function(r){r in t?n[r]=l(e[r],t[r]):r in e&&(n[r]=l(void 0,e[r]))}));var c=r.concat(o).concat(i).concat(a),u=Object.keys(e).concat(Object.keys(t)).filter((function(e){return-1===c.indexOf(e)}));return pC.forEach(u,s),n};var hC={name:"axios",version:"0.21.4",description:"Promise based HTTP client for the browser and node.js",main:"index.js",scripts:{test:"grunt test",start:"node ./sandbox/server.js",build:"NODE_ENV=production grunt build",preversion:"npm test",version:"npm run build && grunt version && git add -A dist && git add CHANGELOG.md bower.json package.json",postversion:"git push && git push --tags",examples:"node ./examples/server.js",coveralls:"cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js",fix:"eslint --fix lib/**/*.js"},repository:{type:"git",url:"https://github.com/axios/axios.git"},keywords:["xhr","http","ajax","promise","node"],author:"Matt Zabriskie",license:"MIT",bugs:{url:"https://github.com/axios/axios/issues"},homepage:"https://axios-http.com",devDependencies:{coveralls:"^3.0.0","es6-promise":"^4.2.4",grunt:"^1.3.0","grunt-banner":"^0.6.0","grunt-cli":"^1.2.0","grunt-contrib-clean":"^1.1.0","grunt-contrib-watch":"^1.0.0","grunt-eslint":"^23.0.0","grunt-karma":"^4.0.0","grunt-mocha-test":"^0.13.3","grunt-ts":"^6.0.0-beta.19","grunt-webpack":"^4.0.2","istanbul-instrumenter-loader":"^1.0.0","jasmine-core":"^2.4.1",karma:"^6.3.2","karma-chrome-launcher":"^3.1.0","karma-firefox-launcher":"^2.1.0","karma-jasmine":"^1.1.1","karma-jasmine-ajax":"^0.1.13","karma-safari-launcher":"^1.0.0","karma-sauce-launcher":"^4.3.6","karma-sinon":"^1.0.5","karma-sourcemap-loader":"^0.3.8","karma-webpack":"^4.0.2","load-grunt-tasks":"^3.5.2",minimist:"^1.2.0",mocha:"^8.2.1",sinon:"^4.5.0","terser-webpack-plugin":"^4.2.3",typescript:"^4.0.5","url-search-params":"^0.10.0",webpack:"^4.44.2","webpack-dev-server":"^3.11.0"},browser:{"./lib/adapters/http.js":"./lib/adapters/xhr.js"},jsdelivr:"dist/axios.min.js",unpkg:"dist/axios.min.js",typings:"./index.d.ts",dependencies:{"follow-redirects":"^1.14.0"},bundlesize:[{path:"./dist/axios.min.js",threshold:"5kB"}]},gC={};["object","boolean","number","function","string","symbol"].forEach((function(e,t){gC[e]=function(n){return typeof n===e||"a"+(t<1?"n ":" ")+e}}));var vC={},yC=hC.version.split(".");function bC(e,t){for(var n=t?t.split("."):yC,r=e.split("."),o=0;o<3;o++){if(n[o]>r[o])return!0;if(n[o]<r[o])return!1}return!1}gC.transitional=function(e,t,n){var r=t&&bC(t);function o(e,t){return"[Axios v"+hC.version+"] Transitional option '"+e+"'"+t+(n?". "+n:"")}return function(n,i,a){if(!1===e)throw new Error(o(i," has been removed in "+t));return r&&!vC[i]&&(vC[i]=!0,console.warn(o(i," has been deprecated since v"+t+" and will be removed in the near future"))),!e||e(n,i,a)}};var wC,xC,kC,SC,jC,EC,CC,AC,OC=bE,NC=kE,_C=WE,PC=function(e){return fC(e),e.headers=e.headers||{},e.data=cC.call(e,e.data,e.headers,e.transformRequest),e.headers=sC.merge(e.headers.common||{},e.headers[e.method]||{},e.headers),sC.forEach(["delete","get","head","post","put","patch","common"],(function(t){delete e.headers[t]})),(e.adapter||dC.adapter)(e).then((function(t){return fC(e),t.data=cC.call(e,t.data,t.headers,e.transformResponse),t}),(function(t){return uC(t)||(fC(e),t&&t.response&&(t.response.data=cC.call(e,t.response.data,t.response.headers,e.transformResponse))),Promise.reject(t)}))},IC=mC,TC={isOlderVersion:bC,assertOptions:function(e,t,n){if("object"!=typeof e)throw new TypeError("options must be an object");for(var r=Object.keys(e),o=r.length;o-- >0;){var i=r[o],a=t[i];if(a){var l=e[i],s=void 0===l||a(l,i,e);if(!0!==s)throw new TypeError("option "+i+" must be "+s)}else if(!0!==n)throw Error("Unknown option "+i)}},validators:gC},LC=TC.validators;function MC(e){this.defaults=e,this.interceptors={request:new _C,response:new _C}}function RC(){if(xC)return wC;function e(e){this.message=e}return xC=1,e.prototype.toString=function(){return"Cancel"+(this.message?": "+this.message:"")},e.prototype.__CANCEL__=!0,wC=e}MC.prototype.request=function(e){"string"==typeof e?(e=arguments[1]||{}).url=arguments[0]:e=e||{},(e=IC(this.defaults,e)).method?e.method=e.method.toLowerCase():this.defaults.method?e.method=this.defaults.method.toLowerCase():e.method="get";var t=e.transitional;void 0!==t&&TC.assertOptions(t,{silentJSONParsing:LC.transitional(LC.boolean,"1.0.0"),forcedJSONParsing:LC.transitional(LC.boolean,"1.0.0"),clarifyTimeoutError:LC.transitional(LC.boolean,"1.0.0")},!1);var n=[],r=!0;this.interceptors.request.forEach((function(t){"function"==typeof t.runWhen&&!1===t.runWhen(e)||(r=r&&t.synchronous,n.unshift(t.fulfilled,t.rejected))}));var o,i=[];if(this.interceptors.response.forEach((function(e){i.push(e.fulfilled,e.rejected)})),!r){var a=[PC,void 0];for(Array.prototype.unshift.apply(a,n),a=a.concat(i),o=Promise.resolve(e);a.length;)o=o.then(a.shift(),a.shift());return o}for(var l=e;n.length;){var s=n.shift(),c=n.shift();try{l=s(l)}catch(u){c(u);break}}try{o=PC(l)}catch(u){return Promise.reject(u)}for(;i.length;)o=o.then(i.shift(),i.shift());return o},MC.prototype.getUri=function(e){return e=IC(this.defaults,e),NC(e.url,e.params,e.paramsSerializer).replace(/^\?/,"")},OC.forEach(["delete","get","head","options"],(function(e){MC.prototype[e]=function(t,n){return this.request(IC(n||{},{method:e,url:t,data:(n||{}).data}))}})),OC.forEach(["post","put","patch"],(function(e){MC.prototype[e]=function(t,n,r){return this.request(IC(r||{},{method:e,url:t,data:n}))}}));var zC=bE,$C=uE,DC=MC,BC=mC;function FC(e){var t=new DC(e),n=$C(DC.prototype.request,t);return zC.extend(n,DC.prototype,t),zC.extend(n,t),n}var UC=FC(oC);UC.Axios=DC,UC.create=function(e){return FC(BC(UC.defaults,e))},UC.Cancel=RC(),UC.CancelToken=function(){if(SC)return kC;SC=1;var e=RC();function t(t){if("function"!=typeof t)throw new TypeError("executor must be a function.");var n;this.promise=new Promise((function(e){n=e}));var r=this;t((function(t){r.reason||(r.reason=new e(t),n(r.reason))}))}return t.prototype.throwIfRequested=function(){if(this.reason)throw this.reason},t.source=function(){var e;return{token:new t((function(t){e=t})),cancel:e}},kC=t}(),UC.isCancel=lC(),UC.all=function(e){return Promise.all(e)},UC.spread=EC?jC:(EC=1,jC=function(e){return function(t){return e.apply(null,t)}}),UC.isAxiosError=AC?CC:(AC=1,CC=function(e){return"object"==typeof e&&!0===e.isAxiosError}),cE.exports=UC,cE.exports.default=UC;const WC=n(cE.exports);var VC={},HC=bh;Object.defineProperty(VC,"__esModule",{value:!0});var qC=VC.default=void 0,YC=HC(hb()),JC=Z,GC=(0,YC.default)((0,JC.jsx)("path",{d:"M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"}),"Person");qC=VC.default=GC;var QC={},KC=bh;Object.defineProperty(QC,"__esModule",{value:!0});var XC=QC.default=void 0,ZC=KC(hb()),eA=Z,tA=(0,ZC.default)((0,eA.jsx)("path",{d:"M5 20h14v-2H5v2zm0-10h4v6h6v-6h4l-7-7-7 7z"}),"Upload");XC=QC.default=tA;var nA={},rA=bh;Object.defineProperty(nA,"__esModule",{value:!0});var oA=nA.default=void 0,iA=rA(hb()),aA=Z,lA=(0,iA.default)((0,aA.jsx)("path",{d:"M16.01 11H4v2h12.01v3L20 12l-3.99-4z"}),"ArrowRightAlt");oA=nA.default=lA;var sA={1:"https://i.imgur.com/vpVqdqe.png,",2:"https://s2.bunnycdn.ru/assets/avatars/Naruto/001.jpg",3:"https://s2.bunnycdn.ru/assets/avatars/DragonBall/002.jpg",4:"https://s2.bunnycdn.ru/assets/avatars/DragonBall/001.jpg",5:"https://s2.bunnycdn.ru/assets/avatars/Doraemon/001.jpg",6:"https://s2.bunnycdn.ru/assets/avatars/Doraemon/002.jpg",7:"https://s2.bunnycdn.ru/assets/avatars/Pokemon/005.jpg",8:"https://s2.bunnycdn.ru/assets/avatars/OnePiece/001.jpg",9:"https://s2.bunnycdn.ru/assets/avatars/Inuyasha/012.jpg",10:"https://s2.bunnycdn.ru/assets/avatars/DeathNote/003.jpg",11:"https://s2.bunnycdn.ru/assets/avatars/Conan/003.jpg"},cA={1:"Watching",2:"Completed",3:"Paused",4:"Dropped",5:"Planning",6:"Rewatching"},uA={1:"Watching",2:"Completed",3:"On-Hold",4:"Dropped",5:"Plan to Watch"};async function dA(e){var t,n,r;try{const o=`\n    query ($id: [Int] = [${e}]) {\n      Page {\n        media(idMal_in: $id, type: ANIME) {\n          id\n        }\n      }\n    }\n  `;return null==(r=null==(n=null==(t=(await WC.post("https://graphql.anilist.co/",{query:o})).data)?void 0:t.data)?void 0:n.Page)?void 0:r.media}catch(o){console.log(o)}}function fA({onClose:e}){var t;const n=W.useRef(),[r,o]=W.useState(!1),[i,a]=W.useState({}),[l,s]=W.useState("settings-1");var c=JSON.parse(sessionStorage.getItem("userdata")||"{}");function u(){o(!0),setTimeout((()=>{e(),o(!1)}),380)}W.useEffect((()=>{const e=e=>{n.current.contains(e.target)||u()};return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]),W.useEffect((()=>{var e=JSON.parse(localStorage.getItem("settings"))||{};return a(e),document.body.style.overflow="hidden",()=>document.body.style.overflow="auto"}),[]);const d=async e=>{const t=e.target.name,n=e.target.value||e.target.id;a((e=>({...e,[t]:n}))),localStorage.setItem("settings",JSON.stringify({...i,[t]:n}));var r=localStorage.getItem("token");if("username"===t){if((await Ek.set(r,"username",n)).error)return hd("Username already in use!",{duration:2e3,style:{color:"white",background:"#E87C03"}});c.username=n,sessionStorage.setItem("userdata",JSON.stringify(c))}"avataricon"===t&&(Ek.set(r,"profile_picture",sA[n]),c.profile_picture=sA[n],sessionStorage.setItem("userdata",JSON.stringify(c))),Ek.set(r,`settings.${t}`,n)};return mu.createPortal(Z.jsx(aE,{closing:r,children:Z.jsx(lE,{children:Z.jsxs(sE,{ref:n,closing:r,children:[window.innerWidth<=600&&Z.jsx(ij,{onClick:u}),Z.jsxs("div",{className:"user-menu",children:[Z.jsxs("p",{className:"settings-1"===l?"active nav":"nav",onClick:()=>{"settings-1"!==l&&(document.getElementById("settings-1").style.display="block",document.getElementById(l).style.display="none",s("settings-1"))},children:[Z.jsx(Jj,{style:{marginBottom:"-2.5%",marginRight:".2rem"}}),Z.jsx("span",{children:"General Settings"})]}),Z.jsxs("p",{className:"settings-2"===l?"active nav":"nav",onClick:()=>{"settings-2"!==l&&(document.getElementById("settings-2").style.display="block",document.getElementById(l).style.display="none",s("settings-2"))},children:[Z.jsx(XC,{style:{marginBottom:"-6%",marginRight:".2rem"}}),Z.jsx("span",{children:"Import"})]}),Z.jsxs("p",{className:"settings-3"===l?"active nav":"nav",onClick:()=>{"settings-3"!==l&&(document.getElementById("settings-3").style.display="block",document.getElementById(l).style.display="none",s("settings-3"))},children:[Z.jsx(qC,{style:{marginBottom:"-3%",marginRight:".2rem"}}),Z.jsx("span",{children:"Account Data"})]})]}),Z.jsxs("div",{className:"settingsmenu bg-secondary",id:"settings-1",children:[Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Username"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsx("input",{type:"text",className:"form-control",id:"username",defaultValue:(null==c?void 0:c.username)||"Unknown",name:"username",onChange:()=>{document.getElementById("savename").style.color="white"}}),Z.jsx("button",{className:"text-muted",id:"savename",style:{cursor:"pointer",background:"transparent",position:"absolute",right:"2.3rem",top:"14%"},onClick:()=>{document.getElementById("savename").style.color="#515151",d({target:{name:"username",value:document.getElementById("username").value}})},children:"Save"})]})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Avatar Icon"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsx("img",{alt:"avatar",src:"https://i.imgur.com/vpVqdqe.png",onClick:d,name:"avataricon",id:"1",className:"avataricon "+("1"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/Naruto/001.jpg",onClick:d,name:"avataricon",id:"2",className:"avataricon "+("2"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/DragonBall/002.jpg",onClick:d,name:"avataricon",id:"3",className:"avataricon "+("3"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/DragonBall/001.jpg",onClick:d,name:"avataricon",id:"4",className:"avataricon "+("4"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/Doraemon/001.jpg",onClick:d,name:"avataricon",id:"5",className:"avataricon "+("5"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/Doraemon/002.jpg",onClick:d,name:"avataricon",id:"6",className:"avataricon "+("6"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/Pokemon/005.jpg",onClick:d,name:"avataricon",id:"7",className:"avataricon "+("7"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/OnePiece/001.jpg",onClick:d,name:"avataricon",id:"8",className:"avataricon "+("8"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/Inuyasha/012.jpg",onClick:d,name:"avataricon",id:"9",className:"avataricon "+("9"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/DeathNote/003.jpg",onClick:d,name:"avataricon",id:"10",className:"avataricon "+("10"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"}),Z.jsx("img",{alt:"avatar",src:"https://s2.bunnycdn.ru/assets/avatars/Conan/003.jpg",onClick:d,name:"avataricon",id:"11",className:"avataricon "+("11"===i.avataricon?"avatariconselected":""),height:"30px",width:"30px"})]})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Password Changing"}),Z.jsx("div",{className:"col-md-9",children:Z.jsx("button",{className:"text-muted",style:{cursor:"pointer",background:"transparent"},onClick:()=>{window.location.href=`/resetpassword/${localStorage.getItem("token")}`},children:"Reset your password"})})]}),Z.jsx("hr",{}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-md-3 col-form-label",children:"Show continue watching in home page"}),Z.jsx("div",{className:"col-md-9",children:Z.jsxs("div",{className:"custom-control custom-switch",children:[" ",Z.jsx("input",{type:"checkbox",className:"custom-control-input",id:"show_playing_in_home",onChange:d,name:"continuewatching",value:"false"===i.continuewatching,checked:"true"===i.continuewatching||!i.continuewatching})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"show_playing_in_home"})," "]})})]}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-md-3 col-form-label",children:"Auto-skip intros"}),Z.jsx("div",{className:"col-md-9",children:Z.jsxs("div",{className:"custom-control custom-switch",children:[" ",Z.jsx("input",{type:"checkbox",className:"custom-control-input",id:"auto_skip_intros",onChange:d,name:"autoskip",value:"false"===i.autoskip,checked:"true"===i.autoskip||!1})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"auto_skip_intros"})," "]})})]}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-md-3 col-form-label",children:"Language for anime name"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"title_lang_en",className:"custom-control-input",onChange:d,name:"titlelang",value:"1",checked:"1"===i.titlelang||!i.titlelang}),Z.jsx("label",{className:"custom-control-label",htmlFor:"title_lang_en",children:"English"})," "]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"title_lang_jp",className:"custom-control-input",onChange:d,name:"titlelang",value:"2",checked:"2"===i.titlelang}),Z.jsx("label",{className:"custom-control-label",htmlFor:"title_lang_jp",children:"Native"})," "]})]})]}),Z.jsx("hr",{}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-md-3 col-form-label",children:"Preferred playback"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"preferred_server_hq",className:"custom-control-input",onChange:d,name:"preferredserver",value:"hq",checked:"hq"===i.preferredserver||!i.preferredserver}),Z.jsx("label",{className:"custom-control-label",htmlFor:"preferred_server_hq",children:"High Quality"})," "]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"preferred_server_def",className:"custom-control-input",onChange:d,name:"preferredserver",value:"gogo",checked:"gogo"===i.preferredserver}),Z.jsx("label",{className:"custom-control-label",htmlFor:"preferred_server_def",children:"Save Bandwidth"})," "]})]})]}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-md-3 col-form-label",children:"Auto select language"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"prefered_source_typesub",className:"custom-control-input",onChange:d,name:"prefered_source_type",value:"sub",checked:"sub"===i.prefered_source_type||!i.prefered_source_type})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"prefered_source_typesub",children:"English Sub"})]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"prefered_source_typedub",className:"custom-control-input",onChange:d,name:"prefered_source_type",value:"dub",checked:"dub"===i.prefered_source_type})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"prefered_source_typedub",children:"English Dub"})]}),Z.jsx("div",{className:"help-text text-muted",children:"System will use the selected audio source if available"})]})]}),Z.jsx("hr",{}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-md-3 col-form-label",children:"Episode list style"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"episode_list_style",className:"custom-control-input",onChange:d,name:"episode_list_style",value:!0,checked:"true"===i.episode_list_style||!i.episode_list_style})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"episode_list_style",children:"Default"})]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"episode_list_stylename",className:"custom-control-input",onChange:d,name:"episode_list_style",value:"noimage",checked:"noimage"===i.episode_list_style})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"episode_list_stylename",children:"No Image"})]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[" ",Z.jsx("input",{type:"radio",id:"episode_list_stylenumber",className:"custom-control-input",onChange:d,name:"episode_list_style",value:"onlytitle",checked:"onlytitle"===i.episode_list_style})," ",Z.jsx("label",{className:"custom-control-label",htmlFor:"episode_list_stylenumber",children:"Only Title"})," "]})]})]}),Z.jsxs("div",{className:"form-group row",children:[" ",Z.jsx("label",{className:"col-form-label col-md-3 pt-0",children:"Episodes per page"}),Z.jsxs("div",{className:"col-md-9",children:[" ",Z.jsx("input",{type:"number",style:{width:"90px"},className:"form-control",onChange:d,name:"watchlist_perpage",value:i.watchlist_perpage||20})," "]})]})]}),Z.jsxs("div",{className:"settingsmenu bg-secondary",id:"settings-2",style:{display:"none"},children:[Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Anilist Username"}),Z.jsx("div",{className:"col-md-9",children:Z.jsx("input",{type:"text",className:"form-control",id:"anilist-username",placeholder:"Please input your AL username",name:"username"})})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"MAL Username"}),Z.jsx("div",{className:"col-md-9",children:Z.jsx("input",{type:"text",className:"form-control",id:"mal-username",placeholder:"Please input your MAL username",name:"username"})})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"File importing"}),Z.jsx("div",{className:"col-md-9",children:Z.jsxs("div",{className:"custom-file",style:{width:"70%"},children:[Z.jsx("input",{type:"file",accept:"application/xml",className:"custom-file-input tether-target-attached-top tether-element-attached-top tether-element-attached-center tether-target-attached-center",id:"malfile",name:"textfile"}),Z.jsx("label",{className:"custom-file-label",htmlFor:"textfile",children:"Choose a mal list export file"}),Z.jsx("div",{className:"help-text text-muted",children:"You can upload a XML file that uses MAL format."})]})})]}),Z.jsx("hr",{}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Import from"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",onClick:()=>document.getElementById("startfolder").disabled=!1,children:[Z.jsx("input",{type:"radio",className:"custom-control-input",id:"site_anilist",name:"site",value:"anilist",defaultChecked:!0}),Z.jsx("label",{className:"custom-control-label",htmlFor:"site_anilist",children:"Anilist"})]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",onClick:()=>document.getElementById("startfolder").disabled=!0,children:[Z.jsx("input",{type:"radio",className:"custom-control-input",id:"site_mal",name:"site",value:"mal"}),Z.jsx("label",{className:"custom-control-label",htmlFor:"site_mal",children:"MAL"})]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",onClick:()=>document.getElementById("startfolder").disabled=!1,children:[Z.jsx("input",{type:"radio",className:"custom-control-input",id:"file",name:"site",value:"file"}),Z.jsx("label",{className:"custom-control-label",htmlFor:"file",children:"File"})]})]})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Import mode"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[Z.jsx("input",{type:"radio",className:"custom-control-input",id:"mode_merge",name:"mode",value:"merge",defaultChecked:!0}),Z.jsx("label",{className:"custom-control-label",htmlFor:"mode_merge",children:"Merge"})]}),Z.jsxs("div",{className:"custom-control custom-radio custom-control-inline",children:[Z.jsx("input",{type:"radio",className:"custom-control-input",id:"mode_replace",name:"mode",value:"replace"}),Z.jsx("label",{className:"custom-control-label",htmlFor:"mode_replace",children:"Replace"})]}),Z.jsx("div",{className:"help-text text-muted",children:"Merge combines with existing content in folder."})]})]}),Z.jsx("hr",{}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Folder select"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsxs("select",{className:"btn folderselect",name:"languages",id:"startfolder",children:[Z.jsx("option",{value:"1",children:"Watching"}),Z.jsx("option",{value:"2",children:"Completed"}),Z.jsx("option",{value:"3",children:"On Hold"}),Z.jsx("option",{value:"4",children:"Dropped"}),Z.jsx("option",{value:"5",children:"Planning"}),Z.jsx("option",{value:"6",children:"Rewatching"})]}),Z.jsx(oA,{style:{marginLeft:"1%",marginRight:"1%",marginBottom:"-1.5%",fontSize:"2rem"}}),Z.jsx("select",{className:"btn folderselect",name:"languages",id:"endfolder",children:(f=JSON.parse(localStorage.getItem("folders"))||["My List"],p=[],null==f||f.forEach((e=>{p.push(Z.jsx("option",{value:e,children:e}))})),p)}),Z.jsx("div",{className:"help-text text-muted",children:"Select which folder to import and the destination."})]})]}),Z.jsx("button",{className:"importbutton",onClick:async e=>{var t,n,r,o,i,a,l,s=(null==(t=document.getElementById("site_anilist"))?void 0:t.checked)?"anilist":(null==(n=document.getElementById("site_mal"))?void 0:n.checked)?"mal":"file",c=null==(r=document.getElementById("endfolder"))?void 0:r.value,u=null==(o=document.getElementById("startfolder"))?void 0:o.value,d=JSON.parse(localStorage.getItem(c)||"[]"),f=document.getElementById("mode_merge").checked,p=localStorage.getItem("token");switch(s){case"anilist":{if(!(i=document.getElementById("anilist-username").value))return hd.error("Please input a valid username!",{style:{background:"#333",color:"#fff"},duration:3e3});hd.loading("Importing anime from list...",{style:{background:"#333",color:"#fff"},duration:3e4});const e=`\n          query ($userId: Int, $userName: String = "${i}", $type: MediaType = ANIME) {\n            MediaListCollection(userId: $userId, userName: $userName, type: $type) {\n              lists {\n                name\n                isCustomList\n                isCompletedList: isSplitCompletedList\n                entries {\n                  id\n                  mediaId\n                  status\n                }\n              }\n            }\n          }\n        `;var m=(await WC.post("https://graphql.anilist.co/",{query:e})).data.data.MediaListCollection.lists.find((e=>e.name===cA[u])).entries.map((e=>e.mediaId));f?(a=d.concat(m),l=a.filter(((e,t)=>a.indexOf(e)===t)),localStorage.setItem(c,JSON.stringify(l)),p&&Ek.set(p,`folders.${c}`,l)):(localStorage.setItem(c,JSON.stringify(m)),p&&Ek.set(p,`folders.${c}`,m)),hd.dismiss(),hd.success("Loaded animes from Anilist!",{style:{background:"#333",color:"#fff"},duration:3e3});break}case"mal":{if(!(i=document.getElementById("mal-username").value))return hd.error("Please input a valid username!",{style:{background:"#333",color:"#fff"},duration:3e3});hd.loading("Importing anime from list...",{style:{background:"#333",color:"#fff"},duration:3e4});const e=await Ek.getMalUser(i);f?(a=d.concat(e),l=a.filter(((e,t)=>a.indexOf(e)===t)),localStorage.setItem(c,JSON.stringify(l)),p&&Ek.set(p,`folders.${c}`,l)):(localStorage.setItem(c,JSON.stringify(e)),p&&Ek.set(p,`folders.${c}`,e)),hd.dismiss(),hd.success("Loaded animes from MAL!",{style:{background:"#333",color:"#fff"},duration:3e3});break}case"file":var h=document.getElementById("malfile").files[0];hd.loading("Importing anime from list...",{style:{background:"#333",color:"#fff"},duration:3e4});var g=new FileReader;g.onload=function(e){var t,n,r=g.result;for(var o=(new DOMParser).parseFromString(r,"text/xml").getElementsByTagName("series_animedb_id"),i=[],s=0;s<o.length;s++){if((null==(n=null==(t=o[s].parentElement.getElementsByTagName("my_status"))?void 0:t[0])?void 0:n.innerHTML)!==uA[u])continue;const e=Number(o[s].innerHTML);i.push(e)}var f=[];for(let a=0;a<i.length;a+=45){const e=i.slice(a,a+45);f.push(dA(e))}Promise.all(f).then((e=>{var t=e.flat(1).map((e=>e.id));document.getElementById("mode_merge").checked?(a=d.concat(t),l=a.filter(((e,t)=>a.indexOf(e)===t)),localStorage.setItem(c,JSON.stringify(l)),Ek.set(p,`folders.${c}`,l)):(localStorage.setItem(c,JSON.stringify(t)),Ek.set(p,`folders.${c}`,t)),hd.dismiss(),hd.success("Loaded animes from file!",{style:{background:"#333",color:"#fff"},duration:3e3})}))},g.readAsText(h)}},children:"Import"})]}),Z.jsxs("div",{className:"settingsmenu bg-secondary",id:"settings-3",style:{display:"none"},children:[Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Anime with progress data"}),Z.jsx("div",{className:"col-md-9",children:Z.jsxs("p",{children:[Z.jsxs("strong",{children:[localStorage.length," shows"]})," ",localStorage.getItem("token")?"(Synced with cloud)":""]})})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Folder Names"}),Z.jsx("div",{className:"col-md-9",children:Z.jsx("p",{children:(null==(t=JSON.parse(localStorage.getItem("folders")))?void 0:t.join(", "))??"(No Folders)"})})]}),Z.jsxs("div",{className:"form-group row",children:[Z.jsx("label",{className:"col-md-3 col-form-label",children:"Data Deletion"}),Z.jsxs("div",{className:"col-md-9",children:[Z.jsx("button",{className:"text-muted",id:"watchdelete",style:{cursor:"pointer",background:"transparent"},onClick:()=>{if(!sessionStorage.getItem("oneclick2"))return sessionStorage.setItem("oneclick2",!0),void(document.getElementById("watchdelete").innerText="Click again to confirm!");var e=localStorage.getItem("token");Ek.set(e,"watchdata",{}).then((t=>{if(t.error)return hd.error("Error occured when deleting data!",{style:{background:"#333",color:"#fff"}});hd.success("Data deleted succesfully!",{style:{background:"#333",color:"#fff"}}),sessionStorage.removeItem("oneclick2"),localStorage.clear(),localStorage.setItem("token",e),window.location.reload()}))},children:"Delete watch data"}),Z.jsx("button",{className:"text-muted",id:"accdelete",style:{cursor:"pointer",background:"transparent",marginLeft:"5%"},onClick:()=>{if(!sessionStorage.getItem("oneclick"))return sessionStorage.setItem("oneclick",!0),void(document.getElementById("accdelete").innerText="Click again to confirm!");var e=localStorage.getItem("token");Ek.accountDelete(e).then((e=>{if(e.error)return hd.error("Error occured when deleting account!",{style:{background:"#333",color:"#fff"}});hd.success("Account deleted succesfully!",{style:{background:"#333",color:"#fff"}}),sessionStorage.removeItem("oneclick"),localStorage.removeItem("userdata"),localStorage.removeItem("token"),u()}))},children:"Delete your account"})]})]})]})]})})}),document.getElementById("modal-root"));var f,p}function pA(){const e=W.useRef(),[t,n]=W.useState(!1),[r,o]=W.useState(!1),[i,a]=W.useState(!1),[l,s]=W.useState(!1),[c,u]=W.useState(!1),d=JSON.parse(sessionStorage.getItem("userdata"));W.useEffect((()=>{function r(r){t&&!e.current.contains(r.target)&&n(!t)}return window.addEventListener("mousedown",r),()=>{window.removeEventListener("mousedown",r)}}),[t]);var f=localStorage.getItem("token");return Z.jsxs(hj,{children:[Z.jsxs(vj,{ref:e,onClick:()=>n(!t),children:[Z.jsx("img",{src:(null==d?void 0:d.profile_picture)||"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAIAAABMXPacAAAACXBIWXMAAC4jAAAuIwF4pT92AAAF+mlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEzLTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIwLTExLTAyVDIwOjQ1OjE3LTAzOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIwLTExLTAyVDIwOjQ1OjE3LTAzOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMC0xMS0wMlQyMDo0NToxNy0wMzowMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1MTE5NmRlYy04ZWIyLTJmNGUtYTdiMS04ZThiODg1MWNlYTQiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDpiM2QxMTg1Zi1mZWMyLWY4NGMtOGNlYS1lOWU4OTE2YTNiMGYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo5OTkyNzc5Zi1mZDIwLTNkNDgtOTg3YS04Y2ExMzc2MDE1YzQiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjk5OTI3NzlmLWZkMjAtM2Q0OC05ODdhLThjYTEzNzYwMTVjNCIgc3RFdnQ6d2hlbj0iMjAyMC0xMS0wMlQyMDo0NToxNy0wMzowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1MTE5NmRlYy04ZWIyLTJmNGUtYTdiMS04ZThiODg1MWNlYTQiIHN0RXZ0OndoZW49IjIwMjAtMTEtMDJUMjA6NDU6MTctMDM6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE5IChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz76LKIbAAAH/UlEQVR4nO2d13LbOBRAFwA72CGKKrFnks/Pb2Vk9WpRsqzifcBMxpPdWCy4ICXhPHMuCBwCRCOIfv78+Y+iPnDdN/DoKAE1owTUjBJQM0pAzWh130AuCCGO49i2bdu2aZqmaeq6rus6xhhjfLlcLpfL8Xg8Ho+Hw+FwOOz3+/1+v9vtzudz3fd+hUYLoJT6vu95nuu6tm3/7TKuQdO0P67Z7/fb7fb19XWz2WRZBn+/ZWiiANM0oygKwzAIAk0rf4e8xiRJcjqd1uv1arVaLpeHw0HgrVanWQIopYyxOI4ppQLDaprGGGOMZVm2WCzm83lzKkRTBDiOkyRJq9WyLAsuFUoppTRJktlsNp1Od7sdXFo5qV8AISRN03a7Lfap/wLLsr59+xZF0WQyGY/H9b6oaxYQBEGn02m1WvKTppR+//7d87zRaLRer+XfAKdOAd1ut9vtftG9kUCr1aKUDofD4XBYyw3UI8AwjH6/3+v1akn9D2zb/vHjh2VZg8Hg/f1dcuo1CKCU9vv9JEnkJ/0FvV5P1/XBYCC5gyRbgOd5T09PURRJTjcPSZJomvbr16/X11dpiUqdC/I87/n5uZmlz4mi6Pn52fM8aSnKE0ApfXp6CsNQWorlCMPw6elJWp9YkgD+1m3ys/+ZKIr6/b5hGBLSkiSggW/dr0mSpN/vS0hIhoBut9uQHmcher1et9uFTgVcQBAEErIBRLfbDYIANAlYAYSQTqdT71i3CrZtdzodQghcErAC0jStZZ5HIK1WK01TuPiAAhzHabfbcPGl0W63HccBCg4oIEkSab1pUPgSAlBwKAGU0ltvfD7DJ00hIkMJYIyBrm1JxrIsxhhEZBABpmnGcQwRuUbiODZNU3hYEAFRFN1H6/8ZSinEVAqIgObPuJUDIl/iBVBKoUePdREEgfCaLV6A7/tVdlM1GU3TfN8XG1O8AJmrGfIRnjvBAgghruuKjdkoXNcVOzUkWADfwyw2ZqOwbVvstIRgAfdd+hyxeVQCCtNoARBjxaYhNo9KQGEaLUDXdbEBG4jYPCoBhWm0AIzv/7NLsXlUAgrTaAGXy0VswAYiNo9KQGEaLeB4PIoN2EDE5lEJKEyjBTTtM2gIxOZRCShMowXs93uxARuI2DwqAYVptIDdbnffDvgpOAIDChZwPp+3263YmI1iu92KPdpA/MyBzG885SM8d+IFbDab0+kkPGwTOJ1Om81GbEzxArIsq/HsC1DW67Xw7+hBJi9XqxVE2NqByBeIgOVy2ZwjqUSRZdlyuRQeFkTA4XBYLBYQkWtksVhAjPOh1k/m8/nb2xtQcPm8vb3N53OIyFACsiybzWZAweUzm82AGlXAFcTpdHofb4Isy6bTKVBwQAG73W4ymcDFl8ZkMoE7XxF2DX08Ht96QzSbzcbjMVx8WAHn83k0Gt3u9Nx+vx+NRqDnWoLvIlmv13UdSFid4XAIPaqXsY1nOBy+vLxISEgsLy8vEh4dSfuoBoMBXEcCgul0OhgMJCQkScD7+/tgMIAYykOwXC6lnSEqbydhlmWDwaD5E6Xr9Vrm6aHyBBBCEELH47HJu+f4nzgQQqCHNH1G0ge9hmH8/jFAkzfwYoz5XyP4bwYktEIyBPB/AzDGbuILMl3XwzA0TdMwDAn/GIAVwD8bbrfbcRzf1ufz/LQ4wzAmk4nwhfjPABYKr86dTicMQ4QQXEJAaJqWJImu66PRaLVaAb26oAQQQqIoStPU87xbLH0OQsj3fYQQxni5XELUAxABuq5HUdRut/ndQyQhDUJIEAS/HQjf/i1egGEYv0tfePBaQAhxBwih5XIptmskWAAhJAzDdrt9f2em8Bx9fHzM53OBbZFgAUEQJEniuu6ttzz/BSHkuu7lcjmdTgK3HIgU4Pt+mqa+7zd5qFUFjLHv+9yBqC1yYgQghBzH4T3Oey19DsY4DMPz+Xw+n3e73cfHR9WAQm7Lsqw0TRlj9136HIwxYyxNUyEHowooL13X4ziO4/gRSp+DMeZZrn5sgYAi832fMfYI56R8xjRNxlj1rnZVAY7jMMbu75jWPPB/v1Y8wazSS5gQwhgLguBxGp/P8Mmu/X5/OBxKjwzKFxwfczHGHuGImr+h6zpjLAzD0gs45QUYhhHHsWVZ9zfmyg9CyLKsOI5L//OqpAD++FcxfzdULIqSAlzXraL9zuCNQbkTa8sIIIR4nveYPZ+/QSn1PK9EJSgjgFLq+/4jv3v/i67rvu+XeCgLC+BN3n0fEF0O13VLvAmKCeCTburx/194JXAcp1C3sJgAfoD+TewuqQXbtov+PqGYAC75tjaYyIQ/oIWahwICMMau63qe95gTD3nAGHue57pu/iIqUJSmaarW/yq8kcg/N1xMANwvFe8Jx3HEC+BL0mrwlQdKaf5tCXkF8Mdftf55wBjnrwR5C/Tufw4jlvy/mskrwLZtNfWWH8Mwcj6vuQQQQhzHUf2f/Oi67jhOnmmJ6wL4moNt24+88FIUhJBt23lWq64LwBhTStXjXxRd1/N8j5VLgGVZqv9TlJzllrcJUkuPRSGEiGmCCCG2basaUBSMsW3bVx/c68VqmqZpmuoNXBSEEC+6ry/LJUDNP5dD0zQBAlT/pwpXS++6ADUArsLV0lM1ABYBNUAJqIIAAZqmqS5QORBCV/svucYBgu7nEREwDlB90CqoGlAzAmqAegFUQcBckAIUJaBmlICaUQJqRgmomX8BgtUlNfYugF4AAAAASUVORK5CYII=",alt:"user-icon",className:"usericon1"}),Z.jsx(Jj,{sx:{fontSize:"2.5rem",color:"darkgray"},className:"usericon2"}),function(){if(!(window.innerWidth<=600))return t?Z.jsx(Uj,{style:{position:"absolute",fontSize:"max(2rem, 1.3vw)"}}):Z.jsx(Rj,{style:{position:"absolute",fontSize:"max(2rem, 1.3vw)"}})}(),Z.jsx("div",{children:Z.jsx(gj,{hide:!t,children:Z.jsxs("section",{children:[!f&&Z.jsx(yj,{onClick:()=>a(!0),children:"Login"}),f&&Z.jsx(yj,{onClick:()=>{localStorage.removeItem("token"),sessionStorage.removeItem("userdata")},children:"Log Out"}),f&&Z.jsx(yj,{onClick:()=>o(!0),children:"Settings"}),Z.jsx(yj,{onClick:()=>u(!0),children:"Contact Us"})]})})})]}),r&&Z.jsx(fA,{onClose:()=>o(!1)}),i&&Z.jsx(Cj,{onClose:()=>a(!1),openRegister:()=>s(!0)}),c&&Z.jsx(iE,{onClose:()=>u(!1)}),l&&Z.jsx(Tj,{onClose:()=>s(!1)})]})}var mA={},hA=bh;Object.defineProperty(mA,"__esModule",{value:!0});var gA=mA.default=void 0,vA=hA(hb()),yA=Z,bA=(0,vA.default)((0,yA.jsx)("path",{d:"M4 18h16c.55 0 1-.45 1-1s-.45-1-1-1H4c-.55 0-1 .45-1 1s.45 1 1 1zm0-5h16c.55 0 1-.45 1-1s-.45-1-1-1H4c-.55 0-1 .45-1 1s.45 1 1 1zM3 7c0 .55.45 1 1 1h16c.55 0 1-.45 1-1s-.45-1-1-1H4c-.55 0-1 .45-1 1z"}),"MenuRounded");gA=mA.default=bA;var wA={},xA=bh;Object.defineProperty(wA,"__esModule",{value:!0});var kA=wA.default=void 0,SA=xA(hb()),jA=Z,EA=(0,SA.default)((0,jA.jsx)("path",{d:"M10 19v-5h4v5c0 .55.45 1 1 1h3c.55 0 1-.45 1-1v-7h1.7c.46 0 .68-.57.33-.87L12.67 3.6c-.38-.34-.96-.34-1.34 0l-8.36 7.53c-.34.3-.13.87.33.87H5v7c0 .55.45 1 1 1h3c.55 0 1-.45 1-1z"}),"HomeRounded");kA=wA.default=EA;var CA={},AA=bh;Object.defineProperty(CA,"__esModule",{value:!0});var OA=CA.default=void 0,NA=AA(hb()),_A=Z,PA=(0,NA.default)((0,_A.jsx)("path",{d:"M15.5 14h-.79l-.28-.27c1.2-1.4 1.82-3.31 1.48-5.34-.47-2.78-2.79-5-5.59-5.34-4.23-.52-7.79 3.04-7.27 7.27.34 2.8 2.56 5.12 5.34 5.59 2.03.34 3.94-.28 5.34-1.48l.27.28v.79l4.25 4.25c.41.41 1.08.41 1.49 0 .41-.41.41-1.08 0-1.49L15.5 14zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"}),"SearchRounded");OA=CA.default=PA;var IA={},TA=bh;Object.defineProperty(IA,"__esModule",{value:!0});var LA=IA.default=void 0,MA=TA(hb()),RA=Z,zA=(0,MA.default)((0,RA.jsx)("path",{d:"M17 20H5c-.55 0-1-.45-1-1V7c0-.55-.45-1-1-1s-1 .45-1 1v13c0 1.1.9 2 2 2h13c.55 0 1-.45 1-1s-.45-1-1-1zm3-18H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 10-2.5-1.5L15 12V4h5v8z"}),"CollectionsBookmarkRounded");LA=IA.default=zA;const $A=W.memo((function(){const e=W.useRef(),[t,n]=W.useState(!1),[r,o]=W.useState(0),[i,a]=W.useState(!1),[l,s]=W.useState(!1),[c,u]=W.useState(!1),[d,f]=W.useState(!1);function p(){window.innerWidth<600||(o(1),document.getElementById("sidenav").style.width="clamp(12rem, 22vw, 30rem)",document.getElementById("meow").style.display="none",document.getElementById("backgroundsh").style.opacity=1,document.getElementById("backgroundsh").style.pointerEvents="auto")}function m(){0===window.scrollY&&o(0),document.getElementById("sidenav").style.width=0,document.getElementById("meow").style.display="block",document.getElementById("backgroundsh").style.opacity=0,document.getElementById("backgroundsh").style.pointerEvents="none"}W.useEffect((()=>{function i(){window.innerWidth<600||(0===r&&window.scrollY>10?o(1):1===r&&window.scrollY<10&&o(0))}function a(i){var a;if(t&&xk){if("menuback"!==i.target.id)return;o(!r),setTimeout((()=>{document.body.style.overflowY="visible",n(!1)}),380)}else t&&!(null==(a=null==e?void 0:e.current)?void 0:a.contains(i.target))&&n(!1)}return window.addEventListener("mousedown",a),window.addEventListener("scroll",i),()=>{window.removeEventListener("mousedown",a),window.removeEventListener("scroll",i)}}),[r,t]);let h=0,g=0;return document.addEventListener("touchstart",(e=>{h=e.changedTouches[0].screenX})),document.addEventListener("touchend",(e=>{g=e.changedTouches[0].screenX,0===h||h>window.innerWidth/6||(g<h&&m(),g>h&&p(),h=0,g=0)})),W.useEffect((()=>{if(!xk)return;const e=document.querySelectorAll(".menu-link");e.forEach((e=>e.classList.remove("active"))),e.forEach(((t,n)=>{if(3!==n){var o=t.pathname.split("/")[1];window.location.pathname.split("/")[1]===o&&t.classList.add("active"),0===r&&t.addEventListener("click",(()=>{navigator.vibrate(40),e.forEach((e=>e.classList.remove("active"))),t.classList.add("active")}))}}))}),window.innerWidth<=600?[r]:[]),Z.jsxs(Cb,{opacity:r,children:[Z.jsxs(Ob,{children:[Z.jsxs(Ib,{id:"sidenav",children:[Z.jsx(Tb,{to:"/",style:{marginTop:"15%"},children:"Home"}),Z.jsx(Tb,{to:"/movies",children:"Movies"}),Z.jsx(Tb,{to:"/series",children:"Series"}),Z.jsx(Tb,{to:"/trending",children:"Trending"}),Z.jsx(Tb,{to:"/schedule",children:"Schedule"}),Z.jsx(Tb,{to:"/collections",children:"Collections"}),Z.jsx(Tb,{to:"/genres",children:"Genres"}),Z.jsx(Tb,{to:"/mylist",children:"My List"}),Z.jsx(Tb,{to:{pathname:"https://discord.gg/SKcb2C7HjH"},target:"_blank",children:"Discord"}),Z.jsxs(Lb,{style:{position:"absolute",bottom:"3rem"},children:[Z.jsx(Mb,{onClick:()=>window.location.href="https://ko-fi.com/animeflixlive",children:"Donate"}),Z.jsx(Mb,{onClick:()=>u(!0),children:"Settings"}),Z.jsx(Mb,{onClick:()=>f(!0),children:"Contact Us"})]})]}),Z.jsx(Pb,{style:{fontSize:"max(3rem, 3vw)",position:"absolute",top:"50vh",left:0},id:"meow",onMouseOver:()=>xk?null:p()}),Z.jsx("div",{id:"backgroundsh",style:{width:"100vw",height:"100vh",top:0,left:0,zIndex:10,position:"fixed",background:"rgba(0, 0, 0, .5)",overflow:"auto",opacity:0,transition:"0.7s opacity",pointerEvents:"none"},onClick:()=>m()}),Z.jsx(Ab,{to:"/",title:"Animeflix",children:Z.jsx("img",{style:{width:"6.98vw"},alt:"animeflix-logo",src:hh})})]}),Z.jsx(Rb,{children:Z.jsxs(zb,{children:[Z.jsx(Db,{children:Z.jsxs($b,{to:"/",className:"menu-link",children:[Z.jsx(kA,{sx:{fontSize:"3rem"}}),Z.jsx(Bb,{children:"Home"})]})}),Z.jsx(Db,{children:Z.jsxs($b,{to:"/search",className:"menu-link",children:[Z.jsx(OA,{sx:{fontSize:"3rem"}}),Z.jsx(Bb,{children:"Search"})]})}),Z.jsx(Db,{children:Z.jsxs($b,{to:"/mylist",className:"menu-link",children:[Z.jsx(LA,{sx:{fontSize:"3rem"}}),Z.jsx(Bb,{children:"My List"})]})}),Z.jsx(Db,{children:Z.jsxs($b,{to:"#",className:"menu-link",onClick:()=>{document.body.style.overflowY="hidden",o(!1),n(!0)},children:[Z.jsx(gA,{sx:{fontSize:"3rem"}}),Z.jsx(Bb,{children:"More"})]})})]})}),t&&Z.jsxs(Fb,{id:"menuback",closing:r,children:[Z.jsx(pA,{}),Z.jsxs("div",{style:{position:"absolute",left:"50%",transform:"translateX(-50%)",top:"15%",textAlign:"center"},onClick:()=>{document.body.style.overflowY="visible",o(!r),n(!1)},children:[Z.jsx(Tb,{to:"/",children:"Home"}),Z.jsx(Tb,{to:"/movies",children:"Movies"}),Z.jsx(Tb,{to:"/series",children:"Series"}),Z.jsx(Tb,{to:"/trending",children:"Trending"}),Z.jsx(Tb,{to:"/schedule",children:"Schedule"}),Z.jsx(Tb,{to:"/collections",children:"Collections"}),Z.jsx(Tb,{to:"/genres",children:"Genres"}),Z.jsx(Tb,{to:"/mylist",children:"My List"}),Z.jsx(Tb,{to:{pathname:"https://discord.gg/SKcb2C7HjH"},target:"_blank",children:"Discord"})]})]}),Z.jsxs(Nb,{children:[Z.jsx(mj,{}),Z.jsx(pA,{})]}),c&&Z.jsx(fA,{onClose:()=>u(!1)}),i&&Z.jsx(Cj,{onClose:()=>a(!1),openRegister:()=>s(!0)}),d&&Z.jsx(iE,{onClose:()=>f(!1)}),l&&Z.jsx(Tj,{onClose:()=>s(!1)})]})})),DA=dh.div`
  @media (min-width: 600px) {
    @media (min-height: 600px) {
      margin: -12rem 0;
    }
  }
`,BA=dh.div`
  & + & {
    margin-top: 1rem;
  }
`,FA=dh.div`
  width: 100%;
  height: 100%;
  z-index: 20;
  position: absolute;
  justify-content: center;
  align-items: center;
  background: black;
  opacity: ${e=>e.visible?1:0};
  display: ${e=>e.disabled?"none":"flex"};
  transition: opacity ease 400ms;

  img {
    mix-blend-mode: screen;
    max-width: max(4rem, 5vw);
    animation: ${xb} 2s infinite linear;
  }
`,UA=dh.p`
  position: absolute;
  bottom: 1.5%;
  opacity: 0;
  white-space: nowrap;
  cursor: pointer;
  transition: opacity 1.5s;
`,WA="/assets/loading-4EBcCCuM.png";function VA({loading:e}){const[t,n]=W.useState(!0),[r,o]=W.useState(!1);return W.useEffect((()=>{let t=0;e?(o(!0),n(!1)):(o(!1),t=setTimeout((()=>{n(!0)}),400));var r=setTimeout((()=>{document.getElementById("toolong").style.opacity=1}),1e4);return()=>{clearTimeout(t),clearTimeout(r)}}),[e]),Z.jsxs(FA,{disabled:t,visible:r,id:"loadingscreen",children:[Z.jsx(UA,{id:"toolong",onClick:()=>window.location.href="https://discord.gg/SKcb2C7HjH",children:"Site having issues? Join our Discord!"}),Z.jsx("img",{alt:"loading",src:WA,style:{width:"100%"}})]})}const HA=dh.div`
  width: 100%;
  height: 45vh;
  display: flex;
  line-height: 1.3;
  align-items: center;
  background: linear-gradient(0deg, #141414, transparent), 
              url(${e=>e.background}) no-repeat;
  background-size: cover;
  background-position: center;

  @media (min-width: 600px) {
    height: 70vh;
    @media (orientation: landscape) {
      height: 100vh;
    }
    line-height: 1.5;
    background: linear-gradient(90deg, #141414 30%, transparent 70%), linear-gradient(0deg, #141414 1%, transparent 99%)${e=>e.background?`, url(${e.background}) no-repeat;`:";"}
    background-size: cover;
  }
  @media (max-height: 720px) and (min-width: 800px) {
    height: 110vh;
  }
`,qA=dh(Cp)`
  height: max(2.5rem, 2vw);
  position: absolute;
  top: .3rem;
  left: 50%;
  z-index: 3;
  transform:translate(-51%,0);
  transition: opacity 1.5s ease; 
  opacity: 0;
  

  @media (min-width: 600px) {
    display: none;
  }

  img {
    filter: drop-shadow(3px 3px 2px rgb(0 0 0 / 0.7));
    max-height: 100%;
  }
`,YA=dh.main`
  margin: 0 3.5vw;
  text-shadow: 2px 2px 3px #141414;
`,JA=dh.img`
  width: clamp(20rem, 25vw, 30vw);
  margin-bottom: 0;
  margin-left: -1vw;
  @media (min-width: 1670px) {
    width: 20vw;
  }
  @media (min-width: 2100px) {
    width: 17vw;
  }
`,GA=dh.div`
  strong {
    color: #46D369;
  }

  label {
    margin-left: min(2vw, 2.5rem);
  }
`;dh.div`
  width: 100vw;
  height: 4rem;
  position: absolute;
  margin-left: 0;
  left: 0;
  top: 0;
  background: linear-gradient(180deg, rgba(20, 20, 20, 1) 0%, rgba(20, 20, 20, 1) 70%, transparent 100%);
`;const QA=dh.div`
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;

  @media (min-width: 500px) {
    width: 60vw;
  }

  @media (min-width: 1200px) {
    width: 40vw;
  }

  @media (min-width: 1500px) {
    width: 35vw;
  }
`,KA=dh.div`
  display: flex;
  margin-top: min(2vw, 3rem);
`,XA=dh.button`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 1vw;
  cursor: pointer;
  padding: min(1vw, 1.5rem) min(3vw, 4rem);

  @media (max-width: 2000px) {
    padding: min(1vw, 1.1rem) min(2.7vw, 4rem);
  }

  border-radius: .3rem;
  color: #fff;
  background: rgba(77, 77, 77, 0.8);
  transition: background ease 200ms;

  &:hover {
    background: rgba(77, 77, 77, 0.4);
  }

  @media (max-width: 600px) {
    padding: min(1.5vw, 1.5rem) min(3vw, 4rem);
  }
`;var ZA={},eO=bh;Object.defineProperty(ZA,"__esModule",{value:!0});var tO=ZA.default=void 0,nO=eO(hb()),rO=Z,oO=(0,nO.default)((0,rO.jsx)("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"}),"Info");function iO({onClick:e=(()=>{})}){return Z.jsxs(XA,{type:"button",onClick:e,children:[Z.jsx(tO,{style:{fontSize:"clamp(1.2rem, 3vw, 2.5rem)",marginRight:".5vw"}}),Z.jsx("p",{style:{fontFamily:"NetflixSans-Md"},children:"More Information"})]})}tO=ZA.default=oO;var aO=function(e){var t={};function n(r){if(t[r])return t[r].exports;var o=t[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,n),o.l=!0,o.exports}return n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)n.d(r,o,function(t){return e[t]}.bind(null,o));return r},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=4)}([function(e,t,n){e.exports=n(7)()},function(e,t,n){e.exports=n(5)},function(e,t,n){var r=Array.isArray,o=Object.keys,i=Object.prototype.hasOwnProperty;e.exports=function e(t,n){if(t===n)return!0;if(t&&n&&"object"==typeof t&&"object"==typeof n){var a,l,s,c=r(t),u=r(n);if(c&&u){if((l=t.length)!=n.length)return!1;for(a=l;0!=a--;)if(!e(t[a],n[a]))return!1;return!0}if(c!=u)return!1;var d=t instanceof Date,f=n instanceof Date;if(d!=f)return!1;if(d&&f)return t.getTime()==n.getTime();var p=t instanceof RegExp,m=n instanceof RegExp;if(p!=m)return!1;if(p&&m)return t.toString()==n.toString();var h=o(t);if((l=h.length)!==o(n).length)return!1;for(a=l;0!=a--;)if(!i.call(n,h[a]))return!1;for(a=l;0!=a--;)if(!e(t[s=h[a]],n[s]))return!1;return!0}return t!=t&&n!=n}},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},o=l(n(10)),i=l(n(11)),a=l(n(13));function l(e){return e&&e.__esModule?e:{default:e}}var s=void 0;t.default=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],l=(0,o.default)();if(s||(s=(0,i.default)(l)),t.events)throw new Error("Event handlers cannot be overwritten.");if("string"==typeof e&&!document.getElementById(e))throw new Error('Element "'+e+'" does not exist.');t.events=a.default.proxyEvents(l);var c=new Promise((function(n){"object"===(void 0===e?"undefined":r(e))&&e.playVideo instanceof Function?n(e):s.then((function(r){var o=new r.Player(e,t);return l.on("ready",(function(){n(o)})),null}))})),u=a.default.promisifyPlayer(c,n);return u.on=l.on,u.off=l.off,u},e.exports=t.default},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},o=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),i=c(n(1)),a=c(n(0)),l=c(n(9)),s=c(n(22));function c(e){return e&&e.__esModule?e:{default:e}}var u=function(e){function t(e){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t);var n=function(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}(this,(t.__proto__||Object.getPrototypeOf(t)).call(this,e)),r=n.props.aspectRatio.split(":");return n.state={aspectRatio:r[0]/r[1],videoHeight:10},n.defaultPlayerVars={autoplay:1,controls:0,rel:0,showinfo:0,mute:1,modestbranding:1,iv_load_policy:3,playsinline:1},n}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(t,e),o(t,[{key:"componentDidMount",value:function(){this.updateDimensions(),window.addEventListener("resize",this.updateDimensions.bind(this))}},{key:"componentWillUnmount",value:function(){window.removeEventListener("resize",this.updateDimensions.bind(this))}},{key:"updateDimensions",value:function(){var e=this.state.aspectRatio,t=this.container.clientWidth,n=this.container.clientHeight,r=n,o=t,i=0,a=0;t/n>e?i=((r=t/e)-n)/-2:a=((o=n*e)-t)/-2,this.setState({videoHeight:r,videoWidth:o,videoY:i,videoX:a})}},{key:"onEnd",value:function(e){e.target.playVideo(),this.props.onEnd(e)}},{key:"onReady",value:function(e){e.target.playVideo(),this.props.onReady(e)}},{key:"render",value:function(){var e,t=this,n=this.state,o=n.videoHeight,a=n.videoWidth,c=n.videoX,u=n.videoY,d=this.props,f=d.style,p=d.children,m=d.className,h=d.overlay,g=d.playerOptions,v={videoId:(e=this.props).videoId,onPlay:e.onPlay,onPause:e.onPause,onError:e.onError,onStateChange:e.onStateChange,onPlaybackRateChange:e.onPlaybackRateChange,onPlaybackQualityChange:e.onPlaybackQualityChange},y={playerVars:r({},this.defaultPlayerVars,g),host:this.props.nocookie?"https://www.youtube-nocookie.com":"https://www.youtube.com"};return i.default.createElement("div",{style:f,ref:function(e){return t.container=e},className:[s.default.container,m].join(" ")},i.default.createElement("div",null,p),i.default.createElement("div",{className:s.default.videoContainer,style:{width:a+"px",height:o+"px",top:u+"px",left:c+"px"}},h&&i.default.createElement("div",{className:s.default.overlay,style:{backgroundColor:h}}),i.default.createElement(l.default,r({},v,{onReady:this.onReady.bind(this),onEnd:this.onEnd.bind(this),opts:y,className:s.default.videoIframe,containerClassName:s.default.videoInnerContainer}))))}}]),t}(i.default.Component);u.propTypes={videoId:a.default.string.isRequired,aspectRatio:a.default.string,overlay:a.default.string,className:a.default.string,onReady:a.default.func,onEnd:a.default.func,playerOptions:a.default.object},u.defaultProps={aspectRatio:"16:9",overlay:"false",nocookie:!1,playerOptions:{},onReady:function(){},onPlay:function(){},onPause:function(){},onError:function(){},onEnd:function(){}},t.default=u},function(e,t,n){
/** @license React v16.13.1
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
var r=n(6),o="function"==typeof Symbol&&Symbol.for,i=o?Symbol.for("react.element"):60103,a=o?Symbol.for("react.portal"):60106,l=o?Symbol.for("react.fragment"):60107,s=o?Symbol.for("react.strict_mode"):60108,c=o?Symbol.for("react.profiler"):60114,u=o?Symbol.for("react.provider"):60109,d=o?Symbol.for("react.context"):60110,f=o?Symbol.for("react.forward_ref"):60112,p=o?Symbol.for("react.suspense"):60113,m=o?Symbol.for("react.memo"):60115,h=o?Symbol.for("react.lazy"):60116,g="function"==typeof Symbol&&Symbol.iterator;function v(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var y={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},b={};function w(e,t,n){this.props=e,this.context=t,this.refs=b,this.updater=n||y}function x(){}function k(e,t,n){this.props=e,this.context=t,this.refs=b,this.updater=n||y}w.prototype.isReactComponent={},w.prototype.setState=function(e,t){if("object"!=typeof e&&"function"!=typeof e&&null!=e)throw Error(v(85));this.updater.enqueueSetState(this,e,t,"setState")},w.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},x.prototype=w.prototype;var S=k.prototype=new x;S.constructor=k,r(S,w.prototype),S.isPureReactComponent=!0;var j={current:null},E=Object.prototype.hasOwnProperty,C={key:!0,ref:!0,__self:!0,__source:!0};function A(e,t,n){var r,o={},a=null,l=null;if(null!=t)for(r in void 0!==t.ref&&(l=t.ref),void 0!==t.key&&(a=""+t.key),t)E.call(t,r)&&!C.hasOwnProperty(r)&&(o[r]=t[r]);var s=arguments.length-2;if(1===s)o.children=n;else if(1<s){for(var c=Array(s),u=0;u<s;u++)c[u]=arguments[u+2];o.children=c}if(e&&e.defaultProps)for(r in s=e.defaultProps)void 0===o[r]&&(o[r]=s[r]);return{$$typeof:i,type:e,key:a,ref:l,props:o,_owner:j.current}}function O(e){return"object"==typeof e&&null!==e&&e.$$typeof===i}var N=/\/+/g,_=[];function P(e,t,n,r){if(_.length){var o=_.pop();return o.result=e,o.keyPrefix=t,o.func=n,o.context=r,o.count=0,o}return{result:e,keyPrefix:t,func:n,context:r,count:0}}function I(e){e.result=null,e.keyPrefix=null,e.func=null,e.context=null,e.count=0,10>_.length&&_.push(e)}function T(e,t,n){return null==e?0:function e(t,n,r,o){var l=typeof t;"undefined"!==l&&"boolean"!==l||(t=null);var s=!1;if(null===t)s=!0;else switch(l){case"string":case"number":s=!0;break;case"object":switch(t.$$typeof){case i:case a:s=!0}}if(s)return r(o,t,""===n?"."+L(t,0):n),1;if(s=0,n=""===n?".":n+":",Array.isArray(t))for(var c=0;c<t.length;c++){var u=n+L(l=t[c],c);s+=e(l,u,r,o)}else if("function"==typeof(u=null===t||"object"!=typeof t?null:"function"==typeof(u=g&&t[g]||t["@@iterator"])?u:null))for(t=u.call(t),c=0;!(l=t.next()).done;)s+=e(l=l.value,u=n+L(l,c++),r,o);else if("object"===l)throw r=""+t,Error(v(31,"[object Object]"===r?"object with keys {"+Object.keys(t).join(", ")+"}":r,""));return s}(e,"",t,n)}function L(e,t){return"object"==typeof e&&null!==e&&null!=e.key?(n=e.key,r={"=":"=0",":":"=2"},"$"+(""+n).replace(/[=:]/g,(function(e){return r[e]}))):t.toString(36);var n,r}function M(e,t){e.func.call(e.context,t,e.count++)}function R(e,t,n){var r,o,a=e.result,l=e.keyPrefix;e=e.func.call(e.context,t,e.count++),Array.isArray(e)?z(e,a,n,(function(e){return e})):null!=e&&(O(e)&&(r=e,o=l+(!e.key||t&&t.key===e.key?"":(""+e.key).replace(N,"$&/")+"/")+n,e={$$typeof:i,type:r.type,key:o,ref:r.ref,props:r.props,_owner:r._owner}),a.push(e))}function z(e,t,n,r,o){var i="";null!=n&&(i=(""+n).replace(N,"$&/")+"/"),T(e,R,t=P(t,i,r,o)),I(t)}var $={current:null};function D(){var e=$.current;if(null===e)throw Error(v(321));return e}var B={ReactCurrentDispatcher:$,ReactCurrentBatchConfig:{suspense:null},ReactCurrentOwner:j,IsSomeRendererActing:{current:!1},assign:r};t.Children={map:function(e,t,n){if(null==e)return e;var r=[];return z(e,r,null,t,n),r},forEach:function(e,t,n){if(null==e)return e;T(e,M,t=P(null,null,t,n)),I(t)},count:function(e){return T(e,(function(){return null}),null)},toArray:function(e){var t=[];return z(e,t,null,(function(e){return e})),t},only:function(e){if(!O(e))throw Error(v(143));return e}},t.Component=w,t.Fragment=l,t.Profiler=c,t.PureComponent=k,t.StrictMode=s,t.Suspense=p,t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=B,t.cloneElement=function(e,t,n){if(null==e)throw Error(v(267,e));var o=r({},e.props),a=e.key,l=e.ref,s=e._owner;if(null!=t){if(void 0!==t.ref&&(l=t.ref,s=j.current),void 0!==t.key&&(a=""+t.key),e.type&&e.type.defaultProps)var c=e.type.defaultProps;for(u in t)E.call(t,u)&&!C.hasOwnProperty(u)&&(o[u]=void 0===t[u]&&void 0!==c?c[u]:t[u])}var u=arguments.length-2;if(1===u)o.children=n;else if(1<u){c=Array(u);for(var d=0;d<u;d++)c[d]=arguments[d+2];o.children=c}return{$$typeof:i,type:e.type,key:a,ref:l,props:o,_owner:s}},t.createContext=function(e,t){return void 0===t&&(t=null),(e={$$typeof:d,_calculateChangedBits:t,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider={$$typeof:u,_context:e},e.Consumer=e},t.createElement=A,t.createFactory=function(e){var t=A.bind(null,e);return t.type=e,t},t.createRef=function(){return{current:null}},t.forwardRef=function(e){return{$$typeof:f,render:e}},t.isValidElement=O,t.lazy=function(e){return{$$typeof:h,_ctor:e,_status:-1,_result:null}},t.memo=function(e,t){return{$$typeof:m,type:e,compare:void 0===t?null:t}},t.useCallback=function(e,t){return D().useCallback(e,t)},t.useContext=function(e,t){return D().useContext(e,t)},t.useDebugValue=function(){},t.useEffect=function(e,t){return D().useEffect(e,t)},t.useImperativeHandle=function(e,t,n){return D().useImperativeHandle(e,t,n)},t.useLayoutEffect=function(e,t){return D().useLayoutEffect(e,t)},t.useMemo=function(e,t){return D().useMemo(e,t)},t.useReducer=function(e,t,n){return D().useReducer(e,t,n)},t.useRef=function(e){return D().useRef(e)},t.useState=function(e){return D().useState(e)},t.version="16.13.1"},function(e,t,n){
/*
  object-assign
  (c) Sindre Sorhus
  @license MIT
  */
var r=Object.getOwnPropertySymbols,o=Object.prototype.hasOwnProperty,i=Object.prototype.propertyIsEnumerable;e.exports=function(){try{if(!Object.assign)return!1;var e=new String("abc");if(e[5]="de","5"===Object.getOwnPropertyNames(e)[0])return!1;for(var t={},n=0;n<10;n++)t["_"+String.fromCharCode(n)]=n;if("0123456789"!==Object.getOwnPropertyNames(t).map((function(e){return t[e]})).join(""))return!1;var r={};return"abcdefghijklmnopqrst".split("").forEach((function(e){r[e]=e})),"abcdefghijklmnopqrst"===Object.keys(Object.assign({},r)).join("")}catch(o){return!1}}()?Object.assign:function(e,t){for(var n,a,l=function(e){if(null==e)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(e)}(e),s=1;s<arguments.length;s++){for(var c in n=Object(arguments[s]))o.call(n,c)&&(l[c]=n[c]);if(r){a=r(n);for(var u=0;u<a.length;u++)i.call(n,a[u])&&(l[a[u]]=n[a[u]])}}return l}},function(e,t,n){var r=n(8);function o(){}function i(){}i.resetWarningCache=o,e.exports=function(){function e(e,t,n,o,i,a){if(a!==r){var l=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw l.name="Invariant Violation",l}}function t(){return e}e.isRequired=e;var n={array:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:t,element:e,elementType:e,instanceOf:t,node:e,objectOf:t,oneOf:t,oneOfType:t,shape:t,exact:t,checkPropTypes:i,resetWarningCache:o};return n.PropTypes=n,n}},function(e,t,n){e.exports="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"},function(e,t,n){n.r(t);var r=n(0),o=n.n(r),i=n(1),a=n.n(i),l=n(2),s=n.n(l),c=n(3),u=n.n(c),d=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),f=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e};function p(e){return f({},e,{playerVars:f({},e.playerVars,{autoplay:0,start:0,end:0})})}var m=function(e){function t(e){!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t);var n=function(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}(this,(t.__proto__||Object.getPrototypeOf(t)).call(this,e));return n.onPlayerReady=function(e){return n.props.onReady(e)},n.onPlayerError=function(e){return n.props.onError(e)},n.onPlayerStateChange=function(e){switch(n.props.onStateChange(e),e.data){case t.PlayerState.ENDED:n.props.onEnd(e);break;case t.PlayerState.PLAYING:n.props.onPlay(e);break;case t.PlayerState.PAUSED:n.props.onPause(e)}},n.onPlayerPlaybackRateChange=function(e){return n.props.onPlaybackRateChange(e)},n.onPlayerPlaybackQualityChange=function(e){return n.props.onPlaybackQualityChange(e)},n.createPlayer=function(){if("undefined"!=typeof document){var e=f({},n.props.opts,{videoId:n.props.videoId});n.internalPlayer=u()(n.container,e),n.internalPlayer.on("ready",n.onPlayerReady),n.internalPlayer.on("error",n.onPlayerError),n.internalPlayer.on("stateChange",n.onPlayerStateChange),n.internalPlayer.on("playbackRateChange",n.onPlayerPlaybackRateChange),n.internalPlayer.on("playbackQualityChange",n.onPlayerPlaybackQualityChange)}},n.resetPlayer=function(){return n.internalPlayer.destroy().then(n.createPlayer)},n.updatePlayer=function(){n.internalPlayer.getIframe().then((function(e){n.props.id?e.setAttribute("id",n.props.id):e.removeAttribute("id"),n.props.className?e.setAttribute("class",n.props.className):e.removeAttribute("class")}))},n.updateVideo=function(){if(void 0!==n.props.videoId&&null!==n.props.videoId){var e=!1,t={videoId:n.props.videoId};"playerVars"in n.props.opts&&(e=1===n.props.opts.playerVars.autoplay,"start"in n.props.opts.playerVars&&(t.startSeconds=n.props.opts.playerVars.start),"end"in n.props.opts.playerVars&&(t.endSeconds=n.props.opts.playerVars.end)),e?n.internalPlayer.loadVideoById(t):n.internalPlayer.cueVideoById(t)}else n.internalPlayer.stopVideo()},n.refContainer=function(e){n.container=e},n.container=null,n.internalPlayer=null,n}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(t,e),d(t,[{key:"componentDidMount",value:function(){this.createPlayer()}},{key:"componentDidUpdate",value:function(e){var t,n;t=e,n=this.props,(t.id!==n.id||t.className!==n.className)&&this.updatePlayer(),function(e,t){return!s()(p(e.opts),p(t.opts))}(e,this.props)&&this.resetPlayer(),function(e,t){if(e.videoId!==t.videoId)return!0;var n=e.opts.playerVars||{},r=t.opts.playerVars||{};return n.start!==r.start||n.end!==r.end}(e,this.props)&&this.updateVideo()}},{key:"componentWillUnmount",value:function(){this.internalPlayer.destroy()}},{key:"render",value:function(){return a.a.createElement("div",{className:this.props.containerClassName},a.a.createElement("div",{id:this.props.id,className:this.props.className,ref:this.refContainer}))}}]),t}(a.a.Component);m.propTypes={videoId:o.a.string,id:o.a.string,className:o.a.string,containerClassName:o.a.string,opts:o.a.objectOf(o.a.any),onReady:o.a.func,onError:o.a.func,onPlay:o.a.func,onPause:o.a.func,onEnd:o.a.func,onStateChange:o.a.func,onPlaybackRateChange:o.a.func,onPlaybackQualityChange:o.a.func},m.defaultProps={id:null,className:null,opts:{},containerClassName:"",onReady:function(){},onError:function(){},onPlay:function(){},onPause:function(){},onEnd:function(){},onStateChange:function(){},onPlaybackRateChange:function(){},onPlaybackQualityChange:function(){}},m.PlayerState={UNSTARTED:-1,ENDED:0,PLAYING:1,PAUSED:2,BUFFERING:3,CUED:5},t.default=m},function(e,t,n){var r;
/**
  * @link https://github.com/gajus/sister for the canonical source repository
  * @license https://github.com/gajus/sister/blob/master/LICENSE BSD 3-Clause
  */r=function(){var e={},t={};return e.on=function(e,n){var r={name:e,handler:n};return t[e]=t[e]||[],t[e].unshift(r),r},e.off=function(e){var n=t[e.name].indexOf(e);-1!==n&&t[e.name].splice(n,1)},e.trigger=function(e,n){var r,o=t[e];if(o)for(r=o.length;r--;)o[r].handler(n)},e},e.exports=r},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r,o=(r=n(12))&&r.__esModule?r:{default:r};t.default=function(e){return new Promise((function(t){if(window.YT&&window.YT.Player&&window.YT.Player instanceof Function)t(window.YT);else{var n="http:"===window.location.protocol?"http:":"https:";(0,o.default)(n+"//www.youtube.com/iframe_api",(function(t){t&&e.trigger("error",t)}));var r=window.onYouTubeIframeAPIReady;window.onYouTubeIframeAPIReady=function(){r&&r(),t(window.YT)}}}))},e.exports=t.default},function(e,t){function n(e,t){e.onload=function(){this.onerror=this.onload=null,t(null,e)},e.onerror=function(){this.onerror=this.onload=null,t(new Error("Failed to load "+this.src),e)}}function r(e,t){e.onreadystatechange=function(){"complete"!=this.readyState&&"loaded"!=this.readyState||(this.onreadystatechange=null,t(null,e))}}e.exports=function(e,t,o){var i=document.head||document.getElementsByTagName("head")[0],a=document.createElement("script");"function"==typeof t&&(o=t,t={}),t=t||{},o=o||function(){},a.type=t.type||"text/javascript",a.charset=t.charset||"utf8",a.async=!("async"in t)||!!t.async,a.src=e,t.attrs&&function(e,t){for(var n in t)e.setAttribute(n,t[n])}(a,t.attrs),t.text&&(a.text=""+t.text),("onload"in a?n:r)(a,o),a.onload||n(a,o),i.appendChild(a)}},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=l(n(14)),o=l(n(18)),i=l(n(19)),a=l(n(20));function l(e){return e&&e.__esModule?e:{default:e}}var s=(0,r.default)("youtube-player"),c={proxyEvents:function(e){var t={},n=function(n){var r="on"+n.slice(0,1).toUpperCase()+n.slice(1);t[r]=function(t){s('event "%s"',r,t),e.trigger(n,t)}},r=!0,o=!1,a=void 0;try{for(var l,c=i.default[Symbol.iterator]();!(r=(l=c.next()).done);r=!0)n(l.value)}catch(u){o=!0,a=u}finally{try{!r&&c.return&&c.return()}finally{if(o)throw a}}return t},promisifyPlayer:function(e){var t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n={},r=function(r){t&&a.default[r]?n[r]=function(){for(var t=arguments.length,n=Array(t),o=0;o<t;o++)n[o]=arguments[o];return e.then((function(e){var t=a.default[r],o=e.getPlayerState(),i=e[r].apply(e,n);return t.stateChangeRequired||Array.isArray(t.acceptableStates)&&-1===t.acceptableStates.indexOf(o)?new Promise((function(n){e.addEventListener("onStateChange",(function r(){var o=e.getPlayerState(),i=void 0;"number"==typeof t.timeout&&(i=setTimeout((function(){e.removeEventListener("onStateChange",r),n()}),t.timeout)),Array.isArray(t.acceptableStates)&&-1!==t.acceptableStates.indexOf(o)&&(e.removeEventListener("onStateChange",r),clearTimeout(i),n())}))})).then((function(){return i})):i}))}:n[r]=function(){for(var t=arguments.length,n=Array(t),o=0;o<t;o++)n[o]=arguments[o];return e.then((function(e){return e[r].apply(e,n)}))}},i=!0,l=!1,s=void 0;try{for(var c,u=o.default[Symbol.iterator]();!(i=(c=u.next()).done);i=!0){r(c.value)}}catch(d){l=!0,s=d}finally{try{!i&&u.return&&u.return()}finally{if(l)throw s}}return n}};t.default=c,e.exports=t.default},function(e,t,n){(function(r){function o(){var e;try{e=t.storage.debug}catch(n){}return!e&&void 0!==r&&"env"in r&&(e=r.env.DEBUG),e}(t=e.exports=n(16)).log=function(){return"object"==typeof console&&console.log&&Function.prototype.apply.call(console.log,console,arguments)},t.formatArgs=function(e){var n=this.useColors;if(e[0]=(n?"%c":"")+this.namespace+(n?" %c":" ")+e[0]+(n?"%c ":" ")+"+"+t.humanize(this.diff),n){var r="color: "+this.color;e.splice(1,0,r,"color: inherit");var o=0,i=0;e[0].replace(/%[a-zA-Z%]/g,(function(e){"%%"!==e&&(o++,"%c"===e&&(i=o))})),e.splice(i,0,r)}},t.save=function(e){try{null==e?t.storage.removeItem("debug"):t.storage.debug=e}catch(n){}},t.load=o,t.useColors=function(){return!("undefined"==typeof window||!window.process||"renderer"!==window.process.type)||("undefined"!=typeof document&&document.documentElement&&document.documentElement.style&&document.documentElement.style.WebkitAppearance||"undefined"!=typeof window&&window.console&&(window.console.firebug||window.console.exception&&window.console.table)||"undefined"!=typeof navigator&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)&&parseInt(RegExp.$1,10)>=31||"undefined"!=typeof navigator&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/))},t.storage="undefined"!=typeof chrome&&void 0!==chrome.storage?chrome.storage.local:function(){try{return window.localStorage}catch(e){}}(),t.colors=["lightseagreen","forestgreen","goldenrod","dodgerblue","darkorchid","crimson"],t.formatters.j=function(e){try{return JSON.stringify(e)}catch(t){return"[UnexpectedJSONParseError]: "+t.message}},t.enable(o())}).call(this,n(15))},function(e,t){var n,r,o=e.exports={};function i(){throw new Error("setTimeout has not been defined")}function a(){throw new Error("clearTimeout has not been defined")}function l(e){if(n===setTimeout)return setTimeout(e,0);if((n===i||!n)&&setTimeout)return n=setTimeout,setTimeout(e,0);try{return n(e,0)}catch(t){try{return n.call(null,e,0)}catch(r){return n.call(this,e,0)}}}!function(){try{n="function"==typeof setTimeout?setTimeout:i}catch(e){n=i}try{r="function"==typeof clearTimeout?clearTimeout:a}catch(e){r=a}}();var s,c=[],u=!1,d=-1;function f(){u&&s&&(u=!1,s.length?c=s.concat(c):d=-1,c.length&&p())}function p(){if(!u){var e=l(f);u=!0;for(var t=c.length;t;){for(s=c,c=[];++d<t;)s&&s[d].run();d=-1,t=c.length}s=null,u=!1,function(e){if(r===clearTimeout)return clearTimeout(e);if((r===a||!r)&&clearTimeout)return r=clearTimeout,clearTimeout(e);try{r(e)}catch(t){try{return r.call(null,e)}catch(n){return r.call(this,e)}}}(e)}}function m(e,t){this.fun=e,this.array=t}function h(){}o.nextTick=function(e){var t=new Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n];c.push(new m(e,t)),1!==c.length||u||l(p)},m.prototype.run=function(){this.fun.apply(null,this.array)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=h,o.addListener=h,o.once=h,o.off=h,o.removeListener=h,o.removeAllListeners=h,o.emit=h,o.prependListener=h,o.prependOnceListener=h,o.listeners=function(e){return[]},o.binding=function(e){throw new Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(e){throw new Error("process.chdir is not supported")},o.umask=function(){return 0}},function(e,t,n){var r;function o(e){function n(){if(n.enabled){var e=n,o=+new Date,i=o-(r||o);e.diff=i,e.prev=r,e.curr=o,r=o;for(var a=new Array(arguments.length),l=0;l<a.length;l++)a[l]=arguments[l];a[0]=t.coerce(a[0]),"string"!=typeof a[0]&&a.unshift("%O");var s=0;a[0]=a[0].replace(/%([a-zA-Z%])/g,(function(n,r){if("%%"===n)return n;s++;var o=t.formatters[r];if("function"==typeof o){var i=a[s];n=o.call(e,i),a.splice(s,1),s--}return n})),t.formatArgs.call(e,a),(n.log||t.log||console.log.bind(console)).apply(e,a)}}return n.namespace=e,n.enabled=t.enabled(e),n.useColors=t.useColors(),n.color=function(e){var n,r=0;for(n in e)r=(r<<5)-r+e.charCodeAt(n),r|=0;return t.colors[Math.abs(r)%t.colors.length]}(e),"function"==typeof t.init&&t.init(n),n}(t=e.exports=o.debug=o.default=o).coerce=function(e){return e instanceof Error?e.stack||e.message:e},t.disable=function(){t.enable("")},t.enable=function(e){t.save(e),t.names=[],t.skips=[];for(var n=("string"==typeof e?e:"").split(/[\s,]+/),r=n.length,o=0;o<r;o++)n[o]&&("-"===(e=n[o].replace(/\*/g,".*?"))[0]?t.skips.push(new RegExp("^"+e.substr(1)+"$")):t.names.push(new RegExp("^"+e+"$")))},t.enabled=function(e){var n,r;for(n=0,r=t.skips.length;n<r;n++)if(t.skips[n].test(e))return!1;for(n=0,r=t.names.length;n<r;n++)if(t.names[n].test(e))return!0;return!1},t.humanize=n(17),t.names=[],t.skips=[],t.formatters={}},function(e,t){var n=1e3,r=6e4,o=60*r,i=24*o;function a(e,t,n){if(!(e<t))return e<1.5*t?Math.floor(e/t)+" "+n:Math.ceil(e/t)+" "+n+"s"}e.exports=function(e,t){t=t||{};var l,s,c=typeof e;if("string"===c&&e.length>0)return function(e){if(!((e=String(e)).length>100)){var t=/^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(e);if(t){var a=parseFloat(t[1]);switch((t[2]||"ms").toLowerCase()){case"years":case"year":case"yrs":case"yr":case"y":return 315576e5*a;case"days":case"day":case"d":return a*i;case"hours":case"hour":case"hrs":case"hr":case"h":return a*o;case"minutes":case"minute":case"mins":case"min":case"m":return a*r;case"seconds":case"second":case"secs":case"sec":case"s":return a*n;case"milliseconds":case"millisecond":case"msecs":case"msec":case"ms":return a;default:return}}}}(e);if("number"===c&&!1===isNaN(e))return t.long?a(l=e,i,"day")||a(l,o,"hour")||a(l,r,"minute")||a(l,n,"second")||l+" ms":(s=e)>=i?Math.round(s/i)+"d":s>=o?Math.round(s/o)+"h":s>=r?Math.round(s/r)+"m":s>=n?Math.round(s/n)+"s":s+"ms";throw new Error("val is not a non-empty string or a valid number. val="+JSON.stringify(e))}},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=["cueVideoById","loadVideoById","cueVideoByUrl","loadVideoByUrl","playVideo","pauseVideo","stopVideo","getVideoLoadedFraction","cuePlaylist","loadPlaylist","nextVideo","previousVideo","playVideoAt","setShuffle","setLoop","getPlaylist","getPlaylistIndex","setOption","mute","unMute","isMuted","setVolume","getVolume","seekTo","getPlayerState","getPlaybackRate","setPlaybackRate","getAvailablePlaybackRates","getPlaybackQuality","setPlaybackQuality","getAvailableQualityLevels","getCurrentTime","getDuration","removeEventListener","getVideoUrl","getVideoEmbedCode","getOptions","getOption","addEventListener","destroy","setSize","getIframe"],e.exports=t.default},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=["ready","stateChange","playbackQualityChange","playbackRateChange","error","apiChange","volumeChange"],e.exports=t.default},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r,o=(r=n(21))&&r.__esModule?r:{default:r};t.default={pauseVideo:{acceptableStates:[o.default.ENDED,o.default.PAUSED],stateChangeRequired:!1},playVideo:{acceptableStates:[o.default.ENDED,o.default.PLAYING],stateChangeRequired:!1},seekTo:{acceptableStates:[o.default.ENDED,o.default.PLAYING,o.default.PAUSED],stateChangeRequired:!0,timeout:3e3}},e.exports=t.default},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0}),t.default={BUFFERING:3,ENDED:0,PAUSED:2,PLAYING:1,UNSTARTED:-1,VIDEO_CUED:5},e.exports=t.default},function(e,t,n){var r=n(23);"string"==typeof r&&(r=[[e.i,r,""]]);n(25)(r,{hmr:!0,transform:void 0,insertInto:void 0}),r.locals&&(e.exports=r.locals)},function(e,t,n){(t=n(24)(!1)).push([e.i,".Player__container___f3NHe{\n\tposition: relative;\n\toverflow: hidden;\n}\n\n.Player__videoContainer___2TVqS{\n\tposition: absolute;\n\tleft:0;\n\ttop:0;\n\tright:0;\n\tbottom:0;\n\twidth:100%;\n\theight:100%;\n\tz-index: -1;\n\n}\n\n.Player__videoInnerContainer___3idnr{\n\twidth:100%;\n\theight:100%;\n}\n\n.Player__overlay___3alO1{\n\tposition: absolute;\n\tleft:0;\n\ttop:0;\n\tright:0;\n\tbottom:0;\n\tz-index: 5\n}\n.Player__videoIframe___3_jFK{\n\tposition: relative;\n\tleft:0;\n\ttop:0;\n\tright:0;\n\tbottom:0;\n\twidth: 100%;\n\theight: 100%;\n\tz-index:0;\n\n}",""]),t.locals={container:"Player__container___f3NHe",videoContainer:"Player__videoContainer___2TVqS",videoInnerContainer:"Player__videoInnerContainer___3idnr",overlay:"Player__overlay___3alO1",videoIframe:"Player__videoIframe___3_jFK"},e.exports=t},function(e,t,n){e.exports=function(e){var t=[];return t.toString=function(){return this.map((function(t){var n=function(e,t){var n,r,o,i=e[1]||"",a=e[3];if(!a)return i;if(t&&"function"==typeof btoa){var l=(n=a,r=btoa(unescape(encodeURIComponent(JSON.stringify(n)))),o="sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(r),"/*# ".concat(o," */")),s=a.sources.map((function(e){return"/*# sourceURL=".concat(a.sourceRoot||"").concat(e," */")}));return[i].concat(s).concat([l]).join("\n")}return[i].join("\n")}(t,e);return t[2]?"@media ".concat(t[2]," {").concat(n,"}"):n})).join("")},t.i=function(e,n,r){"string"==typeof e&&(e=[[null,e,""]]);var o={};if(r)for(var i=0;i<this.length;i++){var a=this[i][0];null!=a&&(o[a]=!0)}for(var l=0;l<e.length;l++){var s=[].concat(e[l]);r&&o[s[0]]||(n&&(s[2]?s[2]="".concat(n," and ").concat(s[2]):s[2]=n),t.push(s))}},t}},function(e,t,n){var r,o,i={},a=(r=function(){return window&&document&&document.all&&!window.atob},function(){return void 0===o&&(o=r.apply(this,arguments)),o}),l=function(e){return document.querySelector(e)},s=function(e){var t={};return function(e){if("function"==typeof e)return e();if(void 0===t[e]){var n=l.call(this,e);if(window.HTMLIFrameElement&&n instanceof window.HTMLIFrameElement)try{n=n.contentDocument.head}catch(r){n=null}t[e]=n}return t[e]}}(),c=null,u=0,d=[],f=n(26);function p(e,t){for(var n=0;n<e.length;n++){var r=e[n],o=i[r.id];if(o){o.refs++;for(var a=0;a<o.parts.length;a++)o.parts[a](r.parts[a]);for(;a<r.parts.length;a++)o.parts.push(b(r.parts[a],t))}else{var l=[];for(a=0;a<r.parts.length;a++)l.push(b(r.parts[a],t));i[r.id]={id:r.id,refs:1,parts:l}}}}function m(e,t){for(var n=[],r={},o=0;o<e.length;o++){var i=e[o],a=t.base?i[0]+t.base:i[0],l={css:i[1],media:i[2],sourceMap:i[3]};r[a]?r[a].parts.push(l):n.push(r[a]={id:a,parts:[l]})}return n}function h(e,t){var n=s(e.insertInto);if(!n)throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");var r=d[d.length-1];if("top"===e.insertAt)r?r.nextSibling?n.insertBefore(t,r.nextSibling):n.appendChild(t):n.insertBefore(t,n.firstChild),d.push(t);else if("bottom"===e.insertAt)n.appendChild(t);else{if("object"!=typeof e.insertAt||!e.insertAt.before)throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");var o=s(e.insertInto+" "+e.insertAt.before);n.insertBefore(t,o)}}function g(e){if(null===e.parentNode)return!1;e.parentNode.removeChild(e);var t=d.indexOf(e);t>=0&&d.splice(t,1)}function v(e){var t=document.createElement("style");return void 0===e.attrs.type&&(e.attrs.type="text/css"),y(t,e.attrs),h(e,t),t}function y(e,t){Object.keys(t).forEach((function(n){e.setAttribute(n,t[n])}))}function b(e,t){var n,r,o,i,a,l;if(t.transform&&e.css){if(!(i=t.transform(e.css)))return function(){};e.css=i}if(t.singleton){var s=u++;n=c||(c=v(t)),r=k.bind(null,n,s,!1),o=k.bind(null,n,s,!0)}else e.sourceMap&&"function"==typeof URL&&"function"==typeof URL.createObjectURL&&"function"==typeof URL.revokeObjectURL&&"function"==typeof Blob&&"function"==typeof btoa?(a=t,l=document.createElement("link"),void 0===a.attrs.type&&(a.attrs.type="text/css"),a.attrs.rel="stylesheet",y(l,a.attrs),h(a,l),n=l,r=j.bind(null,n,t),o=function(){g(n),n.href&&URL.revokeObjectURL(n.href)}):(n=v(t),r=S.bind(null,n),o=function(){g(n)});return r(e),function(t){if(t){if(t.css===e.css&&t.media===e.media&&t.sourceMap===e.sourceMap)return;r(e=t)}else o()}}e.exports=function(e,t){if("undefined"!=typeof DEBUG&&DEBUG&&"object"!=typeof document)throw new Error("The style-loader cannot be used in a non-browser environment");(t=t||{}).attrs="object"==typeof t.attrs?t.attrs:{},t.singleton||"boolean"==typeof t.singleton||(t.singleton=a()),t.insertInto||(t.insertInto="head"),t.insertAt||(t.insertAt="bottom");var n=m(e,t);return p(n,t),function(e){for(var r=[],o=0;o<n.length;o++){var a=n[o];(l=i[a.id]).refs--,r.push(l)}for(e&&p(m(e,t),t),o=0;o<r.length;o++){var l;if(0===(l=r[o]).refs){for(var s=0;s<l.parts.length;s++)l.parts[s]();delete i[l.id]}}}};var w,x=(w=[],function(e,t){return w[e]=t,w.filter(Boolean).join("\n")});function k(e,t,n,r){var o=n?"":r.css;if(e.styleSheet)e.styleSheet.cssText=x(t,o);else{var i=document.createTextNode(o),a=e.childNodes;a[t]&&e.removeChild(a[t]),a.length?e.insertBefore(i,a[t]):e.appendChild(i)}}function S(e,t){var n=t.css,r=t.media;if(r&&e.setAttribute("media",r),e.styleSheet)e.styleSheet.cssText=n;else{for(;e.firstChild;)e.removeChild(e.firstChild);e.appendChild(document.createTextNode(n))}}function j(e,t,n){var r=n.css,o=n.sourceMap,i=void 0===t.convertToAbsoluteUrls&&o;(t.convertToAbsoluteUrls||i)&&(r=f(r)),o&&(r+="\n/*# sourceMappingURL=data:application/json;base64,"+btoa(unescape(encodeURIComponent(JSON.stringify(o))))+" */");var a=new Blob([r],{type:"text/css"}),l=e.href;e.href=URL.createObjectURL(a),l&&URL.revokeObjectURL(l)}},function(e,t){e.exports=function(e){var t="undefined"!=typeof window&&window.location;if(!t)throw new Error("fixUrls requires window.location");if(!e||"string"!=typeof e)return e;var n=t.protocol+"//"+t.host,r=n+t.pathname.replace(/\/[^\/]*$/,"/");return e.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi,(function(e,t){var o,i=t.trim().replace(/^"(.*)"$/,(function(e,t){return t})).replace(/^'(.*)'$/,(function(e,t){return t}));return/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(i)?e:(o=0===i.indexOf("//")?i:0===i.indexOf("/")?n+i:r+i.replace(/^\.\//,""),"url("+JSON.stringify(o)+")")}))}}]);const lO=n(aO);function sO({anime:e}){const[t,n]=W.useState(null);if(xk||!(null==e?void 0:e.trailerVideo)){var r=window.innerWidth>1100?e.bannerart.large:e.bannerart.medium;return Z.jsxs(HA,{id:"container1",background:r,children:[Z.jsx(qA,{to:"/",title:"Animeflix",id:"mobilelogo",onLoad:()=>document.getElementById("mobilelogo").style.opacity=1,children:Z.jsx("img",{alt:"animeflix-logo",src:hh})}),Z.jsxs(YA,{children:[Z.jsxs(GA,{children:[Z.jsx(JA,{src:e.logoart,style:{marginBottom:e.style[0],marginLeft:e.style[1]},alt:"logo"}),Z.jsx("br",{}),Z.jsxs("strong",{children:[e.averageScore?e.averageScore:76,"% Match"]}),Z.jsx("label",{children:e.startDate?e.startDate.year:"(To Be Announced)"}),Z.jsxs("label",{children:[e.episodeNum," episodes"]})]}),Z.jsx(QA,{children:e.description.replace(/<\/?[^>]+(>|$)/g,"")}),Z.jsxs(KA,{children:[Z.jsx(KS,{anime:e}),Z.jsx(iO,{onClick:()=>n(e)})]})]}),t&&Z.jsx(pj,{anime:t,onClose:e=>n(e??null)})]})}return Z.jsx(lO,{nocookie:!0,videoId:null==e?void 0:e.trailerVideo,playerOptions:{start:(null==e?void 0:e.trailerStart)??0,loop:1,playlist:null==e?void 0:e.trailerVideo,rel:0},children:Z.jsxs(HA,{id:"container1",children:[Z.jsxs(YA,{children:[Z.jsxs(GA,{children:[Z.jsx(JA,{src:e.logoart,style:{marginBottom:e.style[0],marginLeft:e.style[1]},alt:"logo"}),Z.jsx("br",{}),Z.jsxs("strong",{children:[e.averageScore?e.averageScore:76,"% Match"]}),Z.jsx("label",{children:e.startDate?e.startDate.year:"(To Be Announced)"}),Z.jsxs("label",{children:[e.episodeNum," episodes"]})]}),Z.jsx(QA,{children:e.description.replace(/<\/?[^>]+(>|$)/g,"")}),Z.jsxs(KA,{children:[Z.jsx(KS,{anime:e}),Z.jsx(iO,{onClick:()=>n(e)})]})]}),t&&Z.jsx(pj,{anime:t,onClose:e=>n(e??null)})]})})}const cO=dh.div`
  width: 100%;
  overflow: clip;
  position: relative;
`,uO=dh.div`
  overflow: scroll hidden;
  scrollbar-width: none;
  scroll-behavior: smooth;

  ::-webkit-scrollbar {
    display: none;
  }

  
  @media (min-width: 1200px) {
    margin-top: -.5vw;
  }
`,dO=dh.div`
  width: fit-content;
  display: flex;
  padding: 1.25vw 3.5vw;
`,fO=dh.h3`
  display: flex;
  margin-left: 3.5vw;
  position: relative;
  z-index: 2;
`,pO=dh.button`
  width: 3.5vw;
  height: 100%;
  cursor: pointer;
  position: absolute;
  z-index: 3;
  color: white;
  opacity: 0;
  transform: scaleY(.9);
  background: rgba(0, 0, 0, .5);
  transition: opacity ease 200ms;

  ${e=>"left"===e.position&&Xm`
    left: 0;
  `}

  ${e=>"right"===e.position&&Xm`
    right: 0;
  `}

  ${cO}:hover & {
    opacity: 1;
  }

  @media (max-width: 800px) {
    display: none;
  }
`;var mO={},hO=bh;Object.defineProperty(mO,"__esModule",{value:!0});var gO=mO.default=void 0,vO=hO(hb()),yO=Z,bO=(0,vO.default)((0,yO.jsx)("path",{d:"M15.41 7.41 14 6l-6 6 6 6 1.41-1.41L10.83 12z"}),"ChevronLeft");gO=mO.default=bO;var wO={},xO=bh;Object.defineProperty(wO,"__esModule",{value:!0});var kO=wO.default=void 0,SO=xO(hb()),jO=Z,EO=(0,SO.default)((0,jO.jsx)("path",{d:"M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"}),"ChevronRight");kO=wO.default=EO;const CO=dh.div`
  width: 45vw;

  & + & {
    margin-left: .6rem;
    @media (max-width: 800px) {
      margin-left: .4rem;
    }
  }

  &:hover {
    z-index: 2;
  }

  button {
    height: 100%;
    cursor: pointer;
    transition: transform ease 200ms;

    @media not (hover: none){
      :hover {
        transform: scale(1.1);
      }
    }
    
  }
  background: transparent;

  img {
    max-width: 100%;
  }

  @media (min-width: 500px) {
    width: 22vw;
  }

  @media (min-width: 800px) {
    width: 18.1vw;
  }
  
  @media (min-width: 1100px) {
    width: 12.9vw;
  }
`,AO=W.memo((function({anime:e,titleLanguage:t,isLazy:n,onClick:r=(()=>{}),onContext:o=(()=>{})}){var i,a,l;return Z.jsx(CO,{onContextMenu:o,children:Z.jsxs("button",{onClick:r,className:"cardbutton","aria-label":"Anime",children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 1500px)",srcSet:null==(i=e.images)?void 0:i.large}),Z.jsx("source",{media:"(min-width: 236px)",srcSet:null==(a=e.images)?void 0:a.medium}),Z.jsx("img",{src:null==(l=e.images)?void 0:l.small,id:"imgcard",alt:e.anilistID,loading:n?"lazy":"eager"})]}),"1"===t&&Z.jsx("h3",{className:"cardname",children:Ck.trimParagraph(e.title.english||e.title.userPreferred||e.title.romaji,55,"")}),"2"===t&&Z.jsx("h3",{className:"cardname",children:Ck.trimParagraph(e.title.native||e.title.userPreferred||e.title.romaji,55,"")})]})})})),OO=dh.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 10;
  ul {
    position: absolute;
    ${({top:e,left:t})=>Xm`
      top: ${e}px;
      left: ${t}px;
    `}
    animation: ${kb} 200ms;
    min-width: 7em;
    padding: .5rem 0;
    color: #777;
    text-align: left;
    list-style: none;
    background-color: #242424;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: 5px;
    @media (pointer:none), (pointer:coarse) {
      width: fit-content;
    }
  }
  ul li {
    display: block;
    width: 100%;
    padding: .25rem 1.5rem;
    clear: both;
    line-height: 2;
    font-weight: 400;
    color: #848484;
    text-align: inherit;
    white-space: nowrap;
    vertical-align: middle;
    background-color: transparent;
    border: 0;
  }
  /* hover */
  ul li:hover {
    cursor:pointer;
    color: #adadad; 
    text-decoration: none; 
    background-color: #2e2e2e;
  }
`,NO=dh.ul`
  position: fixed;
  z-index: 10;
  animation: ${kb} 200ms;
  width: 100%;
  bottom: 0;
  font-size: 2rem;
  color: #777;
  text-align: center;
  list-style: none;
  background-color: #242424;
  background-clip: padding-box;
  border-radius: 5px;
`,_O=dh.li`
  display: block;
  width: 100%;
  padding: .25rem 1.5rem;
  clear: both;
  line-height: 2.5;
  font-weight: 400;
  color: #848484;
  text-align: inherit;
  white-space: nowrap;
  background-color: transparent;
  border: 0;
  &:hover {
    cursor:pointer;
    color: #adadad; 
    text-decoration: none; 
    background-color: #2e2e2e;
  }
`;function PO({points:e,clicked:t,animes:n,onCallback:r=(()=>{}),scale:o=1.1,watching:i,setClicked:a,setSelectedAnime:l}){const[s,c]=W.useState();var u=localStorage.getItem("token"),d=JSON.parse(localStorage.getItem("folders"))||["My List"];async function f(){var t=null==e?void 0:e.target.alt,n=JSON.parse(localStorage.getItem("recentlywatched"))||[];const o=n.findIndex((e=>Number(e)===Number(t)));n.splice(o,1),localStorage.setItem("recentlywatched",JSON.stringify(n)),a(!1),u&&Ek.set(u,"recentlywatched",n),r()}function p(){var t=JSON.parse(localStorage.getItem(`${null==e?void 0:e.target.alt}`));if(t)return window.location.href=`/watch/${t.episodeId}/${t.position}`;var r=n.find((t=>Number(t.anilistID)===Number(e.target.alt)));l(r)}function m(){var t=JSON.parse(localStorage.getItem(`${null==e?void 0:e.target.alt}`));return`Watch Episode ${(null==t?void 0:t.epNum)||1}`}function h(t){var n=JSON.parse(localStorage.getItem(t))||[];return null==n?void 0:n.find((t=>Number(t)===Number(e.target.alt)))}function g(t){var n=JSON.parse(localStorage.getItem(t))||[];n.find((t=>Number(t)===Number(e.target.alt)))?(n=n.filter((t=>Number(t)!==Number(e.target.alt))),u&&Ek.set(u,`folders.${t}`,n),r(t)):(n.push(Number(e.target.alt)),u&&Ek.set(u,`folders.${t}`,n)),localStorage.setItem(t,JSON.stringify(n))}return W.useEffect((()=>{var n=null==e?void 0:e.target;if(n){var r=n.parentNode.parentNode.querySelector(".epname"),i=n.parentNode.parentNode.querySelector("#watchbar");t?(n.style.filter="brightness(50%)",n.parentNode.parentNode.querySelector(".cardname").style.opacity=1,r&&(r.style.opacity=1),i&&(i.style.opacity=1),n.parentNode.parentNode.style.transform=`scale(${o})`):(n.style.filter="",n.parentNode.parentNode.querySelector(".cardname").style.opacity="",r&&(r.style.opacity=""),i&&(i.style.opacity=""),n.parentNode.parentNode.style.transform="")}}),[t]),t?("string"==typeof d&&(d=["My List"]),Z.jsxs(Z.Fragment,{children:[Z.jsx(bk,{children:Z.jsx(OO,{top:e.y,left:e.x,children:Z.jsxs("ul",{children:[i&&Z.jsxs("li",{onClick:f,children:[Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"1.1em",height:"auto",marginRight:"1rem"},children:Z.jsx("path",{d:"M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"})}),"Mark As Watched"]}),Z.jsxs("li",{style:{position:"relative"},onMouseOver:()=>c(!0),onMouseLeave:()=>c(!1),children:[Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"1.1em",height:"auto",marginRight:"1rem"},children:Z.jsx("path",{d:"M4 10.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zm0-6c-.83 0-1.5.67-1.5 1.5S3.17 7.5 4 7.5 5.5 6.83 5.5 6 4.83 4.5 4 4.5zm0 12c-.83 0-1.5.68-1.5 1.5s.68 1.5 1.5 1.5 1.5-.68 1.5-1.5-.67-1.5-1.5-1.5zM7 19h14v-2H7v2zm0-6h14v-2H7v2zm0-8v2h14V5H7z"})}),"Add To List",Z.jsx(vb,{style:{fontSize:"1em",position:"absolute",right:"5px",top:"27%",color:"#555",pointerEvents:"none"}}),s&&Z.jsx(OO,{top:"0",left:"0",style:{top:"-8%",left:"98%"},children:Z.jsx("ul",{style:{left:0,top:0,width:"105%"},children:d.map(((e,t)=>Z.jsxs("li",{style:{position:"relative"},onClick:()=>g(e),children:[e," ",h(e)&&Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"1.1em",height:"auto",position:"absolute",right:"1rem",top:"20%"},children:Z.jsx("path",{d:"M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"})})]},t)))})})]}),Z.jsxs("li",{onClick:p,children:[Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"2 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"1.1em",height:"auto",marginRight:"1rem"},children:Z.jsx("path",{d:"M8 5v14l11-7z"})}),m()]})]})})}),Z.jsxs(wk,{style:{position:"absolute",top:0,left:0,width:"100%",height:"100%"},children:[Z.jsx("div",{style:{width:"100%",height:"100%"},onClick:()=>{a(!1),c(!1)}}),Z.jsxs(NO,{children:[i&&Z.jsxs(_O,{onClick:f,children:[Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"2rem",height:"auto",marginRight:"1rem"},children:Z.jsx("path",{d:"M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"})}),"Mark As Watched"]}),Z.jsxs(_O,{style:{position:"relative"},onClick:()=>c(!0),children:[Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"2rem",height:"auto",marginRight:"1rem"},children:Z.jsx("path",{d:"M4 10.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zm0-6c-.83 0-1.5.67-1.5 1.5S3.17 7.5 4 7.5 5.5 6.83 5.5 6 4.83 4.5 4 4.5zm0 12c-.83 0-1.5.68-1.5 1.5s.68 1.5 1.5 1.5 1.5-.68 1.5-1.5-.67-1.5-1.5-1.5zM7 19h14v-2H7v2zm0-6h14v-2H7v2zm0-8v2h14V5H7z"})}),"Add To a List",Z.jsx(vb,{style:{fontSize:"1em",position:"absolute",right:"5px",top:"35%",color:"#555",pointerEvents:"none"}})]}),Z.jsxs(_O,{onClick:p,children:[Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"2 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"2rem",height:"auto",marginRight:"1rem"},children:Z.jsx("path",{d:"M8 5v14l11-7z"})}),m()]})]}),s&&Z.jsx(NO,{children:d.map((e=>Z.jsxs(_O,{style:{position:"relative",textAlign:"left"},onClick:()=>{g(e),c(!1)},children:[e," ",h(e)&&Z.jsx("svg",{className:"MuiSvgIcon-root",focusable:"false",viewBox:"0 0 20 20","aria-hidden":"true",fill:"#848484",style:{width:"2rem",height:"auto",position:"absolute",right:"1.5rem",top:"27%"},children:Z.jsx("path",{d:"M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"})})]})))})]})]})):null}const IO=()=>{const[e,t]=W.useState(!1),[n,r]=W.useState({x:0,y:0});return W.useEffect((()=>{const e=()=>t(!1);return xk||document.addEventListener("click",e),()=>{document.removeEventListener("click",e)}}),[]),{clicked:e,setClicked:t,points:n,setPoints:r}},TO=W.memo((function({title:e,animes:t=[],customURL:n}){const r=W.useRef(),[o,i]=W.useState(),[a,l]=W.useState(),[s,c]=W.useState(null);var u=JSON.parse(localStorage.getItem("settings"));const{clicked:d,setClicked:f,points:p,setPoints:m}=IO();function h(e=!0){const t=window.innerWidth,n=r.current.scrollWidth,s=n/(n/t)-.04*t*2;r.current.scrollBy(e?s:-s,0),e?(o||i(!0),r.current.scrollLeft+s+r.current.clientWidth>=n&&l(!1)):(a||l(!0),r.current.scrollLeft-s<=0&&i(!1))}return W.useEffect((()=>{r.current.scrollWidth>window.innerWidth&&l(!0)}),[]),Z.jsxs(Z.Fragment,{children:[e&&Z.jsxs("div",{onClick:()=>window.location.href=n,style:{display:"flex",cursor:"pointer",width:"fit-content"},children:[Z.jsx(fO,{children:e}),Z.jsx(kO,{style:{color:"gray",marginTop:".1em",marginBottom:"-.2em",verticalAlign:"bottom",fontSize:"1.17em"}})]}),Z.jsxs(cO,{children:[o&&Z.jsx(pO,{"aria-label":"Go Left",type:"button",position:"left",onClick:()=>h(!1),children:Z.jsx(gO,{style:{fontSize:"3vw"}})}),a&&Z.jsx(pO,{"aria-label":"Go Right",type:"button",position:"right",onClick:()=>h(),children:Z.jsx(kO,{style:{fontSize:"3vw"}})}),Z.jsx(uO,{ref:r,children:Z.jsx(dO,{children:t.map(((e,t)=>Z.jsx(AO,{anime:e,isLazy:t>10,titleLanguage:(null==u?void 0:u.titlelang)?u.titlelang:"1",onClick:()=>c(e),onContext:e=>{e.preventDefault(),f(!d),m({x:e.pageX,y:e.pageY,target:e.target})}},t)))})})]}),s&&Z.jsx(pj,{anime:s,onClose:e=>c(e??null)}),Z.jsx(PO,{points:p,clicked:d,animes:t,setClicked:f,setSelectedAnime:c})]})})),LO=dh.div`
  width: 100%;
  overflow: clip;

  position: relative;
`,MO=dh.div`
  overflow: scroll hidden;
  scrollbar-width: none;
  scroll-behavior: smooth;

  ::-webkit-scrollbar {
    display: none;
  }

  
  @media (min-width: 1200px) {
    margin-top: -.5vw;
  }
`,RO=dh.div`
  width: fit-content;
  display: flex;
  padding: 1.25vw 3.5vw;
`,zO=dh.h3`
  margin-left: 3.5vw;
  position: relative;
  z-index: 2;
`,$O=dh.button`
  width: 3.5vw;
  height: 100%;
  cursor: pointer;
  position: absolute;
  z-index: 3;
  color: white;
  opacity: 0;
  transform: scaleY(.9);
  background: rgba(0, 0, 0, .5);
  transition: opacity ease 200ms;

  ${e=>"left"===e.position&&Xm`
    left: 0;
  `}

  ${e=>"right"===e.position&&Xm`
    right: 0;
  `}

  ${LO}:hover & {
    opacity: 1;
  }

  @media (max-width: 800px) {
    display: none;
  }
`,DO=dh.div`
  width: 45vw;

  & + & {
    margin-left: .6rem;
    @media (max-width: 800px) {
      margin-left: .4rem;
    }
  }
  
  &:hover {
    z-index: 2;
  }

  button {
    height: 100%;
    cursor: pointer;
    transition: transform ease 200ms;

    @media not (hover: none){
      :hover {
        transform: scale(1.1);
      }
    }
  }
  background: transparent;

  img {
    max-width: 100%;
  }

  @media (min-width: 500px) {
    width: 22vw;
  }

  @media (min-width: 800px) {
    width: 18.1vw;
  }
  
  @media (min-width: 1100px) {
    width: 12.9vw;
  }
`;function BO({anime:e,titleLanguage:t,onClick:n=(()=>{}),onContext:r=(()=>{})}){var o,i,a,l,s,c,u,d=JSON.parse(localStorage.getItem(`${e.anilistID}`)),f=null==d?void 0:d.episodes.find((e=>d.episodeId===e.episodeId));return Z.jsx(DO,{onContextMenu:r,children:Z.jsxs("button",{onClick:n,id:e.anilistID,className:"cardbutton",children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 1500px)",srcSet:null==(o=e.images)?void 0:o.large}),Z.jsx("source",{media:"(min-width: 236px)",srcSet:null==(i=e.images)?void 0:i.medium}),Z.jsx("img",{src:null==(a=e.images)?void 0:a.small,id:"imgcard",alt:e.anilistID})]}),"1"===t&&Z.jsx("h3",{className:"cardname",children:Ck.trimParagraph((null==(l=e.title)?void 0:l.english)||(null==(s=e.title)?void 0:s.userPreferred)||e.title.romaji,55,"")}),"2"===t&&Z.jsx("h3",{className:"cardname",children:Ck.trimParagraph((null==(c=e.title)?void 0:c.native)||(null==(u=e.title)?void 0:u.userPreferred)||e.title.romaji,55,"")}),f&&Z.jsxs(W.Fragment,{children:[Z.jsx("p",{className:"epname",children:d&&`Episode ${d.epNum}`}),Z.jsx("div",{id:"watchbar",style:{width:`${Math.round(f.position/f.outof*100)}%`}})]})]})})}const FO=W.memo((function({title:e,animes:t=[],callback:n=(()=>{})}){const r=W.useRef(),[o,i]=W.useState(),[a,l]=W.useState(),[s,c]=W.useState(null);var u=JSON.parse(localStorage.getItem("settings"));const{clicked:d,setClicked:f,points:p,setPoints:m}=IO();function h(e=!0){const t=window.innerWidth,n=r.current.scrollWidth,s=n/(n/t)-.04*t*2;r.current.scrollBy(e?s:-s,0),e?(o||i(!0),r.current.scrollLeft+s+r.current.clientWidth>=n&&l(!1)):(a||l(!0),r.current.scrollLeft-s<=0&&i(!1))}return W.useEffect((()=>{r.current.scrollWidth>window.innerWidth&&l(!0)}),[]),Z.jsxs(Z.Fragment,{children:[e&&Z.jsx(zO,{children:e}),Z.jsxs(LO,{children:[o&&Z.jsx($O,{"aria-label":"Go Left",type:"button",position:"left",onClick:()=>h(!1),children:Z.jsx(gO,{style:{fontSize:"3vw"}})}),a&&Z.jsx($O,{"aria-label":"Go Right",type:"button",position:"right",onClick:()=>h(),children:Z.jsx(kO,{style:{fontSize:"3vw"}})}),Z.jsx(MO,{ref:r,children:Z.jsx(RO,{children:t.map(((e,t)=>Z.jsx(BO,{titleLanguage:(null==u?void 0:u.titlelang)?u.titlelang:"1",anime:e,onClick:()=>c(e),onContext:e=>{e.preventDefault(),f(!d),m({x:e.pageX,y:e.pageY,target:e.target})}},t)))})})]}),s&&Z.jsx(pj,{anime:s,onClose:e=>{c(e??null),document.body.style.overflowY="visible"}}),Z.jsx(PO,{watching:!0,points:p,clicked:d,onCallback:n,animes:t,setClicked:f,setSelectedAnime:c})]})})),UO=dh.div`
  width: 100%;
  overflow: clip;
  position: relative;
`,WO=dh.div`
  overflow: scroll hidden;
  scrollbar-width: none;
  scroll-behavior: smooth;

  ::-webkit-scrollbar {
    display: none;
  }
`,VO=dh.div`
  width: fit-content;
  display: flex;
  padding: 1.25vw 3.5vw;
`,HO=dh.h3`
  margin-left: 3.5vw;
  position: relative;
  z-index: 2;
`,qO=dh.button`
  width: 3.5vw;
  height: 100%;
  cursor: pointer;
  position: absolute;
  z-index: 3;
  color: white;
  opacity: 0;
  transform: scaleY(.9);
  background: rgba(0, 0, 0, .5);
  transition: opacity ease 200ms;

  ${e=>"left"===e.position&&Xm`
    left: 0;
  `}

  ${e=>"right"===e.position&&Xm`
    right: 0;
  `}

  ${UO}:hover & {
    opacity: 1;
  }

  @media (max-width: 800px) {
    display: none;
  }
`,YO=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;

  ${e=>e.opening&&Xm`
    animation: ${Sb} 400ms;
  `}

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}
`,JO=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);
`,GO=dh.div`
  line-height: 1.5;
  height: fit-content;
  border-radius: .5rem;
  background: transparent;
  ${e=>e.opening&&Xm`
    animation: ${kb} 400ms;
  `}

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}
`,QO=dh.div`
  width: 100%;
  overflow: clip;
  position: relative;
`,KO=dh.div`
  overflow: scroll hidden;
  scrollbar-width: none;
  scroll-behavior: smooth;

  ::-webkit-scrollbar {
    display: none;
  }
`,XO=dh.div`
  width: fit-content;
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
`,ZO=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (max-width: 700px) {
    width: 42vw;
    height: 62vw;
  }

  @media (min-width: 1300px) {
    width: ${15}vw;
    height: ${22}vw;
  }
`;function eN({animes:e=[]}){const t=W.useRef(),[n,r]=W.useState(null);return Z.jsxs(Z.Fragment,{children:[Z.jsx(QO,{children:Z.jsx(KO,{ref:t,children:Z.jsx(XO,{id:"quitzone",children:e.map(((e,t)=>{var n,o,i;return Z.jsx(ZO,{children:Z.jsxs("button",{onClick:()=>r(e),className:"cardbutton",children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 236px)",srcSet:null==(o=e.images)?void 0:o.medium}),Z.jsx("img",{src:null==(i=e.images)?void 0:i.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english?e.title.english:e.title.romaji})]})},t)}))})})}),n&&Z.jsx(pj,{anime:n,onClose:e=>r(e??null)})]})}function tN({collection:e,onClose:t,openAnimation:n=!0}){const r=W.useRef(),[o,i]=W.useState(!1);function a(e){e||window.history.replaceState({},"Main Page",window.location.pathname),i(!0),setTimeout((()=>{t(),i(!1)}),380)}return W.useEffect((()=>{const e=e=>{"quitzone"===e.target.id&&a()},t=e=>{a(!0)};return window.addEventListener("popstate",t),document.addEventListener("mousedown",e),()=>{window.removeEventListener("popstate",t),document.removeEventListener("mousedown",e)}}),[]),W.useEffect((()=>(document.body.style.overflow="hidden",window.history.pushState({},"",`${window.location.pathname}?collection`),()=>document.body.style.overflow="auto")),[]),mu.createPortal(Z.jsx(YO,{id:"quitzone",closing:o,opening:n,children:Z.jsx(JO,{id:"quitzone",children:Z.jsx(GO,{ref:r,closing:o,opening:n,children:Z.jsx(eN,{animes:e.animes})})})}),document.getElementById("modal-root"))}function nN({animes:e=[]}){const t=W.useRef(),[n,r]=W.useState(),[o,i]=W.useState(!0),[a,l]=W.useState(null);function s(e=!0){const a=window.innerWidth,l=t.current.scrollWidth,s=l/(l/a)-.04*a*2;t.current.scrollBy(e?s:-s,0),e?(n||r(!0),t.current.scrollLeft+s+t.current.clientWidth>=l&&i(!1)):(o||i(!0),t.current.scrollLeft-s<=0&&r(!1))}return Z.jsxs(Z.Fragment,{children:[Z.jsxs("div",{onClick:()=>window.location.href="/collections",style:{display:"flex",cursor:"pointer"},children:[Z.jsx(HO,{children:"Anime Collections"}),Z.jsx(kO,{style:{color:"gray",marginTop:".1em",marginBottom:"-.2em",verticalAlign:"bottom",fontSize:"1.17em"}})]}),Z.jsxs(UO,{children:[n&&Z.jsx(qO,{type:"button",position:"left",onClick:()=>s(!1),children:Z.jsx(gO,{style:{fontSize:"3vw"}})}),o&&Z.jsx(qO,{type:"button",position:"right",onClick:()=>s(),children:Z.jsx(kO,{style:{fontSize:"3vw"}})}),Z.jsx(WO,{ref:t,children:Z.jsx(VO,{children:e.map(((e,t)=>Z.jsx(AO,{anime:e,onClick:()=>l(e),onContext:e=>{e.preventDefault()}},t)))})})]}),a&&Z.jsx(tN,{collection:a,onClose:e=>l(e??null)})]})}var rN={},oN=bh;Object.defineProperty(rN,"__esModule",{value:!0});var iN=rN.default=void 0,aN=oN(hb()),lN=Z,sN=(0,aN.default)((0,lN.jsx)("path",{d:"M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-1.29 1.29c-.63.63-.19 1.71.7 1.71h13.17c.89 0 1.34-1.08.71-1.71L18 16z"}),"NotificationsRounded");iN=rN.default=sN;var cN={},uN=bh;Object.defineProperty(cN,"__esModule",{value:!0});var dN=cN.default=void 0,fN=uN(hb()),pN=Z,mN=(0,fN.default)((0,pN.jsx)("path",{d:"m16 5-1.42 1.42-1.59-1.59V16h-1.98V4.83L9.42 6.42 8 5l4-4 4 4zm4 5v11c0 1.1-.9 2-2 2H6c-1.11 0-2-.9-2-2V10c0-1.11.89-2 2-2h3v2H6v11h12V10h-3V8h3c1.1 0 2 .89 2 2z"}),"IosShare");dN=cN.default=mN;const hN=dh.div`
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 10;
  position: fixed;
  background: rgba(0, 0, 0, .5);
  overflow: auto;

  animation: ${Sb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${Eb} 400ms;
  `}
`,gN=dh.div`
  display: flex;
  justify-content: center;
  padding: clamp(1rem, 2vw, 3rem);
`,vN=dh.div`
  width: clamp(30rem, 25vw, 50rem);
  line-height: 1.5;
  margin-top: 30vh;
  position: relative;
  border-radius: .5rem;
  background: #181818;
  animation: ${kb} 400ms;

  ${e=>e.closing&&Xm`
    animation: ${jb} 400ms;
  `}
`;function yN({onClose:e}){const t=W.useRef(),[n,r]=W.useState(!1);function o(){r(!0),localStorage.setItem("domainnotif",!0),setTimeout((()=>{e(),r(!1)}),380)}return W.useEffect((()=>{const e=e=>{t.current.contains(e.target)||o()};return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]),W.useEffect((()=>(document.body.style.overflow="hidden",()=>document.body.style.overflow="auto")),[]),mu.createPortal(Z.jsx(hN,{closing:n,children:Z.jsx(gN,{children:Z.jsxs(vN,{ref:t,closing:n,children:[Z.jsx(ij,{onClick:o}),Z.jsxs("div",{style:{padding:"3rem"},children:[Z.jsxs("p",{style:{display:"flex",alignItems:"center"},children:["Official Domains ",Z.jsx("img",{style:{height:"1.3em"},src:"https://cdn.discordapp.com/emojis/1063796785744715846.webp?size=original&quality=lossless"})]}),Z.jsx("br",{}),Z.jsxs("p",{style:{fontSize:"80%"},children:["Hello! We would like to remind you to bookmark our ",Z.jsx("a",{style:{color:"LinkText"},target:"_blank",href:"https://animeflix.domains",children:"domain list page"})," so you can stay up to date on official mirror sites!",Z.jsx("br",{}),Z.jsx("br",{}),"If you have any issues, feel free to join our ",Z.jsx("strong",{style:{cursor:"pointer"},onClick:()=>window.location.href="https://discord.gg/SKcb2C7HjH",children:"Discord"})," server for support!"]})]})]})})}),document.getElementById("modal-root"))}function bN(){const[e,t]=W.useState([]),[n,r]=W.useState(),[o,i]=W.useState(),[a,l]=W.useState(),[s,c]=W.useState(sessionStorage.getItem("animeinfo")),[u,d]=W.useState(!1),[f,p]=W.useState(!localStorage.getItem("domainnotif")),m=JSON.parse(localStorage.getItem("settings"))||{};return W.useEffect((()=>{(function(){var e;const n=JSON.parse(sessionStorage.getItem("@animeflix/home"));if(n){t(n.rows),r(n.featured);const o=localStorage.getItem("recentlywatched");return o&&o!==JSON.stringify(null==(e=null==n?void 0:n.recently)?void 0:e.map((e=>e.anilistID)))?Ek.idsToInfo(o).then((e=>{sessionStorage.setItem("@animeflix/home",JSON.stringify({featured:n.featured,rows:n.rows,recently:e})),i(e)})):i(n.recently),!0}return!1})()||async function(){d(!0);const e=await Ek.getTrending().catch((e=>{if(e.message.includes("Failed to fetch"))return hd.error("Couldn't connect to Animeflix servers! Try again later.",{duration:1e5,style:{background:"#333",color:"#fff"}})})),n=e.featured[Math.floor(Math.random()*e.featured.length)],o=[{title:"Trending Anime",customURL:"/trending",animes:e.trending},{title:"Popular Anime",customURL:"/popular",animes:await Ek.getPopular()},{title:"Currently Airing",customURL:"/schedule",animes:await Ek.getAiring()}];var a,l=localStorage.getItem("recentlywatched");l&&(a=await Ek.idsToInfo(l)),window.addEventListener("updateData",(async e=>{var t;if(!(null==(t=e.user)?void 0:t.newload)){var n=localStorage.getItem("recentlywatched");n&&(a=await Ek.idsToInfo(n)),i(a)}})),sessionStorage.setItem("@animeflix/home",JSON.stringify({rows:o,featured:n,recently:a})),t(o),r(n),a&&i(a),d(!1)}()}),[]),W.useEffect((()=>{window.location.search.includes("?anime")&&!sessionStorage.getItem("animeinfo")&&Ek.getBySlug(window.location.search.split("anime=")[1]).then((e=>{c(JSON.stringify(e))}));var e=/iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase()),t=window.matchMedia("(display-mode: standalone)").matches||!0===window.navigator.standalone,n=/android/.test(window.navigator.userAgent.toLowerCase());if(e&&!t)var r=hd(Z.jsxs("span",{onClick:()=>hd.dismiss(r),children:["Please install Animeflix as a webapp for better user experience.",Z.jsx("br",{}),"Tap the ",Z.jsx(dN,{}),' and then "Add to Homescreen".']}),{duration:1e4,icon:Z.jsx(iN,{}),position:"bottom-center",style:{background:"#333",color:"#fff"}});else if(n&&!t){var o=!1;window.addEventListener("beforeinstallprompt",(e=>{if(!o)var t=hd(Z.jsxs("span",{onClick:async()=>{e.prompt(),hd.dismiss(t),o=!0,await e.userChoice,e=null},children:["Please install Animeflix as a webapp for better user experience. ",Z.jsx("strong",{children:"Tap this notification to install"}),"."]}),{duration:1e4,icon:Z.jsx(iN,{}),position:"bottom-center",style:{background:"#333",color:"#fff"}})}))}}),[]),W.useEffect((()=>{async function e(){if((document.documentElement.scrollTop+document.body.scrollTop)/(document.documentElement.scrollHeight-document.documentElement.clientHeight)>.8&&!a){document.removeEventListener("scroll",e);const t=await Ek.getCollection();l(t)}}return document.addEventListener("scroll",e),()=>document.removeEventListener("scroll",e)}),[]),Z.jsxs(W.Fragment,{children:[Z.jsx(VA,{loading:u}),f&&Z.jsx(yN,{onClose:()=>{p(!1)}}),!u&&function(){if(n&&e)return Z.jsxs(W.Fragment,{children:[Z.jsx(sO,{anime:n}),Z.jsxs(DA,{children:[(null==o?void 0:o.length)>=1&&("true"===m.continuewatching||!m.continuewatching)&&Z.jsx(BA,{children:Z.jsx(FO,{title:"Continue Watching",animes:o,callback:()=>{const e=JSON.parse(sessionStorage.getItem("@animeflix/home")),t=localStorage.getItem("recentlywatched");Ek.idsToInfo(t).then((t=>{sessionStorage.setItem("@animeflix/home",JSON.stringify({featured:e.featured,rows:e.rows,recently:t})),i(t)}))}})}),e.map(((e,t)=>Z.jsx(BA,{children:Z.jsx(TO,{customURL:e.customURL,title:e.title,animes:e.animes})},t))),Z.jsx(BA,{children:Z.jsx(nN,{animes:a})},"collection")]}),s&&Z.jsx(pj,{anime:JSON.parse(s),openAnimation:!1,onClose:e=>{c(e?JSON.stringify(e):null),sessionStorage.removeItem("animeinfo")}})]})}()]})}const wN=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,xN=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`;function kN(){const{genre:e}=bp(),t=W.useRef(),[n,r]=W.useState([]),[o,i]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:a,setClicked:l,points:s,setPoints:c}=IO();var[u,d]=W.useState(0),f=!1;async function p(){var n;const i=Math.abs(window.scrollY/((null==(n=null==t?void 0:t.current)?void 0:n.clientHeight)-window.innerHeight));if(u>9&&(u=0),!f&&!o&&i>.8){f=!0;const t=await Ek.getGenre(e,u);r((e=>null==e?void 0:e.concat(t))),d(u+1)}}return W.useEffect((()=>{!async function(){r(await Ek.getGenre(e,u))}()}),[e]),W.useEffect((()=>(document.addEventListener("scroll",p),()=>document.removeEventListener("scroll",p)))),!1===n&&visualViewport?Z.jsx("p",{style:{textAlign:"center",marginTop:"40vh"},children:"No Results Found"}):Z.jsxs(Z.Fragment,{children:[Z.jsxs(wN,{ref:t,children:[null==n?void 0:n.map(((e,t)=>{var n,r,o;return Z.jsx(xN,{onContextMenu:e=>{"imgcard"===e.target.id&&(e.preventDefault(),l(!a),c({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>i(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(o=e.images)?void 0:o.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),o&&Z.jsx(pj,{anime:o,onClose:e=>{i(e??null),sessionStorage.removeItem("animeinfo")}})]}),Z.jsx(PO,{points:s,clicked:a,animes:n,setClicked:l,setSelectedAnime:i})]})}dh.div`
  z-index: 10;
  ul {
    position: absolute;
    ${({top:e,left:t})=>Xm`
      top: ${e}px;
      left: ${t}px;
    `}
    animation: ${kb} 200ms;
    min-width: 15rem;
    padding: .5rem 0;
    margin: .125rem 0 0;
    font-size: 2rem;
    color: #777;
    text-align: left;
    list-style: none;
    background-color: #242424;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: 5px;
    @media (pointer:none), (pointer:coarse) {
      width: fit-content;
    }
  }
  ul li {
    display: block;
    width: 100%;
    padding: .25rem 1.5rem;
    clear: both;
    line-height: 2;
    font-weight: 400;
    color: #848484;
    text-align: inherit;
    white-space: nowrap;
    background-color: transparent;
    border: 0;
  }
  /* hover */
  ul li:hover {
    cursor:pointer;
    color: #adadad; 
    text-decoration: none; 
    background-color: #2e2e2e;
  }
`,dh.ul`
  position: fixed;
  z-index: 10;
  animation: ${kb} 200ms;
  width: 100%;
  bottom: 0;
  font-size: 2rem;
  color: #777;
  text-align: center;
  list-style: none;
  background-color: #242424;
  background-clip: padding-box;
  border-radius: 5px;
`,dh.li`
  display: block;
  width: 100%;
  padding: .25rem 1.5rem;
  clear: both;
  line-height: 2.5;
  font-weight: 400;
  color: #848484;
  text-align: inherit;
  white-space: nowrap;
  background-color: transparent;
  border: 0;
  &:hover {
    cursor:pointer;
    color: #adadad; 
    text-decoration: none; 
    background-color: #2e2e2e;
  }
`;const SN=dh.div`
  display: inline-flex;
  flex-wrap: wrap;
  padding: 3.5vw;
  padding-top: 0;

  animation: ${Sb} 1000ms;

  @media (max-width: 1200px) {
    justify-content: center;
  }
`,jN=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`,EN=dh.input`
  background: #242424;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 7vh;
  font-size: 1.5rem;
  border: 2px solid #333;
  width: calc(100vw - 1.6vh);
  line-height: 50px;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .2vh;

  @media (min-width: 600px) {
    display: none;
  }

  &:focus {
    outline: 2px solid #444;
  }

  &:-webkit-autofill,
  &:-webkit-autofill:focus {
      transition: background-color 600000s 0s, color 600000s 0s;
  }
  &[data-autocompleted] {
      background-color: transparent !important;
  }
`;dh.input`
  background: #242424;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 5rem;
  font-size: 1.5rem;
  border: 2px solid #333;
  width: 20vw;
  line-height: 50px;
  padding: .5vh;
  margin: .8vh;
  margin-bottom: .1vh;
  display: block;

  @media (max-width: 600px) {
    display: none;
  }
`;const CN=dh.form`
  display: flex;
  padding: 4.5vw;
  padding-bottom: 0;
  margin-top: clamp(2rem, 1vw, 3rem);

  
  @media (max-width: 600px) {
    display: flex;
    justify-content: center;
    width: calc(100vw - 1.6vh);
    padding-top: .5rem;
    margin-top: 0;
    margin: auto;
  }
`,AN=dh.div`
  display: inline-block;
  float: left;
  box-sizing: border-box;
  padding-right: clamp(.2rem, 1vw, 10px);
`,ON=dh.div`
  position: relative;
`,NN=dh.ul`
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 99;
  float: left;
  padding: 0.5rem 0.5rem;
  margin: 0.125rem 0 0;
  font-size: 1.2em;
  width: 100%;
  font-size: 0.8em;
  color: #777;
  text-align: left;
  list-style: none;
  background-color: #242424;
  background-clip: padding-box;
  border: 1px solid rgba(0,0,0, 0.15);
  border-radius: 5px;
  display: none;

  li label  { 
    transition: all .2s; 
    font-size: 1.05em;
  }
  
  li > input:checked ~ label  { 
    background-color: transparent; 
    color: #e11212;
  }

  max-height: 38vh;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none
  }
`,_N=dh.li`
  -webkit-tap-highlight-color: transparent;
  font-weight: 400;
  line-height: 1.5;
  font-size: .8em;
  color: #777;
  list-style: none;
  box-sizing: border-box;
  display: flex;
  width: 100%;

  label {
    display: block; 
    color: #777; 
    margin: 0; 
    padding: 2px 5px; 
    overflow: hidden; 
    text-overflow: ellipsis; 
    white-space: nowrap;
  }

  input {
    list-style: none;
    margin: 0;
    overflow: visible;
    box-sizing: border-box;
    padding: 0;

    cursor: default;
    appearance: auto;
    box-sizing: border-box;
    margin: 0px 3px 0px 5px;
    padding: initial;
    border: initial;
    accent-color: #e11212;

    @media (max-width: 600px) {
      width: 1.2em;
      margin: 0;
    }
  }
`,PN=dh.div`
  -webkit-text-size-adjust: 100%;
  -webkit-tap-highlight-color: transparent;
  box-sizing: border-box;
  margin: 0;
  font-family: inherit;
  overflow: visible;
  text-transform: none;
  -webkit-appearance: button;
  font-weight: 400;
  vertical-align: middle;
  user-select: none;
  border: 1px solid #212121;
  padding: .375rem .5rem .375rem .9rem;
  font-size: .9em;
  line-height: 1.5;
  border-radius: 5px;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  background-color: #2c2c2c;
  border-color: #2c2c2c;
  white-space: nowrap;
  color: #777;
  display: flex;
  justify-content: space-between;
  cursor: pointer;
  width: fit-content;
  text-align: left;
`;function IN(){var e,{query:t}=bp();const n=W.useRef(),r=W.useRef(),o=W.useRef(),i=yp(),[a,l]=W.useState(!0),[s,c]=W.useState([]);var[u,d]=W.useState({});const[f,p]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:m,setClicked:h,points:g,setPoints:v}=IO();return W.useEffect((()=>{window.location.search.includes("?anime")&&!sessionStorage.getItem("animeinfo")&&Ek.getBySlug(window.location.search.split("anime=")[1]).then((e=>{p(e)})),sessionStorage.getItem("lastsearch")&&i.replace(`/search/${sessionStorage.getItem("lastsearch")}`)}),[]),W.useEffect((()=>{!async function(){t&&(c(await Ek.search(t,15,JSON.stringify(u))),l(!1))}()}),[t]),W.useEffect((()=>{const e=e=>{n.current.contains(e.target)||(document.getElementById("dropmenu1").style.display=null),r.current.contains(e.target)||(document.getElementById("dropmenu2").style.display=null),o.current.contains(e.target)||(document.getElementById("dropmenu3").style.display=null)};return document.addEventListener("mousedown",e),()=>{document.removeEventListener("mousedown",e)}}),[]),!1===s&&visualViewport?Z.jsx("p",{style:{textAlign:"center",marginTop:"40vh"},children:"No Results Found"}):Z.jsxs(Z.Fragment,{children:[a&&window.innerWidth>=600&&Z.jsx("div",{style:{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)"},children:Z.jsx($k,{})}),Z.jsx("form",{onSubmit:e=>{e.preventDefault();const t=e.target[0].value;sessionStorage.setItem("lastsearch",t),t&&i.replace(`/search/${t}`)},children:Z.jsx(EN,{id:"test",placeholder:"What should we search today?"})}),Z.jsxs(CN,{onChange:async e=>{var n,r,[o,i]=null==(r=null==(n=e.target)?void 0:n.id)?void 0:r.split("-");if("type"===o||"genre"===o){var a=[...document.querySelectorAll(`[id^='${o}-']:checked`)].map((e=>e.value));u[o]=JSON.stringify(a)}else"sort"===o&&(u[o]=i);d(u),c(await Ek.search(t,15,JSON.stringify(u))),e.preventDefault()},children:[Z.jsx(AN,{ref:n,children:Z.jsxs(ON,{children:[Z.jsxs(PN,{onClick:()=>{var e=document.getElementById("dropmenu1");e.style.display=""===e.style.display?"block":null},style:{width:window.innerWidth>=600?"18.5rem":null},children:[Z.jsx("span",{"data-placeholder":"Sort by","data-label-placement":"true",children:(null==(e=document.querySelector(`label[for="sort-${u.sort}"]`))?void 0:e.innerText)??"Recently Updated"}),Z.jsx(TS,{style:{fontSize:"1.2em",margin:"auto",marginRight:0}})]}),Z.jsxs(NN,{id:"dropmenu1",children:[Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-recently_updated",name:"sort",defaultChecked:!u.sort}),Z.jsx("label",{htmlFor:"sort-recently_updated",children:"Recently Updated"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-recently_added",name:"sort"}),Z.jsx("label",{htmlFor:"sort-recently_added",children:"Recently Added"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-release_date_down",name:"sort"}),Z.jsx("label",{htmlFor:"sort-release_date_down",children:"Release Date ↓"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-release_date_up",name:"sort"}),Z.jsx("label",{htmlFor:"sort-release_date_up",children:"Release Date ↑"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-title_az",name:"sort"}),Z.jsx("label",{htmlFor:"sort-title_az",children:"Name A-Z"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-scores",name:"sort"}),Z.jsx("label",{htmlFor:"sort-scores",children:"Best Rating"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-most_watched",name:"sort"}),Z.jsx("label",{htmlFor:"sort-most_watched",children:"Most Watched"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"radio",id:"sort-number_of_episodes",name:"sort"}),Z.jsx("label",{htmlFor:"sort-number_of_episodes",children:"Anime Length"})]})]})]})}),Z.jsx(AN,{ref:r,children:Z.jsxs(ON,{children:[Z.jsxs(PN,{onClick:()=>{var e=document.getElementById("dropmenu2");e.style.display=""===e.style.display?"block":null},"data-toggle":"dropdown",children:[Z.jsx("span",{"data-placeholder":"Sort by","data-label-placement":"true",children:"Select Type"}),Z.jsx(TS,{style:{fontSize:"1.2em",margin:"auto",marginLeft:0}})]}),Z.jsxs(NN,{id:"dropmenu2",children:[Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"type-tv",value:"TV"}),Z.jsx("label",{htmlFor:"type-tv",children:"TV"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"type-movie",value:"MOVIE"}),Z.jsx("label",{htmlFor:"type-movie",children:"Movie"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"type-ova",value:"OVA"}),Z.jsx("label",{htmlFor:"type-ova",children:"OVA"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"type-ona",value:"ONA"}),Z.jsx("label",{htmlFor:"type-ona",children:"ONA"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"type-special",value:"SPECIAL"}),Z.jsx("label",{htmlFor:"type-special",children:"Special"})]})]})]})}),Z.jsx(AN,{ref:o,children:Z.jsxs(ON,{children:[Z.jsxs(PN,{onClick:()=>{var e=document.getElementById("dropmenu3");e.style.display=""===e.style.display?"block":null},"data-toggle":"dropdown",children:[Z.jsx("span",{"data-placeholder":"Sort by","data-label-placement":"true",children:"Select Genres"}),Z.jsx(TS,{style:{fontSize:"1.2em",margin:"auto",marginLeft:0}})]}),Z.jsxs(NN,{id:"dropmenu3",children:[Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-action",value:"Action"}),Z.jsx("label",{htmlFor:"genre-action",children:"Action"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-adventure",value:"Adventure"}),Z.jsx("label",{htmlFor:"genre-adventure",children:"Adventure"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-comedy",value:"Comedy"}),Z.jsx("label",{htmlFor:"genre-comedy",children:"Comedy"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-drama",value:"Drama"}),Z.jsx("label",{htmlFor:"genre-drama",children:"Drama"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-ecchi",value:"Ecchi"}),Z.jsx("label",{htmlFor:"genre-ecchi",children:"Ecchi"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-fantasy",value:"Fantasy"}),Z.jsx("label",{htmlFor:"genre-fantasy",children:"Fantasy"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-horror",value:"Horror"}),Z.jsx("label",{htmlFor:"genre-horror",children:"Horror"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-mecha",value:"Mecha"}),Z.jsx("label",{htmlFor:"genre-mecha",children:"Mecha"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-mystery",value:"Mystery"}),Z.jsx("label",{htmlFor:"genre-mystery",children:"Mystery"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-psycho",value:"Psychological"}),Z.jsx("label",{htmlFor:"genre-psycho",children:"Psychological"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-romance",value:"Romance"}),Z.jsx("label",{htmlFor:"genre-romance",children:"Romance"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-scifi",value:"Sci-Fi"}),Z.jsx("label",{htmlFor:"genre-scifi",children:"Sci-Fi"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-sports",value:"Sports"}),Z.jsx("label",{htmlFor:"genre-sports",children:"Sports"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-supernnatural",value:"Supernatural"}),Z.jsx("label",{htmlFor:"genre-supernnatural",children:"Supernatural"})]}),Z.jsxs(_N,{children:[Z.jsx("input",{type:"checkbox",id:"genre-thriller",value:"Thriller"}),Z.jsx("label",{htmlFor:"genre-thriller",children:"Thriller"})]})]})]})})]}),Z.jsxs(SN,{children:[0===(null==s?void 0:s.length)&&!a&&Z.jsx("p",{style:{position:"absolute",left:"50%",top:"50%",color:"darkgray",transform:"translate(-50%, -50%)",textAlign:"center"},children:"No results found!"}),null==s?void 0:s.map(((e,t)=>{var n,r,o;return Z.jsx(jN,{onContextMenu:e=>{"imgcard"===e.target.id&&(e.preventDefault(),h(!m),v({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>p(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(o=e.images)?void 0:o.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),f&&Z.jsx(pj,{anime:f,onClose:e=>{p(e??null),sessionStorage.removeItem("animeinfo")}})]}),Z.jsx(PO,{style:{position:"absolute"},scale:1,points:g,clicked:m,animes:s,setClicked:h,setSelectedAnime:p})]})}var TN=W,LN=function(e){return e&&"object"==typeof e&&"default"in e?e.default:e}(TN);function MN(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var RN=!("undefined"==typeof window||!window.document||!window.document.createElement);const zN=n((function(e,t,n){if("function"!=typeof e)throw new Error("Expected reducePropsToState to be a function.");if("function"!=typeof t)throw new Error("Expected handleStateChangeOnClient to be a function.");if(void 0!==n&&"function"!=typeof n)throw new Error("Expected mapStateOnServer to either be undefined or a function.");return function(r){if("function"!=typeof r)throw new Error("Expected WrappedComponent to be a React component.");var o,i=[];function a(){o=e(i.map((function(e){return e.props}))),l.canUseDOM?t(o):n&&(o=n(o))}var l=function(e){var t,n;function l(){return e.apply(this,arguments)||this}n=e,(t=l).prototype=Object.create(n.prototype),t.prototype.constructor=t,t.__proto__=n,l.peek=function(){return o},l.rewind=function(){if(l.canUseDOM)throw new Error("You may only call rewind() on the server. Call peek() to read the current state.");var e=o;return o=void 0,i=[],e};var s=l.prototype;return s.UNSAFE_componentWillMount=function(){i.push(this),a()},s.componentDidUpdate=function(){a()},s.componentWillUnmount=function(){var e=i.indexOf(this);i.splice(e,1),a()},s.render=function(){return LN.createElement(r,this.props)},l}(TN.PureComponent);return MN(l,"displayName","SideEffect("+function(e){return e.displayName||e.name||"Component"}(r)+")"),MN(l,"canUseDOM",RN),l}}));var $N="undefined"!=typeof Element,DN="function"==typeof Map,BN="function"==typeof Set,FN="function"==typeof ArrayBuffer&&!!ArrayBuffer.isView;function UN(e,t){if(e===t)return!0;if(e&&t&&"object"==typeof e&&"object"==typeof t){if(e.constructor!==t.constructor)return!1;var n,r,o,i;if(Array.isArray(e)){if((n=e.length)!=t.length)return!1;for(r=n;0!=r--;)if(!UN(e[r],t[r]))return!1;return!0}if(DN&&e instanceof Map&&t instanceof Map){if(e.size!==t.size)return!1;for(i=e.entries();!(r=i.next()).done;)if(!t.has(r.value[0]))return!1;for(i=e.entries();!(r=i.next()).done;)if(!UN(r.value[1],t.get(r.value[0])))return!1;return!0}if(BN&&e instanceof Set&&t instanceof Set){if(e.size!==t.size)return!1;for(i=e.entries();!(r=i.next()).done;)if(!t.has(r.value[0]))return!1;return!0}if(FN&&ArrayBuffer.isView(e)&&ArrayBuffer.isView(t)){if((n=e.length)!=t.length)return!1;for(r=n;0!=r--;)if(e[r]!==t[r])return!1;return!0}if(e.constructor===RegExp)return e.source===t.source&&e.flags===t.flags;if(e.valueOf!==Object.prototype.valueOf)return e.valueOf()===t.valueOf();if(e.toString!==Object.prototype.toString)return e.toString()===t.toString();if((n=(o=Object.keys(e)).length)!==Object.keys(t).length)return!1;for(r=n;0!=r--;)if(!Object.prototype.hasOwnProperty.call(t,o[r]))return!1;if($N&&e instanceof Element)return!1;for(r=n;0!=r--;)if(("_owner"!==o[r]&&"__v"!==o[r]&&"__o"!==o[r]||!e.$$typeof)&&!UN(e[o[r]],t[o[r]]))return!1;return!0}return e!=e&&t!=t}var WN=function(e,t){try{return UN(e,t)}catch(n){if((n.message||"").match(/stack|recursion/i))return console.warn("react-fast-compare cannot handle circular refs"),!1;throw n}};const VN=n(WN);var HN="bodyAttributes",qN="htmlAttributes",YN="titleAttributes",JN={BASE:"base",BODY:"body",HEAD:"head",HTML:"html",LINK:"link",META:"meta",NOSCRIPT:"noscript",SCRIPT:"script",STYLE:"style",TITLE:"title"};Object.keys(JN).map((function(e){return JN[e]}));var GN,QN,KN,XN,ZN="charset",e_="cssText",t_="href",n_="http-equiv",r_="innerHTML",o_="itemprop",i_="name",a_="property",l_="rel",s_="src",c_="target",u_={accesskey:"accessKey",charset:"charSet",class:"className",contenteditable:"contentEditable",contextmenu:"contextMenu","http-equiv":"httpEquiv",itemprop:"itemProp",tabindex:"tabIndex"},d_="defaultTitle",f_="defer",p_="encodeSpecialCharacters",m_="onChangeClientState",h_="titleTemplate",g_=Object.keys(u_).reduce((function(e,t){return e[u_[t]]=t,e}),{}),v_=[JN.NOSCRIPT,JN.SCRIPT,JN.STYLE],y_="data-react-helmet",b_="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},w_=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),x_=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},k_=function(e,t){var n={};for(var r in e)t.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(n[r]=e[r]);return n},S_=function(e){return!1===(!(arguments.length>1&&void 0!==arguments[1])||arguments[1])?String(e):String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;")},j_=function(e){var t=N_(e,JN.TITLE),n=N_(e,h_);if(n&&t)return n.replace(/%s/g,(function(){return Array.isArray(t)?t.join(""):t}));var r=N_(e,d_);return t||r||void 0},E_=function(e){return N_(e,m_)||function(){}},C_=function(e,t){return t.filter((function(t){return void 0!==t[e]})).map((function(t){return t[e]})).reduce((function(e,t){return x_({},e,t)}),{})},A_=function(e,t){return t.filter((function(e){return void 0!==e[JN.BASE]})).map((function(e){return e[JN.BASE]})).reverse().reduce((function(t,n){if(!t.length)for(var r=Object.keys(n),o=0;o<r.length;o++){var i=r[o].toLowerCase();if(-1!==e.indexOf(i)&&n[i])return t.concat(n)}return t}),[])},O_=function(e,t,n){var r={};return n.filter((function(t){return!!Array.isArray(t[e])||(void 0!==t[e]&&L_("Helmet: "+e+' should be of type "Array". Instead found type "'+b_(t[e])+'"'),!1)})).map((function(t){return t[e]})).reverse().reduce((function(e,n){var o={};n.filter((function(e){for(var n=void 0,i=Object.keys(e),a=0;a<i.length;a++){var l=i[a],s=l.toLowerCase();-1===t.indexOf(s)||n===l_&&"canonical"===e[n].toLowerCase()||s===l_&&"stylesheet"===e[s].toLowerCase()||(n=s),-1===t.indexOf(l)||l!==r_&&l!==e_&&l!==o_||(n=l)}if(!n||!e[n])return!1;var c=e[n].toLowerCase();return r[n]||(r[n]={}),o[n]||(o[n]={}),!r[n][c]&&(o[n][c]=!0,!0)})).reverse().forEach((function(t){return e.push(t)}));for(var i=Object.keys(o),a=0;a<i.length;a++){var l=i[a],s=u({},r[l],o[l]);r[l]=s}return e}),[]).reverse()},N_=function(e,t){for(var n=e.length-1;n>=0;n--){var r=e[n];if(r.hasOwnProperty(t))return r[t]}return null},__=(GN=Date.now(),function(e){var t=Date.now();t-GN>16?(GN=t,e(t)):setTimeout((function(){__(e)}),0)}),P_=function(e){return clearTimeout(e)},I_="undefined"!=typeof window?window.requestAnimationFrame&&window.requestAnimationFrame.bind(window)||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||__:global.requestAnimationFrame||__,T_="undefined"!=typeof window?window.cancelAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame||P_:global.cancelAnimationFrame||P_,L_=function(e){return console&&"function"==typeof console.warn&&console.warn(e)},M_=null,R_=function(e,t){var n=e.baseTag,r=e.bodyAttributes,o=e.htmlAttributes,i=e.linkTags,a=e.metaTags,l=e.noscriptTags,s=e.onChangeClientState,c=e.scriptTags,u=e.styleTags,d=e.title,f=e.titleAttributes;D_(JN.BODY,r),D_(JN.HTML,o),$_(d,f);var p={baseTag:B_(JN.BASE,n),linkTags:B_(JN.LINK,i),metaTags:B_(JN.META,a),noscriptTags:B_(JN.NOSCRIPT,l),scriptTags:B_(JN.SCRIPT,c),styleTags:B_(JN.STYLE,u)},m={},h={};Object.keys(p).forEach((function(e){var t=p[e],n=t.newTags,r=t.oldTags;n.length&&(m[e]=n),r.length&&(h[e]=p[e].oldTags)})),t&&t(),s(e,m,h)},z_=function(e){return Array.isArray(e)?e.join(""):e},$_=function(e,t){void 0!==e&&document.title!==e&&(document.title=z_(e)),D_(JN.TITLE,t)},D_=function(e,t){var n=document.getElementsByTagName(e)[0];if(n){for(var r=n.getAttribute(y_),o=r?r.split(","):[],i=[].concat(o),a=Object.keys(t),l=0;l<a.length;l++){var s=a[l],c=t[s]||"";n.getAttribute(s)!==c&&n.setAttribute(s,c),-1===o.indexOf(s)&&o.push(s);var u=i.indexOf(s);-1!==u&&i.splice(u,1)}for(var d=i.length-1;d>=0;d--)n.removeAttribute(i[d]);o.length===i.length?n.removeAttribute(y_):n.getAttribute(y_)!==a.join(",")&&n.setAttribute(y_,a.join(","))}},B_=function(e,t){var n=document.head||document.querySelector(JN.HEAD),r=n.querySelectorAll(e+"["+y_+"]"),o=Array.prototype.slice.call(r),i=[],a=void 0;return t&&t.length&&t.forEach((function(t){var n=document.createElement(e);for(var r in t)if(t.hasOwnProperty(r))if(r===r_)n.innerHTML=t.innerHTML;else if(r===e_)n.styleSheet?n.styleSheet.cssText=t.cssText:n.appendChild(document.createTextNode(t.cssText));else{var l=void 0===t[r]?"":t[r];n.setAttribute(r,l)}n.setAttribute(y_,"true"),o.some((function(e,t){return a=t,n.isEqualNode(e)}))?o.splice(a,1):i.push(n)})),o.forEach((function(e){return e.parentNode.removeChild(e)})),i.forEach((function(e){return n.appendChild(e)})),{oldTags:o,newTags:i}},F_=function(e){return Object.keys(e).reduce((function(t,n){var r=void 0!==e[n]?n+'="'+e[n]+'"':""+n;return t?t+" "+r:r}),"")},U_=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};return Object.keys(e).reduce((function(t,n){return t[u_[n]||n]=e[n],t}),t)},W_=function(e,t,n){switch(e){case JN.TITLE:return{toComponent:function(){return e=t.title,n=t.titleAttributes,(r={key:e})[y_]=!0,o=U_(n,r),[V.createElement(JN.TITLE,o,e)];var e,n,r,o},toString:function(){return function(e,t,n,r){var o=F_(n),i=z_(t);return o?"<"+e+" "+y_+'="true" '+o+">"+S_(i,r)+"</"+e+">":"<"+e+" "+y_+'="true">'+S_(i,r)+"</"+e+">"}(e,t.title,t.titleAttributes,n)}};case HN:case qN:return{toComponent:function(){return U_(t)},toString:function(){return F_(t)}};default:return{toComponent:function(){return function(e,t){return t.map((function(t,n){var r,o=((r={key:n})[y_]=!0,r);return Object.keys(t).forEach((function(e){var n=u_[e]||e;if(n===r_||n===e_){var r=t.innerHTML||t.cssText;o.dangerouslySetInnerHTML={__html:r}}else o[n]=t[e]})),V.createElement(e,o)}))}(e,t)},toString:function(){return function(e,t,n){return t.reduce((function(t,r){var o=Object.keys(r).filter((function(e){return!(e===r_||e===e_)})).reduce((function(e,t){var o=void 0===r[t]?t:t+'="'+S_(r[t],n)+'"';return e?e+" "+o:o}),""),i=r.innerHTML||r.cssText||"",a=-1===v_.indexOf(e);return t+"<"+e+" "+y_+'="true" '+o+(a?"/>":">"+i+"</"+e+">")}),"")}(e,t,n)}}}},V_=function(e){var t=e.baseTag,n=e.bodyAttributes,r=e.encode,o=e.htmlAttributes,i=e.linkTags,a=e.metaTags,l=e.noscriptTags,s=e.scriptTags,c=e.styleTags,u=e.title,d=void 0===u?"":u,f=e.titleAttributes;return{base:W_(JN.BASE,t,r),bodyAttributes:W_(HN,n,r),htmlAttributes:W_(qN,o,r),link:W_(JN.LINK,i,r),meta:W_(JN.META,a,r),noscript:W_(JN.NOSCRIPT,l,r),script:W_(JN.SCRIPT,s,r),style:W_(JN.STYLE,c,r),title:W_(JN.TITLE,{title:d,titleAttributes:f},r)}},H_=zN((function(e){return{baseTag:A_([t_,c_],e),bodyAttributes:C_(HN,e),defer:N_(e,f_),encode:N_(e,p_),htmlAttributes:C_(qN,e),linkTags:O_(JN.LINK,[l_,t_],e),metaTags:O_(JN.META,[i_,ZN,n_,a_,o_],e),noscriptTags:O_(JN.NOSCRIPT,[r_],e),onChangeClientState:E_(e),scriptTags:O_(JN.SCRIPT,[s_,r_],e),styleTags:O_(JN.STYLE,[e_],e),title:j_(e),titleAttributes:C_(YN,e)}}),(function(e){M_&&T_(M_),e.defer?M_=I_((function(){R_(e,(function(){M_=null}))})):(R_(e),M_=null)}),V_)((function(){return null})),q_=(QN=H_,XN=KN=function(e){function t(){return function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,t),function(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}(this,e.apply(this,arguments))}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(t,e),t.prototype.shouldComponentUpdate=function(e){return!VN(this.props,e)},t.prototype.mapNestedChildrenToProps=function(e,t){if(!t)return null;switch(e.type){case JN.SCRIPT:case JN.NOSCRIPT:return{innerHTML:t};case JN.STYLE:return{cssText:t}}throw new Error("<"+e.type+" /> elements are self-closing and can not contain children. Refer to our API for more information.")},t.prototype.flattenArrayTypeChildren=function(e){var t,n=e.child,r=e.arrayTypeChildren,o=e.newChildProps,i=e.nestedChildren;return x_({},r,((t={})[n.type]=[].concat(r[n.type]||[],[x_({},o,this.mapNestedChildrenToProps(n,i))]),t))},t.prototype.mapObjectTypeChildren=function(e){var t,n,r=e.child,o=e.newProps,i=e.newChildProps,a=e.nestedChildren;switch(r.type){case JN.TITLE:return x_({},o,((t={})[r.type]=a,t.titleAttributes=x_({},i),t));case JN.BODY:return x_({},o,{bodyAttributes:x_({},i)});case JN.HTML:return x_({},o,{htmlAttributes:x_({},i)})}return x_({},o,((n={})[r.type]=x_({},i),n))},t.prototype.mapArrayTypeChildrenToProps=function(e,t){var n=x_({},t);return Object.keys(e).forEach((function(t){var r;n=x_({},n,((r={})[t]=e[t],r))})),n},t.prototype.warnOnInvalidChildren=function(e,t){return!0},t.prototype.mapChildrenToProps=function(e,t){var n=this,r={};return V.Children.forEach(e,(function(e){if(e&&e.props){var o=e.props,i=o.children,a=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};return Object.keys(e).reduce((function(t,n){return t[g_[n]||n]=e[n],t}),t)}(k_(o,["children"]));switch(n.warnOnInvalidChildren(e,i),e.type){case JN.LINK:case JN.META:case JN.NOSCRIPT:case JN.SCRIPT:case JN.STYLE:r=n.flattenArrayTypeChildren({child:e,arrayTypeChildren:r,newChildProps:a,nestedChildren:i});break;default:t=n.mapObjectTypeChildren({child:e,newProps:t,newChildProps:a,nestedChildren:i})}}})),t=this.mapArrayTypeChildrenToProps(r,t)},t.prototype.render=function(){var e=this.props,t=e.children,n=k_(e,["children"]),r=x_({},n);return t&&(r=this.mapChildrenToProps(t,r)),V.createElement(QN,r)},w_(t,null,[{key:"canUseDOM",set:function(e){QN.canUseDOM=e}}]),t}(V.Component),KN.propTypes={base:xd.object,bodyAttributes:xd.object,children:xd.oneOfType([xd.arrayOf(xd.node),xd.node]),defaultTitle:xd.string,defer:xd.bool,encodeSpecialCharacters:xd.bool,htmlAttributes:xd.object,link:xd.arrayOf(xd.object),meta:xd.arrayOf(xd.object),noscript:xd.arrayOf(xd.object),onChangeClientState:xd.func,script:xd.arrayOf(xd.object),style:xd.arrayOf(xd.object),title:xd.string,titleAttributes:xd.object,titleTemplate:xd.string},KN.defaultProps={defer:!0,encodeSpecialCharacters:!0},KN.peek=QN.peek,KN.rewind=function(){var e=QN.rewind();return e||(e=V_({baseTag:[],bodyAttributes:{},encodeSpecialCharacters:!0,htmlAttributes:{},linkTags:[],metaTags:[],noscriptTags:[],scriptTags:[],styleTags:[],title:"",titleAttributes:{}})),e},XN);function Y_(){var e,t,n,r,o,i,a,[l,s]=[window.location.pathname.split("/")[2],window.location.pathname.split("/")[3]],c=JSON.parse(sessionStorage.getItem("animeinfo")),u=JSON.parse(localStorage.getItem("settings"))||{};const[d,f]=V.useState(!0),[p,m]=V.useState(),[h,g]=V.useState();var v=l.split("-episode-"),y=Number(v[1])||0;return W.useEffect((()=>{!async function(){var e="gogo"===(null==u?void 0:u.preferredserver)?"gogo":h||"";let t=await Ek.watchEpisode(l,s,e).catch((e=>{if(hd.dismiss(),"Failed to fetch"===e.message)return hd.error("Could not reach Animeflix servers! Try again in a few minutes.",{style:{background:"#333",color:"#fff"}});hd.error("You are being rate limited! Please slow down.",{style:{background:"#333",color:"#fff"}})}));t||(window.location.href="/"),t=`${t}${"true"===u.autoskip?"&autoskip=true":""}`,m(t)}()}),[h]),W.useEffect((()=>{const e=e=>{const{message:t,data:n}=e;var r=t||n;switch("watchprogress"===(null==r?void 0:r.type)&&async function(e,t,n){var r,o,i=Number(window.location.pathname.split("/")[2].split("-episode-")[1])||0,a=window.location.pathname.split("/")[2],l=null==n?void 0:n.anilistID;if(l){var s=localStorage.getItem("token"),c=JSON.parse(localStorage.getItem("recentlywatched"))||[];if(n){const r=c.findIndex((e=>e===l));"FINISHED"===n.status&&n.episodeNum===i&&e/t>.8&&-1!==r?(c.splice(r,1),localStorage.setItem("recentlywatched",JSON.stringify(c)),s&&await Ek.set(s,"recentlywatched",c)):0!==r&&e/t<.8&&(-1!==r?(c.splice(r,1),c.unshift(l)):(c.length>10&&c.pop(),c.unshift(l)),localStorage.setItem("recentlywatched",JSON.stringify(c)),s&&await Ek.set(s,"recentlywatched",c))}var u=localStorage.getItem(`${l}`);if(u){var d=JSON.parse(u).episodes;d||(d=[]),d.find((e=>e.episodeId===a))?d[d.findIndex((e=>e.episodeId===a))].position=Math.floor(e):d.push({episodeId:a,position:Math.floor(e),outof:t});var f={episodeId:a,episodeName:(null==(r=null==n?void 0:n.episode)?void 0:r.title)||`Episode ${i}`,epNum:i,position:Math.floor(e),episodes:d};localStorage.setItem(`${l}`,JSON.stringify(f)),s&&await Ek.set(s,`watchdata.${l}`,f)}else{var p={episodeId:a,episodeName:(null==(o=null==n?void 0:n.episode)?void 0:o.title)||`Episode ${i}`,epNum:i,position:Math.floor(e),episodes:[{episodeId:a,position:Math.floor(e),outof:t}]};localStorage.setItem(`${l}`,JSON.stringify(p)),s&&await Ek.set(s,`watchdata.${l}`,p)}}}(n.position,n.duration,c),r){case"nextepisode-pressed":var o=Number(window.location.pathname.split("/")[2].split("-episode-")[1])+1;Ek.watchEpisode(`${v[0]}-episode-${o}`,"","").then((e=>{e||(window.location.href="/"),window.history.replaceState({},"Player Page",`/watch/${v[0]}-episode-${o}`),e=`${e}${"true"===u.autoskip?"&autoskip=true":""}`,m(e)}));break;case"backbutton-clicked":window.history.replaceState({},"Main Page",`${(null==c?void 0:c.lastpage)||"/"}`),window.location.href=(null==c?void 0:c.lastpage)||"/";break;case"show-submitted":hd.success("Timestamp successfully submitted",{style:{background:"#333",color:"#fff"}});break;case"show-reported":hd.success("Timestamp successfully reported",{style:{background:"#333",color:"#fff"}});break;case"invalid-timestamp":hd.error("Invalid timestamp detected!",{style:{background:"#333",color:"#fff"}});break;case"settings-0":g("moon");break;case"settings-1":g("sun");break;case"settings-2":g("zoro");break;case"settings-3":g("gogo");break;case"timestamp-notice":if(localStorage.getItem("stampnotification"))return;hd((e=>Z.jsxs("div",{style:{display:"block",lineHeight:"1"},children:[Z.jsxs("span",{style:{whiteSpace:"nowrap",fontSize:"80%",display:"inline-block"},children:["This episode doesn't have an intro timestamp!",Z.jsx("br",{}),"You can submit one from the player settings."]}),Z.jsxs("div",{style:{display:"flex",flexWrap:"wrap",width:"100%",justifyContent:"space-between",marginTop:".4rem"},children:[Z.jsx("button",{style:{width:"48%",borderRadius:"4px",background:"#e50914",color:"white",fontSize:"85%",padding:".5vh"},onClick:()=>hd.dismiss(e.id),children:"Dismiss"}),Z.jsx("button",{style:{width:"48%",borderRadius:"4px",background:"#e50914",color:"white",fontSize:"85%",padding:".5vh"},onClick:()=>{localStorage.setItem("stampnotification",!0),hd.dismiss(e.id)},children:"Don't Remind"})]})]})),{position:"bottom-right",duration:5e5,style:{marginBottom:"4rem",display:"block",width:"fit-content",background:"#181818",color:"#fff"}});break;case"ios-fullscreen":var i=hd(Z.jsxs("span",{onClick:()=>hd.dismiss(i),children:["Please install Animeflix as a webapp to get fullscreen on iOS.",Z.jsx("br",{}),"Tap the ",Z.jsx(dN,{}),' and then "Add to Homescreen".']}),{duration:1e4,icon:Z.jsx(iN,{}),position:"top-center",style:{background:"#333",color:"#fff"}})}};return window.addEventListener("message",e,!1),function(){window.removeEventListener("message",e)}}),[]),Z.jsxs(Z.Fragment,{children:[Z.jsxs(q_,{children:[" ",Z.jsx("meta",{charSet:"utf-8"}),Z.jsx("script",{id:"syncData",type:"application/json",children:JSON.stringify({page:"episode",episode:y,"page-url":`https://animeflix.live/?anime=${l.includes("-dub-")?l.split("-dub-")[0]:l.split("-episode-")[0]}`,"next-episode-url":window.location.href.replace(/-episode-[0-9]+.*/,`-episode-${y+1}`),slug:l.includes("-dub-")?l.split("-dub-")[0]:l.split("-episode-")[0],anilistID:null==c?void 0:c.anilistID,malID:null==c?void 0:c.malID,name:(null==(e=null==c?void 0:c.title)?void 0:e.romaji)||(null==(t=null==c?void 0:c.title)?void 0:t.userPreferred)||(null==(n=null==c?void 0:c.title)?void 0:n.english)})}),c&&Z.jsx("title",{children:`${(null==(r=null==c?void 0:c.title)?void 0:r.romaji)||"Anime"} - Episode ${y||0}`})]})," ",Z.jsx("meta",{name:"anime-skip.show.name",content:(null==(o=null==c?void 0:c.title)?void 0:o.userPreferred)||(null==(i=null==c?void 0:c.title)?void 0:i.english)||"Unknown"}),Z.jsx("meta",{name:"anime-skip.episode.name",content:(null==(a=null==c?void 0:c.episode)?void 0:a.title)||`Episode ${Number(v[1])||0}`}),Z.jsx("meta",{name:"anime-skip.episode.number",content:Number(v[1])||0}),Z.jsx(VA,{loading:d}),Z.jsx("iframe",{src:p,style:{height:"100vh",width:"100vw",position:"fixed"},allow:"autoplay; fullscreen",onLoad:e=>{if(f(!1),xk){const t=()=>e.target.style.height=window.innerHeight+"px";window.addEventListener("resize",t),t()}},id:"iframee",allowFullScreen:!0})]})}q_.renderStatic=q_.rewind;var J_={},G_=bh;Object.defineProperty(J_,"__esModule",{value:!0});var Q_=J_.default=void 0,K_=G_(hb()),X_=Z,Z_=(0,K_.default)((0,X_.jsx)("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"}),"Add");Q_=J_.default=Z_;var eP={},tP=bh;Object.defineProperty(eP,"__esModule",{value:!0});var nP=eP.default=void 0,rP=tP(hb()),oP=Z,iP=(0,rP.default)((0,oP.jsx)("path",{d:"M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"}),"Edit");nP=eP.default=iP;var aP={},lP=bh;Object.defineProperty(aP,"__esModule",{value:!0});var sP=aP.default=void 0,cP=lP(hb()),uP=Z,dP=(0,cP.default)((0,uP.jsx)("path",{d:"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9zm7.5-5-1-1h-5l-1 1H5v2h14V4z"}),"DeleteOutline");sP=aP.default=dP;var fP={},pP=bh;Object.defineProperty(fP,"__esModule",{value:!0});var mP=fP.default=void 0,hP=pP(hb()),gP=Z,vP=(0,hP.default)((0,gP.jsx)("path",{d:"M18.3 5.71a.9959.9959 0 0 0-1.41 0L12 10.59 7.11 5.7a.9959.9959 0 0 0-1.41 0c-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z"}),"CloseRounded");mP=fP.default=vP;var yP={},bP=bh;Object.defineProperty(yP,"__esModule",{value:!0});var wP=yP.default=void 0,xP=bP(hb()),kP=Z,SP=(0,xP.default)((0,kP.jsx)("path",{d:"M9 16.17 5.53 12.7a.9959.9959 0 0 0-1.41 0c-.39.39-.39 1.02 0 1.41l4.18 4.18c.39.39 1.02.39 1.41 0L20.29 7.71c.39-.39.39-1.02 0-1.41a.9959.9959 0 0 0-1.41 0L9 16.17z"}),"CheckRounded");wP=yP.default=SP;const jP=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,EP=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    user-select: none;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`,CP=dh.h3`
  white-space: nowrap;
  margin-left: 1rem;
  transition: 0.3s;
  cursor: pointer;
  color: #818181;
  
  ${e=>e.isMobile&&Xm`
    font-size: 1.3em;
  `}

  ${e=>e.selected&&Xm`
    color: white;
  `}

  &:hover {
    color: #d7d7d7;
  }
`,AP=dh.h3`
  width: clamp(25rem, 35vw, 35rem);
  height: clamp(2rem, 2em, 5rem);
  border-radius: 5px;
  border: 1.2px solid #5c5c5c;
  background-color: #242424;
  display: flex;
  position: relative;
  margin-left: -10%;
  position: absolute;
  top: 120%;
  z-index: 3;

  left: ${e=>e.left}px;
  .icon {
    font-size: 1.2em;
  }

  .input {
    background: transparent;
    margin: auto;
    margin-left: .5em;
    height: 100%;
    outline: none;
    color: white;
  }

  ${e=>!0===e.isMobile&&Xm`
    left: 10%;
    width: 100%;
    height: 250%;
    .icon { font-size: 1.7em; }
    .input { width: 75%; }
  `}
`,OP=dh(Q_)`
  margin-left: 1rem;
  margin-top: -.1rem;
  margin-bottom: .1rem;
  white-space: nowrap;
  transition: 0.3s;
  cursor: pointer;
  color: #818181;

  &:hover {
    color: #d7d7d7;
  }
`,NP=dh(sP)`
  position: absolute;
  left: 93%;
  top: 20%;
  transform: translate(-40%);
  white-space: nowrap;
  transition: 0.3s;
  cursor: pointer;
  color: #818181;

  &:hover {
    color: #d7d7d7;
  }
`,_P=dh(wP)`
  position: absolute;
  left: 83%;
  top: 20%;
  transform: translate(-40%);
  white-space: nowrap;
  transition: 0.3s;
  cursor: pointer;
  color: #818181;

  &:hover {
    color: #d7d7d7;
  }
`,PP=dh(nP)`
  margin-left: 1rem;
  margin-top: -.1rem;
  margin-bottom: .1rem;
  white-space: nowrap;
  transition: 0.3s;
  cursor: pointer;
  color: #818181;

  &:hover {
    color: #d7d7d7;
  }
`,IP=dh(mP)`
  margin-left: 1rem;
  margin-top: -.1rem;
  margin-bottom: .1rem;
  white-space: nowrap;
  transition: 0.3s;
  cursor: pointer;
  color: #818181;

  &:hover {
    color: #d7d7d7;
  }
`,TP=dh.ul`
  position: absolute;
  top: 1%;
  color: white;
  pointer-events: none;
  transition: opacity 200ms ease;
  border-radius: .375rem;
  margin-bottom: .25rem;
  margin-left: .5rem;
  padding: .3rem; 
  padding-bottom: .1rem;
  --tw-bg-opacity: 1; 
  background-color: rgb(38 38 38/var(--tw-bg-opacity));
  width: -webkit-max-content; 
  width: -moz-max-content; 
  width: max-content;
`;dh.li`
  display: block;
  width: 100%;
  padding: .25rem 1.5rem;
  clear: both;
  line-height: 2.5;
  font-weight: 400;
  color: #848484;
  text-align: inherit;
  white-space: nowrap;
  background-color: transparent;
  border: 0;
  &:hover {
    cursor:pointer;
    color: #adadad; 
    text-decoration: none; 
    background-color: #2e2e2e;
  }
`
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */;var LP=function(){return LP=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var o in t=arguments[n])Object.prototype.hasOwnProperty.call(t,o)&&(e[o]=t[o]);return e},LP.apply(this,arguments)};var MP={exports:{}};const RP=(e,t,n)=>{const r=t<0?e.length+t:t;if(r>=0&&r<e.length){const r=n<0?e.length+n:n,[o]=e.splice(t,1);e.splice(r,0,o)}};MP.exports=(e,t,n)=>(e=[...e],RP(e,t,n),e),MP.exports.mutate=RP;const zP=n(MP.exports);var $P=function(e,t,n){for(var r=e.x,o=e.y,i=(void 0===n?{}:n).fallbackToClosest,a=void 0!==i&&i,l=1e4,s=-1,c=0;c<t.length;c+=1){var u=t[c];if(r>=u.left&&r<u.right&&o>=u.top&&o<u.bottom)return c;if(a){var d=(u.left+u.right)/2,f=(u.top+u.bottom)/2,p=Math.sqrt(Math.pow(r-d,2)+Math.pow(o-f,2));p<l&&(l=p,s=c)}}return s},DP=function(e){return{x:Number(e.clientX),y:Number(e.clientY)}},BP=function(e){return{x:Number(e.clientX),y:Number(e.clientY)}},FP=function(e,t){return{x:e.x-t.x,y:e.y-t.y}},UP=function(e){e.preventDefault()},WP=function(){window.removeEventListener("contextmenu",UP)},VP=function(e){var t=e.onStart,n=e.onMove,r=e.onEnd,o=e.allowDrag,i=void 0===o||o,a=e.containerRef,l=e.knobs,s=V.useRef({x:0,y:0}),c=V.useRef(void 0),u=V.useRef(!1),d=V.useRef({onStart:t,onMove:n,onEnd:r}),f=V.useState(!1),p=f[0],m=f[1];V.useEffect((function(){d.current={onStart:t,onMove:n,onEnd:r}}),[t,n,r]);var h=function(){c.current&&window.clearTimeout(c.current)},g=V.useCallback((function(){if(a.current){var e=a.current.getBoundingClientRect();s.current={x:e.left,y:e.top}}}),[a]),v=V.useCallback((function(e){var t=FP(e,s.current);d.current.onMove&&d.current.onMove({pointInWindow:e,point:t})}),[]),y=V.useCallback((function(e){if(u.current){u.current=!1;var t=DP(e),n=FP(t,s.current);d.current.onStart&&d.current.onStart({point:n,pointInWindow:t})}else v(DP(e))}),[v]),b=V.useCallback((function(e){e.cancelable?(e.preventDefault(),v(BP(e.touches[0]))):(document.removeEventListener("touchmove",b),d.current.onEnd&&d.current.onEnd())}),[v]),w=V.useCallback((function(){u.current=!1,document.removeEventListener("mousemove",y),document.removeEventListener("mouseup",w),d.current.onEnd&&d.current.onEnd()}),[y]),x=V.useCallback((function(){document.removeEventListener("touchmove",b),document.removeEventListener("touchend",x),WP(),d.current.onEnd&&d.current.onEnd()}),[b]),k=V.useCallback((function(e){0===e.button&&((null==l?void 0:l.length)&&!l.find((function(t){return t.contains(e.target)}))||(document.addEventListener("mousemove",y),document.addEventListener("mouseup",w),g(),u.current=!0))}),[y,w,g,l]),S=V.useCallback((function(e,t){document.addEventListener("touchmove",b,{capture:!1,passive:!1}),document.addEventListener("touchend",x),window.addEventListener("contextmenu",UP,{capture:!0,passive:!1}),d.current.onStart&&d.current.onStart({point:e,pointInWindow:t})}),[x,b]),j=V.useCallback((function(e){if(!(null==l?void 0:l.length)||l.find((function(t){return t.contains(e.target)}))){g();var t=BP(e.touches[0]),n=FP(t,s.current);c.current=window.setTimeout((function(){return S(n,t)}),120)}}),[S,g,l]),E=V.useCallback((function(){m(!0),document.removeEventListener("touchstart",E)}),[]),C=V.useCallback((function(){h()}),[]);return V.useLayoutEffect((function(){if(p){var e=a.current;return i&&(null==e||e.addEventListener("touchstart",j,{capture:!0,passive:!1}),document.addEventListener("touchmove",C,{capture:!1,passive:!1}),document.addEventListener("touchend",C,{capture:!1,passive:!1})),function(){null==e||e.removeEventListener("touchstart",j,{capture:!0}),document.removeEventListener("touchmove",C,{capture:!1}),document.removeEventListener("touchend",C,{capture:!1}),document.removeEventListener("touchmove",b),document.removeEventListener("touchend",x),WP(),h()}}return document.addEventListener("touchstart",E),function(){document.removeEventListener("touchstart",E),document.removeEventListener("mousemove",y),document.removeEventListener("mouseup",w)}}),[p,i,E,y,b,C,x,w,a,j]),p?{}:{onMouseDown:k}},HP=V.createContext(void 0),qP=function(e){var t=e.children,n=V.useContext(HP);if(!n)throw new Error("SortableItem must be a child of SortableList");var r=n.registerItem,o=n.removeItem,i=V.useRef(null);return V.useEffect((function(){var e=i.current;return e&&r(e),function(){e&&o(e)}}),[r,o,t]),V.cloneElement(t,{ref:i})};const YP=function(e){var t=e.children,n=e.allowDrag,r=void 0===n||n,o=e.onSortEnd,i=e.draggedItemClassName,a=e.as,l=e.lockAxis,s=e.customHolderRef,c=function(e,t){var n={};for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.indexOf(r)<0&&(n[r]=e[r]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var o=0;for(r=Object.getOwnPropertySymbols(e);o<r.length;o++)t.indexOf(r[o])<0&&Object.prototype.propertyIsEnumerable.call(e,r[o])&&(n[r[o]]=e[r[o]])}return n}(e,["children","allowDrag","onSortEnd","draggedItemClassName","as","lockAxis","customHolderRef"]),u=V.useRef([]),d=V.useRef([]),f=V.useRef([]),p=V.useRef(null),m=V.useRef(null),h=V.useRef(void 0),g=V.useRef(void 0),v=V.useRef({x:0,y:0});V.useEffect((function(){var e=(null==s?void 0:s.current)||document.body;return function(){m.current&&e.removeChild(m.current)}}),[s]);var y=function(e){if(m.current&&void 0!==h.current){var t=v.current,n=d.current[h.current],r="y"===l?n.left:e.x-t.x,o="x"===l?n.top:e.y-t.y;m.current.style.transform="translate3d("+r+"px, "+o+"px, 0px)"}},b=V.useCallback((function(e){if(p.current){var t=u.current[e],n=d.current[e],r=t.cloneNode(!0);i&&i.split(" ").forEach((function(e){return r.classList.add(e)})),r.style.width=n.width+"px",r.style.height=n.height+"px",r.style.position="fixed",r.style.margin="0",r.style.top="0",r.style.left="0";var o=t.querySelectorAll("canvas");r.querySelectorAll("canvas").forEach((function(e,t){var n;null===(n=e.getContext("2d"))||void 0===n||n.drawImage(o[t],0,0)})),((null==s?void 0:s.current)||document.body).appendChild(r),m.current=r}}),[s,i]),w=VP({allowDrag:r,containerRef:p,knobs:f.current,onStart:function(e){var t=e.pointInWindow;if(p.current){d.current=u.current.map((function(e){return e.getBoundingClientRect()}));var n=$P(t,d.current);if(-1!==n){h.current=n,b(n);var r=u.current[n];r.style.opacity="0",r.style.visibility="hidden";var o=r.getBoundingClientRect();v.current={x:t.x-o.left,y:t.y-o.top},y(t),window.navigator.vibrate&&window.navigator.vibrate(100)}}},onMove:function(e){var t=e.pointInWindow;y(t);var n=h.current;if(void 0!==n&&void 0!==h.current){var r=d.current[h.current],o={x:"y"===l?r.left:t.x,y:"x"===l?r.top:t.y},i=$P(o,d.current,{fallbackToClosest:!0});if(-1!==i){g.current=i;for(var a=n<i,s=0;s<u.current.length;s+=1){var c=u.current[s],f=d.current[s];if(a&&s>=n&&s<=i||!a&&s>=i&&s<=n){var p=d.current[a?s-1:s+1];if(p){var m=p.left-f.left,v=p.top-f.top;c.style.transform="translate3d("+m+"px, "+v+"px, 0px)"}}else c.style.transform="translate3d(0,0,0)";c.style.transitionDuration="300ms"}}}},onEnd:function(){for(var e=0;e<u.current.length;e+=1){var t=u.current[e];t.style.transform="",t.style.transitionDuration=""}var n=h.current;if(void 0!==n){var r=u.current[n];r&&(r.style.opacity="1",r.style.visibility="");var i=g.current;void 0!==i&&n!==i&&(u.current=zP(u.current,n,i),o(n,i))}(h.current=void 0,g.current=void 0,m.current)&&(((null==s?void 0:s.current)||document.body).removeChild(m.current),m.current=null)}}),x=V.useCallback((function(e){u.current.push(e)}),[]),k=V.useCallback((function(e){var t=u.current.indexOf(e);-1!==t&&u.current.splice(t,1)}),[]),S=V.useCallback((function(e){f.current.push(e)}),[]),j=V.useCallback((function(e){var t=f.current.indexOf(e);-1!==t&&f.current.splice(t,1)}),[]),E=V.useMemo((function(){return{registerItem:x,removeItem:k,registerKnob:S,removeKnob:j}}),[x,k,S,j]);return V.createElement(a||"div",LP(LP(LP({},r?w:{}),c),{ref:p}),V.createElement(HP.Provider,{value:E},t))};function JP(e,t,n){return function(e,t,n){const r=t<0?e.length+t:t;if(r>=0&&r<e.length){const r=n<0?e.length+n:n,[o]=e.splice(t,1);e.splice(r,0,o)}}(e=[...e],t,n),e}function GP(){var e;const t=W.useRef(),[n,r]=W.useState(),[o,i]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:a,setClicked:l,points:s,setPoints:c}=IO(),[u,d]=W.useState((null==(e=JSON.parse(localStorage.getItem("folders")))?void 0:e[0])||"My List"),[f,p]=W.useState(),[m,h]=W.useState(),[g,v]=W.useState(JSON.parse(localStorage.getItem("folders"))||["My List"]),[y,b]=W.useState(1);var w=!1,x=localStorage.getItem("token"),k=JSON.parse(localStorage.getItem(u))??[];async function S(){var e;const n=Math.abs(window.scrollY/((null==(e=null==t?void 0:t.current)?void 0:e.clientHeight)-window.innerHeight));if(!w&&!o&&n>.8){w=!0;var i=k.slice(100*y,100*y+100);if(!(null==i?void 0:i.length)>0)return;const e=await Ek.idsToInfo(`[${i}]`);r((t=>t.concat(e))),b(y+1)}}W.useEffect((()=>{let e=!0;if(!k)return r([]);if((null==k?void 0:k.length)>100)var t=k.slice(0,100);return Ek.idsToInfo(`[${t??k}]`).then((t=>{e&&r(t)})).catch((e=>{if(hd.dismiss(),e.message.includes("Failed to fetch"))return hd.error("We are currently experiencing technical outages, please wait.",{duration:1e4,style:{background:"#333",color:"#fff"}});hd.error("Unexpected error occured! Please contact support",{duration:1e4,style:{background:"#333",color:"#fff"}})})),()=>{e=!1}}),[u]),W.useEffect((()=>{if(!((null==k?void 0:k.length)<100))return document.addEventListener("scroll",S),()=>document.removeEventListener("scroll",S)}));return"string"==typeof g?v(["My List"]):Z.jsxs(jP,{ref:t,children:[Z.jsxs("div",{style:{display:"flex",marginBottom:".5em",position:"relative",width:"fit-content",maxWidth:"90vw"},children:[Z.jsx(YP,{onSortEnd:(e,t)=>{var n=JP(JSON.parse(localStorage.getItem("folders"))||[],e,t);localStorage.setItem("folders",JSON.stringify(n)),x&&Ek.set(x,"folder_names",n),v((n=>JP(n,e,t)))},className:"noscroll",draggedItemClassName:"dragged",style:{display:"flex",maxWidth:"80vw",overflowX:"auto",overflowY:"hidden"},lockAxis:"x",children:g.map(((e,t)=>Z.jsx(qP,{children:Z.jsx("div",{style:{position:"relative"},children:Z.jsx(CP,{id:e,isMobile:xk,selected:u===e&&!f,onClick:t=>{f?(Array.isArray(m)&&(document.getElementById(m[2]).style.color=null),t.target.style.color="#d7d7d7",h([t.clientX,t.clientY,t.target.id])):d(e)},children:e})})},t)))}),f&&Z.jsx("p",{style:{position:"absolute",top:"-110%",color:"#858585",whiteSpace:"nowrap"},children:"Select folder to edit"}),f?Z.jsx(IP,{style:{fontSize:"1.4em"},onClick:()=>{Array.isArray(m)&&(document.getElementById(m[2]).style.color=null),p(!1),h(void 0)}}):Z.jsx(PP,{style:{fontSize:"1.4em"},onClick:()=>{p(!0)}}),Z.jsx(OP,{style:{fontSize:"1.4em"},onClick:()=>{var e=JSON.parse(localStorage.getItem("folders"))||["My List"];"string"==typeof e&&(e=["My List"]),e.push(`Unnamed ${e.length}`),x&&Ek.set(x,"folder_names",e),localStorage.setItem("folders",JSON.stringify(e)),v(e)}}),m&&f&&Z.jsxs(AP,{isMobile:xk,left:m[0],children:[Z.jsx("input",{id:"namechange",type:"text",placeholder:"Change Name",className:"input",onKeyDown:e=>(e=>{/[0-9a-zA-Z| ]/.test(e.key)||e.preventDefault()})(e)}),Z.jsx(NP,{className:"icon",onClick:()=>{var e=JSON.parse(localStorage.getItem("folders"))||["My List"];e=e.filter((e=>e!==m[2])),localStorage.setItem("folders",JSON.stringify(e)),localStorage.removeItem(m[2]),x&&Ek.set(x,"folder_names",e).then((()=>{Ek.set(x,`folders.${m[2]}`,null)})),v(e),h(void 0),d(null==e?void 0:e[0])}}),Z.jsx(_P,{className:"icon",onClick:async()=>{var e=JSON.parse(localStorage.getItem("folders"))||["My List"],t=e.findIndex((e=>e===m[2])),n=document.getElementById("namechange").value.trim()||"Unnamed";-1!==t&&(e[t]=n),localStorage.setItem("folders",JSON.stringify(e));var r=localStorage.getItem(m[2]);x&&Ek.set(x,"folder_names",e).then((()=>{Ek.set(x,`folders.${m[2]}`,null).then((()=>{Ek.set(x,`folders.${n}`,JSON.parse(r)||[])}))})),localStorage.setItem(n,r||"[]"),localStorage.removeItem(m[2]),Array.isArray(m)&&(document.getElementById(m[2]).style.color=null),v(e),h(void 0),d(null==e?void 0:e[0])}})]})]}),!(null==k?void 0:k.length)>0&&Z.jsxs("p",{style:{position:"absolute",left:"50%",top:"50%",color:"darkgray",transform:"translate(-50%, -50%)",textAlign:"center"},children:["Nothing here yet!",Z.jsx("br",{}),Z.jsx("br",{}),"You can add animes to this list for easier access.",Z.jsx("br",{}),"You can also create new folders to sort your anime!"]}),Z.jsx(YP,{onSortEnd:(e,t)=>{var n=JP(JSON.parse(localStorage.getItem(u))||[],e,t);localStorage.setItem(u,JSON.stringify(n)),x&&Ek.set(x,`folders.${u}`,n),r((n=>JP(n,e,t)))},draggedItemClassName:"dragged",children:null==n?void 0:n.map(((e,t)=>{var n,r,o;return Z.jsx(qP,{children:Z.jsx(EP,{onContextMenu:e=>{e.preventDefault(),"imgcard"!==e.target.id||xk||(l(!a),c({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>i(e),style:{background:"transparent",border:"none",userDrag:"none",userSelect:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{draggable:"false",media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{draggable:"false",media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{draggable:"false",src:null==(o=e.images)?void 0:o.small,id:"imgcard",alt:e.anilistID,loading:"lazy"})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji}),e.nextAiringEpisode&&Z.jsxs(TP,{className:"newep",children:["EP ",e.nextAiringEpisode.episode,": ",Ck.toDMS(e.nextAiringEpisode.airingAt)]})]})},t)},t)}))}),o&&Z.jsx(pj,{anime:o,onClose:e=>{i(e??null),sessionStorage.removeItem("animeinfo")}}),Z.jsx(PO,{scale:1,points:s,clicked:a,animes:n,setClicked:l,setSelectedAnime:i,onCallback:e=>{e===u&&r((e=>e.filter((e=>e.anilistID!==s.target.alt))))}})]})}const QP=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,KP=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`;function XP(){const e=W.useRef(),[t,n]=W.useState(),[r,o]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:i,setClicked:a,points:l,setPoints:s}=IO();var[c,u]=W.useState(1),d=!1;async function f(){var t;const o=Math.abs(window.scrollY/((null==(t=null==e?void 0:e.current)?void 0:t.clientHeight)-window.innerHeight));if(c>9&&(c=0),!d&&!r&&o>.8){d=!0;const e=await Ek.getMovies(c);n((t=>t.concat(e))),u(c+1)}}return W.useEffect((()=>{let e=!0;return Ek.getMovies(0).then((t=>{e&&n(t)})),()=>{e=!1}}),[]),W.useEffect((()=>(document.addEventListener("scroll",f),()=>document.removeEventListener("scroll",f)))),Z.jsxs(Z.Fragment,{children:[Z.jsxs(QP,{ref:e,children:[null==t?void 0:t.map(((e,t)=>{var n,r,l;return Z.jsx(KP,{onContextMenu:e=>{"imgcard"===e.target.id&&(e.preventDefault(),a(!i),s({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>o(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(l=e.images)?void 0:l.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),r&&Z.jsx(pj,{anime:r,onClose:e=>{o(e??null),sessionStorage.removeItem("animeinfo")}})]}),Z.jsx(PO,{scale:1,points:l,clicked:i,animes:t,setClicked:a,setSelectedAnime:o})]})}const ZP=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,eI=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`;function tI(){const e=W.useRef(),[t,n]=W.useState(),[r,o]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:i,setClicked:a,points:l,setPoints:s}=IO();var[c,u]=W.useState(1),d=!1;async function f(){var t;const o=Math.abs(window.scrollY/((null==(t=null==e?void 0:e.current)?void 0:t.clientHeight)-window.innerHeight));if(c>9&&(c=0),!d&&!r&&o>.8){d=!0;const e=await Ek.getSeries(c);n((t=>t.concat(e))),u(c+1)}}return W.useEffect((()=>{let e=!0;return Ek.getSeries(0).then((t=>{e&&n(t)})),()=>{e=!1}}),[]),W.useEffect((()=>(document.addEventListener("scroll",f),()=>document.removeEventListener("scroll",f)))),Z.jsxs(Z.Fragment,{children:[Z.jsxs(ZP,{ref:e,children:[null==t?void 0:t.map(((e,t)=>{var n,r,l;return Z.jsx(eI,{onContextMenu:e=>{"imgcard"===e.target.id&&(e.preventDefault(),a(!i),s({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>o(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(l=e.images)?void 0:l.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),r&&Z.jsx(pj,{anime:r,onClose:e=>{o(e??null),sessionStorage.removeItem("animeinfo")}})]}),Z.jsx(PO,{scale:1,points:l,clicked:i,animes:t,setClicked:a,setSelectedAnime:o})]})}const nI=dh.div`
  & + & {
    margin-top: 1rem;
  }
`,rI=dh.div`
  margin-top: 10vh;

  @media (max-width: 600px) {
    margin-top: 2rem;
  }
`;function oI(){const[e,t]=W.useState([]),[n,r]=W.useState(sessionStorage.getItem("animeinfo"));return W.useEffect((()=>{!async function(){var e=await Ek.getGenres();t(e)}()}),[]),Z.jsxs(W.Fragment,{children:[Z.jsx(rI,{}),function(){if(e)return e.map(((e,t)=>Z.jsx(nI,{children:Z.jsx(TO,{customURL:`/genre/${e.title}`,title:e.title,animes:e.animes})},t)))}(),n&&Z.jsx(pj,{anime:JSON.parse(n),openAnimation:!1,onClose:()=>{r(null),sessionStorage.removeItem("animeinfo")}})]})}const iI=dh.div`
  & + & {
    margin-top: 1rem;
  }
`,aI=dh.div`
  margin-top: 10vh;

  @media (max-width: 600px) {
    margin-top: 2rem;
  }
`,lI=dh.div`
  width: 100%;
  overflow: clip;
  position: relative;
`,sI=dh.div`
  overflow: scroll hidden;
  scrollbar-width: none;
  scroll-behavior: smooth;

  ::-webkit-scrollbar {
    display: none;
  }
`,cI=dh.div`
  width: fit-content;
  display: flex;
  padding: 1.25vw 3.5vw;
  padding-top: .6vw;
  padding-bottom: 5rem;
`,uI=dh.h3`
  display: flex;
  margin-left: 3.5vw;
  margin-bottom: -.2vw;
  position: relative;
  z-index: 2;
`,dI=dh.button`
  width: 3.5vw;
  height: 100%;
  cursor: pointer;
  position: absolute;
  z-index: 2;
  color: white;
  opacity: 0;
  transform: scaleY(.9);
  background: rgba(0, 0, 0, .5);
  transition: opacity ease 200ms;

  ${e=>"left"===e.position&&Xm`
    left: 0;
  `}

  ${e=>"right"===e.position&&Xm`
    right: 0;
  `}

  ${lI}:hover & {
    opacity: 1;
  }

  @media (max-width: 800px) {
    display: none;
  }
`,fI=dh.div`
  width: 8vw;

  @media (max-width: 1500px) {
    width: 12vw;
  }
  @media (max-width: 1000px) {
    width: 22vw;
  }

  & + & {
    margin-left: .6rem;
    @media (max-width: 800px) {
      margin-left: .4rem;
    }
  }

  button {
    height: 100%;
    cursor: pointer;
    transition: transform ease 200ms;

    :hover {
      transform: scale(1.1);
    }
  }
  background: transparent;

  img {
    max-width: 100%;
    min-height: 100%;
    object-fit: cover;
  }
`,pI=dh.ul`
  color: white;
  border-radius: .375rem;
  margin: 5px;
  padding: .3rem; 
  white-space: nowrap;
  padding-bottom: .1rem;
  --tw-bg-opacity: 1; 
  background-color: rgb(38 38 38/var(--tw-bg-opacity));
  width: -webkit-max-content; 
  width: -moz-max-content; 
  width: max-content;
  font-size: 80%;
`,mI=dh.ul`
  color: white;
  border-radius: .375rem;
  margin: 5px;
  padding: .3rem; 
  white-space: nowrap;
  padding-bottom: .1rem;
  --tw-bg-opacity: 1; 
  font-size: 80%;
  background-color: rgb(38 38 38/var(--tw-bg-opacity));
  width: -webkit-max-content; 
  width: -moz-max-content; 
  width: max-content;
  margin-left: auto;
`,hI=dh.div`
  display: flex;
  z-index: 5;
  pointer-events: none;
  width: 8vw;
`,gI=dh.button`
  background: transparent;
  width: 100%;
  border: none;
  img{
    &:hover {
      filter: brightness(50%);
    }
  }

  ${e=>e.grayed&&Xm`
    filter: brightness(50%);
  `}
`,vI=dh.img`
  transition: filter 200ms ease;
  max-width: 100%;
  aspect-ratio: 20/29;
  border-radius: .2vw;
`;function yI({anime:e,onClick:t=(()=>{}),onContext:n=(()=>{})}){var r,o=e.airingTime,i=o<Date.now();return Z.jsx(fI,{onContextMenu:n,children:Z.jsxs(gI,{onClick:t,grayed:i,id:"cardbutton",children:[Z.jsxs(hI,{children:[Z.jsx(pI,{children:e.delayed?"Delayed":new Date(o).toLocaleString("en-US",{hour:"numeric",minute:"numeric",hour12:!0})}),Z.jsxs(mI,{children:["EP ",e.scheduledEpisode]})]}),Z.jsx(vI,{src:null==(r=e.images)?void 0:r.medium,id:"imgcard",alt:e.anilistID})]})})}function bI({title:e,animes:t=[]}){const n=W.useRef(),[r,o]=W.useState(),[i,a]=W.useState(),[l,s]=W.useState(null);var c=JSON.parse(localStorage.getItem("settings"));function u(e=!0){const t=window.innerWidth,l=n.current.scrollWidth,s=l/(l/t)-.04*t*2;n.current.scrollBy(e?s:-s,0),e?(r||o(!0),n.current.scrollLeft+s+n.current.clientWidth>=l&&a(!1)):(i||a(!0),n.current.scrollLeft-s<=0&&o(!1))}return W.useEffect((()=>{n.current.scrollWidth>window.innerWidth&&a(!0)}),[]),Z.jsxs(Z.Fragment,{children:[Z.jsx(uI,{children:e}),Z.jsxs(lI,{children:[r&&Z.jsx(dI,{type:"button",position:"left",onClick:()=>u(!1),children:Z.jsx(gO,{style:{fontSize:"3vw"}})}),i&&Z.jsx(dI,{type:"button",position:"right",onClick:()=>u(),children:Z.jsx(kO,{style:{fontSize:"3vw"}})}),Z.jsx(sI,{ref:n,children:Z.jsx(cI,{children:t.map(((e,t)=>Z.jsx(yI,{anime:e,titleLanguage:(null==c?void 0:c.titlelang)?c.titlelang:"1",onClick:()=>s(e)},t)))})})]}),l&&Z.jsx(pj,{anime:l,onClose:e=>s(e??null)})]})}var wI={Monday:0,Tuesday:1,Wednesday:2,Thursday:3,Friday:4,Saturday:5,Sunday:6};function xI(){const[e,t]=W.useState([]),[n,r]=W.useState(sessionStorage.getItem("animeinfo"));return W.useEffect((()=>{!async function(){var e,n=await Ek.getSchedule();t(n),null==(e=document.getElementById(wI[n.find((e=>e.today)).title]))||e.scrollIntoView({block:"center",behavior:"smooth"})}()}),[]),Z.jsxs(W.Fragment,{children:[Z.jsx(aI,{}),e.map(((e,t)=>Z.jsxs(iI,{id:t,children:[Z.jsx("div",{style:{position:"absolute",backgroundColor:"gray",opacity:.5}}),Z.jsx(bI,{title:e.title,animes:e.animes})]},t))),n&&Z.jsx(pj,{anime:JSON.parse(n),openAnimation:!1,onClose:()=>{r(null),sessionStorage.removeItem("animeinfo")}}),Z.jsx("div",{style:{margin:"5%"}})]})}const kI=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,SI=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`;function jI(){const e=W.useRef(),[t,n]=W.useState(),[r,o]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo")));return W.useEffect((()=>{let e=!0;return Ek.getCollection().then((t=>{e&&n(t)})),()=>{e=!1}}),[]),Z.jsxs(kI,{ref:e,children:[null==t?void 0:t.map(((e,t)=>{var n,r,i;return Z.jsx(SI,{onContextMenu:e=>{"imgcard"===e.target.id&&e.preventDefault()},children:Z.jsxs("button",{onClick:()=>o(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(i=e.images)?void 0:i.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),r&&Z.jsx(tN,{collection:r,onClose:e=>o(e??null)})]})}const EI=dh.div`
  width: 400px;
  display: flex;
  flex-direction: column;
  margin: 0 auto;
  margin-top: 20vh;

  @media (max-width: 600px) {
    width: 100vw;
  }
`,CI=dh.input`
  background: #333;
  border-radius: 4px;
  border: 0;
  color: #fff;
  height: 3.5vh;
  line-height: 50px;
  padding: 3rem;
  margin: .8vh;
  margin-bottom: .1vh;
  &:last-of-type {
    margin-bottom: .2vh;
  }

  &:-webkit-autofill,
  &:-webkit-autofill:focus {
      transition: background-color 600000s 0s, color 600000s 0s;
  }
  &[data-autocompleted] {
      background-color: transparent !important;
  }
`,AI=dh.button`
  background: #e50914;
  border-radius: 4px;
  font-size: 85%;
  font-weight: bold;
  margin: 1vh;
  padding: 2.5rem;
  border: 0;
  color: white;
  cursor: pointer;
  &:disabled {
    opacity: 0.5;
  }
`,OI=dh.a`
  margin: 20px auto;
  color: #1c1c1c;
  font-weight: bold;
  color: #aaa;
  font-weight: normal;
  text-decoration: none;
  cursor: pointer;
`,NI=dh.img`
  width: 60%;
  height: 7rem;
  margin: auto;
  margin-bottom: 3%;
  opacity: 0;
  transition: opacity 1.5s ease;
`;function _I(){var{token:e}=bp();const[t,n]=W.useState(""),[r,o]=W.useState("");return Z.jsxs(EI,{children:[Z.jsx(NI,{id:"mobilelogo",onLoad:()=>document.getElementById("mobilelogo").style.opacity=1,src:"https://animeflix.live/static/media/logo.ff4c5c6e9524142bb4480c86fdc841c8.svg"}),Z.jsx(CI,{type:"password",placeholder:"New Password",onChange:({target:e})=>n(e.value)}),Z.jsx(CI,{type:"password",placeholder:"Repeat Password",onChange:({target:e})=>o(e.value)}),Z.jsx(AI,{onClick:async()=>{if(t!==r)return hd("Passwords don't match! Try again.",{duration:2500,style:{color:"white",background:"#E87C03"}});Ek.set(e,"password",t),hd.success("Password reset successfully!",{duration:2500,style:{background:"#333",color:"#fff"}}),Ek.getAuth(e).then((e=>{window.dispatchEvent(new CustomEvent("updateData",{detail:e}))})),setTimeout((()=>{window.location.href="/"}),2500)},children:"Reset Password"}),Z.jsx(OI,{children:"Back to main page"})]})}const PI=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,II=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`;function TI(){const e=W.useRef(),[t,n]=W.useState(),[r,o]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:i,setClicked:a,points:l,setPoints:s}=IO();var[c,u]=W.useState(1),d=!1;async function f(){var t;const o=Math.abs(window.scrollY/((null==(t=null==e?void 0:e.current)?void 0:t.clientHeight)-window.innerHeight));if(c>9&&(c=0),!d&&!r&&o>.8){d=!0;const e=await Ek.getTrending(c);n((t=>t.concat(null==e?void 0:e.trending))),u(c+1)}}return W.useEffect((()=>{let e=!0;return Ek.getTrending(0).then((t=>{e&&n(null==t?void 0:t.trending)})),()=>{e=!1}}),[]),W.useEffect((()=>(document.addEventListener("scroll",f),()=>document.removeEventListener("scroll",f)))),Z.jsxs(Z.Fragment,{children:[Z.jsxs(PI,{ref:e,children:[null==t?void 0:t.map(((e,t)=>{var n,r,l;return Z.jsx(II,{onContextMenu:e=>{"imgcard"===e.target.id&&(e.preventDefault(),a(!i),s({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>o(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(l=e.images)?void 0:l.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),r&&Z.jsx(pj,{anime:r,onClose:e=>{o(e??null),sessionStorage.removeItem("animeinfo")}})]}),Z.jsx(PO,{scale:1,points:l,clicked:i,animes:t,setClicked:a,setSelectedAnime:o})]})}const LI=dh.div`
  display: inline-block;
  margin-top: clamp(3rem, 2vw, 5rem);
  padding: 3.5vw;
`,MI=dh.div`
  display: inline-block;
  width: 30vw;
  height: 44vw;

  background: none;

  button {
    width: inherit;
    height: inherit;
    cursor: pointer;
    transition: transform ease 200ms;
    transform: scale(.9);

    :hover {
      transform: scale(1);
    }
  }

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  @media (min-width: 1300px) {
    width: ${18}vw;
    height: ${26.4}vw;
  }
`;function RI(){const e=W.useRef(),[t,n]=W.useState(),[r,o]=W.useState(JSON.parse(sessionStorage.getItem("animeinfo"))),{clicked:i,setClicked:a,points:l,setPoints:s}=IO();var[c,u]=W.useState(1),d=!1;async function f(){var t;const o=Math.abs(window.scrollY/((null==(t=null==e?void 0:e.current)?void 0:t.clientHeight)-window.innerHeight));if(c>9&&(c=0),!d&&!r&&o>.8){d=!0;const e=await Ek.getPopular(c);n((t=>t.concat(e))),u(c+1)}}return W.useEffect((()=>{let e=!0;return Ek.getPopular(0).then((t=>{e&&n(t)})),()=>{e=!1}}),[]),W.useEffect((()=>(document.addEventListener("scroll",f),()=>document.removeEventListener("scroll",f)))),Z.jsxs(Z.Fragment,{children:[Z.jsxs(LI,{ref:e,children:[null==t?void 0:t.map(((e,t)=>{var n,r,l;return Z.jsx(MI,{onContextMenu:e=>{"imgcard"===e.target.id&&(e.preventDefault(),a(!i),s({x:e.pageX,y:e.pageY,target:e.target}))},children:Z.jsxs("button",{onClick:()=>o(e),style:{background:"transparent",border:"none"},children:[Z.jsxs("picture",{id:"imgcontainer",children:[Z.jsx("source",{media:"(min-width: 900px)",srcSet:null==(n=e.images)?void 0:n.large}),Z.jsx("source",{media:"(min-width: 300px)",srcSet:null==(r=e.images)?void 0:r.medium}),Z.jsx("img",{src:null==(l=e.images)?void 0:l.small,id:"imgcard",alt:e.anilistID})]}),Z.jsx("h3",{className:"cardname",children:e.title.english||e.title.userPreferred||e.title.romaji})]})},t)})),r&&Z.jsx(pj,{anime:r,onClose:e=>{o(e??null),sessionStorage.removeItem("animeinfo")}})]}),Z.jsx(PO,{scale:1,points:l,clicked:i,animes:t,setClicked:a,setSelectedAnime:o})]})}var zI=["watch","resetpassword"];function $I(){const e=[{path:"/",Component:bN},{path:"/genre/:genre",Component:kN},{path:"/watch/:animeid/:position?",Component:Y_},{path:"/search/:query?",Component:IN},{path:"/movies",Component:XP},{path:"/series",Component:tI},{path:"/genres",Component:oI},{path:"/schedule",Component:xI},{path:"/collections",Component:jI},{path:"/trending",Component:TI},{path:"/popular",Component:RI},{path:"/mylist",Component:GP},{path:"/resetpassword/:token?",Component:_I}];return W.useEffect((()=>{var e=localStorage.getItem("mylist");(null==e?void 0:e.length)>2&&(localStorage.setItem("My List",e),localStorage.removeItem("mylist")),!sessionStorage.getItem("userdata")&&localStorage.getItem("token")&&Ek.getAuth(localStorage.getItem("token")).then((e=>{if(!1===e)return localStorage.removeItem("token");e.newload=!0,window.dispatchEvent(new CustomEvent("updateData",{detail:e}))})),window.addEventListener("updateData",(e=>{var t,n,r=e.detail;if(r){var o=r.recentlywatched;o&&localStorage.setItem("recentlywatched",JSON.stringify(o));var i=(null==(t=r.folder_names)?void 0:t.length)>1?r.folder_names:["My List"];for(var a of(localStorage.setItem("folders",JSON.stringify(i)),i)){var l=null==(n=r.folders)?void 0:n[a];l&&localStorage.setItem(a,JSON.stringify(l))}sessionStorage.setItem("userdata",JSON.stringify({username:r.username,profile_picture:r.profile_picture})),r.settings&&localStorage.setItem("settings",JSON.stringify(r.settings));var s=r.watchdata;if(s)for(var c in s){var u=s[c];localStorage.setItem(`${c}`,JSON.stringify(u))}}}))}),[]),Z.jsxs(wp,{children:[-1===zI.indexOf(window.location.pathname.split("/")[1])&&Z.jsx($A,{}),Z.jsx(md,{}),e.map((({path:e,Component:t})=>Z.jsx(gp,{path:e,exact:!0,style:{overflow:"hidden"},children:({match:e})=>Z.jsxs(mh,{render:e,children:[Z.jsx(t,{}),Z.jsx("div",{style:{height:"7rem"}})]})},e)))]})}pu.render(Z.jsx($I,{}),document.getElementById("root")),"serviceWorker"in navigator&&navigator.serviceWorker.ready.then((e=>{e.unregister()})).catch((e=>{console.error(e.message)}));
